<?php 
$page_title = "About Us Page";
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="css/index.css">
    <style>
      h3 {
        font-family: Georgia, serif;
      }

      body {
        background-image: url('image/img.jpg');

      }

    </style>
</head>

<body>
<div class="section">
		<div class="container">
			<div class="content-section">
				<div class="title">
					<h1 style="font-family: Georgia, serif;">What do we do?</h1>
				</div>
				<div class="content">
					<h3>eWaste is a system that aims to assist by collecting and providing
                sufficient data about food wastes from restaurants to NGOs and government institutions
                that have the means as well as the resources to address this global problem.</h3>
			</div>
		</div>
	</div>

    <div class="wrapper">
    <h1 style="font-family: Georgia, serif;">Our Team</h1>
    <div class="our_team">
        <div class="team_member">
          <div class="member_img">
             <img src="image/ausImg.jpg" alt="aus">
            
          </div>
          <h3>Austin Balace</h3>
          <span>Back End, Front End Developer & Tester</span>
          <p></p>
        </div>
        <div class="team_member">
           <div class="member_img">
           <img src="image/carloimg.jpg" alt="carlo">
             
          </div>
          <h3>Carlo Castillo</h3>
          <span>Researcher & Tester</span>
          <p></p>
      </div>
        <div class="team_member">
           <div class="member_img">
           <img src="image/chabsImg.jpg" alt="chabs">
             
          </div>
          <h3>Chablis Peña</h3>
          <span>Front End Developer</span>
          <p></p>
      </div>
        <div class="team_member">
           <div class="member_img">
           <img src="image/roshImg.png" alt="rosh">
             
          </div>
          <h3>Roshan Thakwani</h3>
          <span>Back End Developer & Tester</span>
          <p></p>
      </div>  
    </div>
</div>	

</body>
</html>