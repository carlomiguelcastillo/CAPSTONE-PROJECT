<?php 
include('authentication.php');
$page_title = "Add Form for Restaurants";
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');
include('includes/scripts.php');

if($_SESSION['user_type'] != 'resto') // Restricts org user from entering page
{
    header("Location: error.html");
}

// Get the CSRF token from the session
$sessionCsrfToken = $_SESSION['auth_user']['csrf_token'];

// Get the user's CSRF token from the database
$userCsrfTokenQuery = "SELECT csrf_token FROM userresto WHERE resto_id = {$_SESSION['auth_user']['id']}";
$userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
$userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
$userCsrfToken = $userCsrfTokenRow['csrf_token'];

// Validate the CSRF token
if ($sessionCsrfToken !== $userCsrfToken) {
    // CSRF token does not match, handle the error (e.g., redirect to an error page)
    header("Location: error.html");
    exit;
}

// CSRF token is valid, continue with further processing
// ...


$csrf_token = $_SESSION['csrf_token'];
$logged_user = $_SESSION['auth_user']['email'];
$query = "SELECT * FROM userResto WHERE email = ?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, 's', $logged_user);
mysqli_stmt_execute($stmt);
$query_run = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($query_run);

$foodtype = isset($_GET['foodtype']) ? htmlspecialchars($_GET['foodtype']) : '';

if(isset($_POST['add_waste']))
{
    $email = htmlspecialchars($_POST['email']);
    $restoname = htmlspecialchars($_POST['restoname']);
    $rcity = htmlspecialchars($_POST['rcity']);
    $restotype = htmlspecialchars($_POST['restotype']);
    $foodtype = htmlspecialchars($_POST['foodtype']);
    $rawcost = htmlspecialchars($_POST['rawcost']);
    $weight = htmlspecialchars($_POST['weight']);
    $frequency = htmlspecialchars($_POST['frequency']);
    $reason = htmlspecialchars($_POST['reason']);
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $logged_user = $_SESSION['auth_user']['email'];
    $query = "SELECT * FROM userResto WHERE email = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $logged_user);
    mysqli_stmt_execute($stmt);
    $query_run = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($query_run);

    $resto_id = $row['resto_id'];

    $number_foodtype = preg_match('@[0-9]@', $foodtype);
    $specialChars_foodtype = preg_match('@[^\w]@', $foodtype);

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($rawcost <= 0 OR $weight <= 0) 
    {
        $_SESSION['status'] = "Raw cost or weight cannot be 0 or less than 0";
        header("Location: /ewaste/add-waste"); 
        exit(0);
    }
    else
    {
        $query = "INSERT INTO waste (resto_id, email, restoname, rcity, restotype, foodtype, rawcost, weight, frequency, reason, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "isssssddss", $resto_id, $email, $restoname, $rcity, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason);
        $query_run = mysqli_stmt_execute($stmt);

        if($query_run)
        {          
            $waste_data = "SELECT MAX(id) AS id FROM waste WHERE email = ?"; //gets latets id from wastew tbl
            $stmt = mysqli_prepare($con, $waste_data);
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            $waste_data_run = mysqli_stmt_get_result($stmt);
            $row_waste = mysqli_fetch_array($waste_data_run);
            $waste_id = $row_waste['id'];
    
            $_SESSION['action'] = "Added food waste (Waste ID: $waste_id)";
            $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
            $log_query_run = mysqli_query($con, $log_query);

            if($log_query_run)
            {
                $_SESSION['progress'] = "Food Waste data added! Adding more data is highly appreciated.";
                $_SESSION['progress_code'] = "success";
                header('location:/ewaste/add-waste');
            }
        }
        else
        {
            $_SESSION['progress'] = "Food Waste not added!";
            $_SESSION['progress_code'] = "error";
            header('location:/ewaste/add-waste');
        }
    }
}

if(isset($_POST['add_surplus']))
{
    $surplus = htmlspecialchars($_POST['surplus']);
    $rawcost = htmlspecialchars($_POST['rawcost']);
    $weight = htmlspecialchars($_POST['weight']);
    $expirydate = htmlspecialchars($_POST['expirydate']);
    $freshness = htmlspecialchars($_POST['freshness']);
    $packaging = htmlspecialchars($_POST['packaging']);
    $storagecondition = htmlspecialchars($_POST['storagecondition']);
    $availability = htmlspecialchars($_POST['availability']);
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $logged_user = $_SESSION['auth_user']['id'];
    $query = "SELECT * FROM userResto WHERE email = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $logged_user);
    mysqli_stmt_execute($stmt);
    $query_run = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($query_run);

    $resto_id = $row['resto_id'];

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($rawcost <= 0 OR $weight <= 0) 
    {
        $_SESSION['status'] = "Raw cost or weight cannot be 0 or less than 0";
        header("Location: /ewaste/add-waste"); 
        exit(0);
    }
    else
    {
        $query = "INSERT INTO surplus (resto_id, surplus, rawcost, weight, expirydate, freshness, packaging, storagecondition, availability, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "isddsssss", $logged_user, $surplus, $rawcost, $weight, $expirydate, $freshness, $packaging, $storagecondition, $availability);
        $query_run = mysqli_stmt_execute($stmt);

        if($query_run)
        {          
            $waste_data = "SELECT MAX(id) AS id FROM surplus WHERE resto_id = ?"; //gets latets id from wastew tbl
            $stmt = mysqli_prepare($con, $waste_data);
            mysqli_stmt_bind_param($stmt, 's', $logged_user);
            mysqli_stmt_execute($stmt);
            $waste_data_run = mysqli_stmt_get_result($stmt);
            $row_waste = mysqli_fetch_array($waste_data_run);
            $waste_id = $row_waste['id'];
    
            $_SESSION['action'] = "Added surplus (Waste ID: $waste_id)";
            $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
            $log_query_run = mysqli_query($con, $log_query);

            if($log_query_run)
            {
                $_SESSION['progress'] = "Food Waste data added! Adding more data is highly appreciated.";
                $_SESSION['progress_code'] = "success";
                header('location:/ewaste/add-waste');
            }
        }
        else
        {
            $_SESSION['progress'] = "Food Surplus not added!";
            $_SESSION['progress_code'] = "error";
            header('location:/ewaste/add-waste');
        }
    }
}

if(isset($_POST['add_recwaste']))
{
    $recwaste = htmlspecialchars($_POST['recwaste']);
    $weight = htmlspecialchars($_POST['weight']);
    $containers = htmlspecialchars($_POST['containers']);
    $frequency = htmlspecialchars($_POST['frequency']);
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $logged_user = $_SESSION['auth_user']['id'];
    $query = "SELECT * FROM userResto WHERE email = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $logged_user);
    mysqli_stmt_execute($stmt);
    $query_run = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($query_run);

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($weight <= 0) 
    {
        $_SESSION['status'] = "Weight cannot be 0 or less than 0";
        header("Location: /ewaste/add-waste"); 
        exit(0);
    }
    else
    {
        $query = "INSERT INTO recwaste (resto_id, recwaste, weight, containers, frequency, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "isdss", $logged_user, $recwaste, $weight, $containers, $frequency);
        $query_run = mysqli_stmt_execute($stmt);

        if($query_run)
        {          
            $waste_data = "SELECT MAX(id) AS id FROM recwaste WHERE resto_id = ?"; //gets latets id from wastew tbl
            $stmt = mysqli_prepare($con, $waste_data);
            mysqli_stmt_bind_param($stmt, 's', $logged_user);
            mysqli_stmt_execute($stmt);
            $waste_data_run = mysqli_stmt_get_result($stmt);
            $row_waste = mysqli_fetch_array($waste_data_run);
            $waste_id = $row_waste['id'];
    
            $_SESSION['action'] = "Added recycled waste (Waste ID: $waste_id)";
            $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
            $log_query_run = mysqli_query($con, $log_query);

            if($log_query_run)
            {
                $_SESSION['progress'] = "Data added! Adding more data is highly appreciated.";
                $_SESSION['progress_code'] = "success";
                header('location:/ewaste/add-waste');
            }
        }
        else
        {
            $_SESSION['progress'] = "Data not added!";
            $_SESSION['progress_code'] = "error";
            header('location:/ewaste/add-waste');
        }
    }
}

if(isset($_POST['add_reswaste']))
{
    $reswaste = htmlspecialchars($_POST['reswaste']);
    $weight = htmlspecialchars($_POST['weight']);
    $containers = htmlspecialchars($_POST['containers']);
    $frequency = htmlspecialchars($_POST['frequency']);
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $logged_user = $_SESSION['auth_user']['id'];
    $query = "SELECT * FROM userResto WHERE email = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $logged_user);
    mysqli_stmt_execute($stmt);
    $query_run = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($query_run);

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($weight <= 0) 
    {
        $_SESSION['status'] = "Weight cannot be 0 or less than 0";
        header("Location: /ewaste/add-waste"); 
        exit(0);
    }
    else
    {
        $query = "INSERT INTO reswaste (resto_id, reswaste, weight, containers, frequency, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "isdss", $logged_user, $reswaste, $weight, $containers, $frequency);
        $query_run = mysqli_stmt_execute($stmt);

        if($query_run)
        {          
            $waste_data = "SELECT MAX(id) AS id FROM reswaste WHERE resto_id = ?"; //gets latets id from wastew tbl
            $stmt = mysqli_prepare($con, $waste_data);
            mysqli_stmt_bind_param($stmt, 's', $logged_user);
            mysqli_stmt_execute($stmt);
            $waste_data_run = mysqli_stmt_get_result($stmt);
            $row_waste = mysqli_fetch_array($waste_data_run);
            $waste_id = $row_waste['id'];
    
            $_SESSION['action'] = "Added recycled waste (Waste ID: $waste_id)";
            $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
            $log_query_run = mysqli_query($con, $log_query);

            if($log_query_run)
            {
                $_SESSION['progress'] = "Data added! Adding more data is highly appreciated.";
                $_SESSION['progress_code'] = "success";
                header('location:/ewaste/add-waste');
            }
        }
        else
        {
            $_SESSION['progress'] = "Data not added!";
            $_SESSION['progress_code'] = "error";
            header('location:/ewaste/add-waste');
        }
    }
}

if(isset($_POST['add_stwaste']))
{
    $stwaste = htmlspecialchars($_POST['stwaste']);
    $weight = htmlspecialchars($_POST['weight']);
    $containers = htmlspecialchars($_POST['containers']);
    $frequency = htmlspecialchars($_POST['frequency']);
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $logged_user = $_SESSION['auth_user']['id'];
    $query = "SELECT * FROM userResto WHERE email = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, 's', $logged_user);
    mysqli_stmt_execute($stmt);
    $query_run = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($query_run);

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($weight <= 0) 
    {
        $_SESSION['status'] = "Weight cannot be 0 or less than 0";
        header("Location: /ewaste/add-waste"); 
        exit(0);
    }
    else
    {
        $query = "INSERT INTO stwaste (resto_id, stwaste, weight, containers, frequency, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())";
        $stmt = mysqli_prepare($con, $query);

        mysqli_stmt_bind_param($stmt, "isdss", $logged_user, $stwaste, $weight, $containers, $frequency);
        $query_run = mysqli_stmt_execute($stmt);

        if($query_run)
        {          
            $waste_data = "SELECT MAX(id) AS id FROM stwaste WHERE resto_id = ?"; //gets latets id from wastew tbl
            $stmt = mysqli_prepare($con, $waste_data);
            mysqli_stmt_bind_param($stmt, 's', $logged_user);
            mysqli_stmt_execute($stmt);
            $waste_data_run = mysqli_stmt_get_result($stmt);
            $row_waste = mysqli_fetch_array($waste_data_run);
            $waste_id = $row_waste['id'];
    
            $_SESSION['action'] = "Added recycled waste (Waste ID: $waste_id)";
            $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
            $log_query_run = mysqli_query($con, $log_query);

            if($log_query_run)
            {
                $_SESSION['progress'] = "Data added! Adding more data is highly appreciated.";
                $_SESSION['progress_code'] = "success";
                header('location:/ewaste/add-waste');
            }
        }
        else
        {
            $_SESSION['progress'] = "Data not added!";
            $_SESSION['progress_code'] = "error";
            header('location:/ewaste/add-waste');
        }
    }
}
?>


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add form</title>
    <!-- BOOTSTRAP PACKAGE CDN -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="path/to/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-image: url('image/img.jpg');
            height: 300px; 
            background-repeat: no-repeat;
            background-size: cover;  
            background-attachment: fixed;
        }
        .container {
            width:1000px;
            margin:4% auto;
            padding:10px;
            border-radius: 20px;
        }
        .card-header{  
            width: 420px;
            margin: 7px;
            height:100px;
            padding: 1px;
            text-align: center;
            font-weight: 1000;
            /* background-image: url('image/imgg.jpg');     */
            background-color: #E2DFD2;
        }
        .card {
            width: 500px;
            margin:10% auto;
            padding:20px;
            border-radius: 20px;
            /* background-image: url('image/imgg.jpg');     */
            background-color: #E2DFD2;
        }
        .form-control {
            width: 420px;            
        }

        .btn {
            width: 30%;
            padding: 10px;
            color: white;
            background-color: black;
            font-weight: 800;        
        }

        .status {
            color: #A52A2A;
            text-align: center;
            background-color: #E2DFD2; 
            padding: 10px; /* Add padding for readability */
            border-radius: 20px; 
            position: relative;
            left: 10px;
        }
</style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">    
                <div class="alert">
                    <?php
                        if(isset($_SESSION['status']))
                        {
                            echo '<h3 class="status">' . $_SESSION['status'] . '</h3>';
                            unset($_SESSION['status']);
                        }               
                    ?>
                </div>

                <div class="card">
                    <div class="card-header">
                        <div class="head mb-3 mt-4" style="font-size: 40px; font-family: Georgia; font-weight: 700; margin-left: 22px;">ADD DATA</div>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <input name="email" type="hidden"  value="<?php echo $row['email']; ?>"/>                                                                    
                                <input name="restoname" type="hidden"  value="<?php echo $row['restoname']; ?>"/>                                                                                                                         
                                <input name="rcity" type="hidden" value="<?php echo $row['rcity']; ?>" />
                                <input name="restotype" type="hidden"  value="<?php echo $row['restotype']; ?>"/>   
                                <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  

                                <div class="col">
                                    <div class="form-group">
                                        <label>Type of Waste/ Surplus</label>
                                        <select name="data" id="data" class="form-control" required>
                                            <option value="">Select one...</option>
                                            <option value="fwaste">Food Waste</option>
                                            <option value="fsurplus">Food Surplus</option>
                                            <option value="recwaste">Recycleable Waste</option>
                                            <option value="reswaste">Residual Waste</option>
                                            <option value="stwaste">Special or Toxic Waste</option>
                                        </select>
                                    </div>

                                    <div id="additionalFields" style="display: none;">
                                        <!-- Additional dropdowns will be inserted here based on the selection -->

                                    </div>
                                                                 
                                </div>
                            </div>                                  
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script>
    // Add event listener to the foodtype dropdown
    const foodTypeDropdown = document.getElementById('data');
    foodTypeDropdown.addEventListener('change', showAdditionalFields);

    // Function to show/hide additional fields based on the foodtype selection
    function showAdditionalFields() {
        const selectedValue = foodTypeDropdown.value;
        const additionalFieldsDiv = document.getElementById('additionalFields');

        // Clear previous additional fields
        additionalFieldsDiv.innerHTML = '';

        if (selectedValue === 'fwaste') 
        {
            // Show additional dropdowns for fwaste
            const subtypeDropdown = document.createElement('div');
            subtypeDropdown.className = 'form-group';
            subtypeDropdown.innerHTML = `
                <label>Type of Food Wasted</label>
                <select name="foodtype" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Dairy Products</option>
                    <option>Fruits</option>
                    <option>Meats</option>
                    <option>Vegetables</option>
                    <option>Canned Food</option>
                    <option>Rice/Grains/Seeds</option>
                    <option>Bread/Wheats</option>
                    <option>Desserts/Sweets</option> 
                </select>
            `;
            additionalFieldsDiv.appendChild(subtypeDropdown);

            const additionalField1 = document.createElement('div');
            additionalField1.className = 'form-group';
            additionalField1.innerHTML = `
                <label>Estimated Total Raw Cost of Food Wasted (PHP)</label>
                <input name="rawcost" type="number" step="any" class="form-control" maxlength="50" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField1);

            const additionalField2 = document.createElement('div');
            additionalField2.className = 'form-group';
            additionalField2.innerHTML = `
                <label>Estimated Weight of Food Wasted (KG)</label>
                <input name="weight" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField2);

            const additionalField3 = document.createElement('div');
            additionalField3.className = 'form-group';
            additionalField3.innerHTML = `
                <label>Frequency Waste Being Disposed</label>
                <select name="frequency" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Daily</option>
                    <option>Weekly</option>
                    <option>Monthly</option>
                    <option>Yearly</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField3);

            const additionalField4 = document.createElement('div');
            additionalField4.className = 'form-group';
            additionalField4.innerHTML = `
                <label>Reasons of Food Being Wasted</label>
                <select name="reason" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Customer Leftovers</option>
                    <option>Over-Stock</option>
                    <option>Expired goods</option>
                    <option>Kitchen scraps</option>
                    <option>Over-prepping</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField4);

            const buttonDiv = document.createElement('div');
            buttonDiv.className = 'd-flex justify-content-center mt-4';

            const button = document.createElement('button');
            button.name = 'add_waste';
            button.className = 'btn';
            button.type = 'submit';
            button.textContent = 'Add';

            buttonDiv.appendChild(button);
            additionalFieldsDiv.appendChild(buttonDiv);
        } 
        
        else if (selectedValue === 'fsurplus') 
        {
            const subtypeDropdown = document.createElement('div');
            subtypeDropdown.className = 'form-group';
            subtypeDropdown.innerHTML = `
                <label>Type of Food Surplus</label>
                <select name="surplus" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Dairy Products</option>
                    <option>Fruits</option>
                    <option>Meats</option>
                    <option>Vegetables</option>
                    <option>Canned Food</option>
                    <option>Rice/Grains/Seeds</option>
                    <option>Bread/Wheats</option>
                    <option>Desserts/Sweets</option> 
                </select>
            `;
            additionalFieldsDiv.appendChild(subtypeDropdown);

            const additionalField1 = document.createElement('div');
            additionalField1.className = 'form-group';
            additionalField1.innerHTML = `
                <label>Estimated Total Raw Cost of Food Surplus (PHP)</label>
                <input name="rawcost" type="number" step="any" class="form-control" maxlength="50" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField1);

            const additionalField2 = document.createElement('div');
            additionalField2.className = 'form-group';
            additionalField2.innerHTML = `
                <label>Estimated Weight of Food Surplus (KG)</label>
                <input name="weight" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField2);

            const additionalField3 = document.createElement('div');
            additionalField3.className = 'form-group';
            additionalField3.innerHTML = `
                <label>Best Before Date</label>
                <input name="expirydate" type="date" class="form-control" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField3);

            const additionalField4 = document.createElement('div');
            additionalField4.className = 'form-group';
            additionalField4.innerHTML = `
                <label>Freshness Waste Being Disposed</label>
                <select name="freshness" class="form-control" required>
                    <option value="">Select one...</option>
                    <option value="Good">Good: Recently Purchased, Long Shelf Life</option>
                    <option value="Fair">Fair: Moderate Shelf Life, Safe to Consume</option>
                    <option value="Slightly">Slightly Damaged: Minor Imperfections, Still Edible</option>
                    <option value="Close to Expire">Close to Expire: Short Shelf Life, Consume Immediately</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField4);

            const additionalField5 = document.createElement('div');
            additionalField5.className = 'form-group';
            additionalField5.innerHTML = `
                <label>Packaging of the Excess Food:</label>
                <select name="packaging" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Original Packaging</option>
                    <option>Sealed Bags</option>
                    <option>Plastic Containers</option>
                    <option>Glass Jars</option>
                    <option>Canned</option>
                    <option>Vacuum-Sealed</option>
                    <option>Paper Wrapping</option>
                    <option>No Packaging</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField5);

            const additionalField6 = document.createElement('div');
            additionalField6.className = 'form-group';
            additionalField6.innerHTML = `
                <label>Storage conditions of the Excess Food:</label>
                <select name="storagecondition" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Refrigerated</option>
                    <option>Frozen</option>
                    <option>Room Temperature</option>
                    <option>Dry Storage</option>
                    <option>Canned</option>
                    <option>Vacuum-Sealed</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField6);

            const additionalField7 = document.createElement('div');
            additionalField7.className = 'form-group';
            additionalField7.innerHTML = `
                <label>Availability of the Excess Food:</label>
                <input name="availability" type="date" class="form-control" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField7);

            const buttonDiv = document.createElement('div');
            buttonDiv.className = 'd-flex justify-content-center mt-4';

            const button = document.createElement('button');
            button.name = 'add_surplus';
            button.className = 'btn';
            button.type = 'submit';
            button.textContent = 'Add';

            buttonDiv.appendChild(button);
            additionalFieldsDiv.appendChild(buttonDiv);
        }
        
        else if (selectedValue === 'recwaste') {
            const subtypeDropdown = document.createElement('div');
            subtypeDropdown.className = 'form-group';
            subtypeDropdown.innerHTML = `
                <label>Type of Recycleable Waste</label>
                <select name="recwaste" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Paper (including newspapers)</option>
                    <option>Magazines</option>
                    <option>Mixed paper</option>
                    <option>Cardboard (OCC)</option>
                    <option>Glass bottles and Jars</option>
                    <option>Rigid plastic products</option>
                    <option>Metal containers (including tin, aluminum and steel cans)</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(subtypeDropdown);

            const additionalField1 = document.createElement('div');
            additionalField1.className = 'form-group';
            additionalField1.innerHTML = `
                <label>Estimated Weight of Receycled Waste (KG)</label>
                <input name="weight" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField1);

            const additionalField2 = document.createElement('div');
            additionalField2.className = 'form-group';
            additionalField2.innerHTML = `
                <label>Number of Containers Used</label>
                <input name="containers" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField2);

            const additionalField3 = document.createElement('div');
            additionalField3.className = 'form-group';
            additionalField3.innerHTML = `
                <label>Frequency of Waste Being Disposed:</label>
                <select name="frequency" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Daily</option>
                    <option>Weekly</option>
                    <option>Monthly</option>
                    <option>Yearly</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField3);

            const buttonDiv = document.createElement('div');
            buttonDiv.className = 'd-flex justify-content-center mt-4';

            const button = document.createElement('button');
            button.name = 'add_recwaste';
            button.className = 'btn';
            button.type = 'submit';
            button.textContent = 'Add';

            buttonDiv.appendChild(button);
            additionalFieldsDiv.appendChild(buttonDiv);
        }


        else if (selectedValue === 'reswaste') 
        {
            const subtypeDropdown = document.createElement('div');
            subtypeDropdown.className = 'form-group';
            subtypeDropdown.innerHTML = `
                <label>Type of Residual Waste</label>
                <select name="reswaste" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Contaminated soil</option>
                    <option>Ceramics</option>
                    <option>Gypsum Board</option>
                    <option>Linoleum</option>
                    <option>Leather</option>
                    <option>Rubber</option>
                    <option>Textiles</option>
                    <option>Electronics</option>
                    <option>Fertilizers</option>
                    <option>Detergents</option>
                    <option>Oil</option>
                    <option>Pharmaceutical waste</option>
                    <option>Photographic film and paper</option>
                    <option>Pesticides</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(subtypeDropdown);

            const additionalField1 = document.createElement('div');
            additionalField1.className = 'form-group';
            additionalField1.innerHTML = `
                <label>Estimated Weight of Residual Waste (KG)</label>
                <input name="weight" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField1);

            const additionalField2 = document.createElement('div');
            additionalField2.className = 'form-group';
            additionalField2.innerHTML = `
                <label>Number of Containers Used</label>
                <input name="containers" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField2);

            const additionalField3 = document.createElement('div');
            additionalField3.className = 'form-group';
            additionalField3.innerHTML = `
                <label>Frequency of Waste Being Disposed:</label>
                <select name="frequency" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Daily</option>
                    <option>Weekly</option>
                    <option>Monthly</option>
                    <option>Yearly</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField3);

            const buttonDiv = document.createElement('div');
            buttonDiv.className = 'd-flex justify-content-center mt-4';

            const button = document.createElement('button');
            button.name = 'add_reswaste';
            button.className = 'btn';
            button.type = 'submit';
            button.textContent = 'Add';

            buttonDiv.appendChild(button);
            additionalFieldsDiv.appendChild(buttonDiv);
        }

        else if (selectedValue === 'stwaste') 
        {
            const subtypeDropdown = document.createElement('div');
            subtypeDropdown.className = 'form-group';
            subtypeDropdown.innerHTML = `
                <label>Type of Special or Toxic Waste</label>
                <select name="stwaste" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Poisonous</option>
                    <option>Radioactive</option>
                    <option>Explosive</option>
                    <option>Carcinogenic</option>
                    <option>Mutagenic </option>
                    <option>Teratogenuic</option>
                    <option>Bioaccumulative</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(subtypeDropdown);

            const additionalField1 = document.createElement('div');
            additionalField1.className = 'form-group';
            additionalField1.innerHTML = `
                <label>Estimated Weight of pecial or Toxic Waste (KG)</label>
                <input name="weight" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField1);

            const additionalField2 = document.createElement('div');
            additionalField2.className = 'form-group';
            additionalField2.innerHTML = `
                <label>Number of Containers Used</label>
                <input name="containers" type="number" step="any" class="form-control" maxlength="200" required/>
            `;
            additionalFieldsDiv.appendChild(additionalField2);

            const additionalField3 = document.createElement('div');
            additionalField3.className = 'form-group';
            additionalField3.innerHTML = `
                <label>Frequency of Waste Being Disposed:</label>
                <select name="frequency" class="form-control" required>
                    <option value="">Select one...</option>
                    <option>Daily</option>
                    <option>Weekly</option>
                    <option>Monthly</option>
                    <option>Yearly</option>
                </select>
            `;
            additionalFieldsDiv.appendChild(additionalField3);

            const buttonDiv = document.createElement('div');
            buttonDiv.className = 'd-flex justify-content-center mt-4';

            const button = document.createElement('button');
            button.name = 'add_stwaste';
            button.className = 'btn';
            button.type = 'submit';
            button.textContent = 'Add';

            buttonDiv.appendChild(button);
            additionalFieldsDiv.appendChild(buttonDiv);
        }

        // Show the additionalFieldsDiv if any additional dropdowns are added
        additionalFieldsDiv.style.display = additionalFieldsDiv.innerHTML ? 'block' : 'none';
    }
</script>

