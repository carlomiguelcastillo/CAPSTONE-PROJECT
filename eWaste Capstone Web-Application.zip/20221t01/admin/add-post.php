<?php
include('../authentication.php');
$page_title = "Add Article";
include('../includes/header.php');
include('../includes/navbar.php');
include('../dbcon.php');

if($_SESSION['user_type'] != 'super_admin' && $_SESSION['user_type'] != 'org') 
{
    header("Location: /ewaste/error.html");
}

//$csrf_token = $_SESSION['csrf_token'];

if(isset($_POST['create_post']))
{
    $file = $_FILES['file'];

    // Check if a file was uploaded
    if (!empty($file['name'])) {
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];
        $fileType = $file['type'];

        $fileExt = explode('.', $fileName);
        $fileActualExt = strtolower(end($fileExt));

        $allowed = array('jpeg', 'jpg', 'png');

        // Validate the uploaded file if it exists
        if (in_array($fileActualExt, $allowed)) {
            if ($fileError === 0) {
                if ($fileSize < 10000000) {
                    $fileDestination = 'uploads/'.$fileName;
                    move_uploaded_file($fileTmpName, $fileDestination);
                } else {
                    $_SESSION['status-error'] = "File size is too large";
                    header("Location: add-post.php");
                    exit(0);
                }
            } else {
                $_SESSION['status-error'] = "Error uploading the file";
                header("Location: add-post.php");
                exit(0);
            }
        } else {
            $_SESSION['status-error'] = "Invalid file type. Only JPEG, JPG, and PNG files are allowed";
            header("Location: add-post.php");
            exit(0);
        }
    } else {
        // Set a default file name or handle the case where no file was uploaded
        $fileName = null; // Change this line according to your needs
    }

    $title = $_POST['title'];
    $category = $_POST['category'];
    $link = $_POST['link'];
    //$c_token = $_POST['csrf_token'];

    if(strlen($title) < 5)
    {
        $_SESSION['status-error'] = "Error";
        header("Location: add-post.php");
        exit(0);
    }

    $query = "INSERT INTO posts (title, category, link, featuredimg) VALUES (?, ?, ?, ?)";
    $query_stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($query_stmt, "ssss", $title, $category, $link, $fileName);
    $query_run = mysqli_stmt_execute($query_stmt);

    $_SESSION['action'] = "Added post";

    $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        header('location: view-post.php');
    }
    else
    {
        $_SESSION['status-error'] = "Error";
        header('location: add-post.php');
    }
}


?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Article</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="css/create-admin.css">
</head>
<body>
    <div class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="alert">
                        <?php
                            if(isset($_SESSION['status-error']))
                            {
                                echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                                unset($_SESSION['status-error']);
                            }
                            if(isset($_SESSION['status']))
                            {
                                echo '<h4>' . $_SESSION['status'] . '</h4>';
                                unset($_SESSION['status']);
                            }
                        ?>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h3><b><center>Add Article/News</center></b></h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="add-post.php" enctype="multipart/form-data">
                                <div class="modal-body">
                                    <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  
                                    <div class="form-group mb-3">
                                        <label>Title</label>
                                        <input type="text" name="title" class="form-control" placeholder="Enter Title" required>
                                    </div>
                                    <div class="form-group  mb-3">
                                        <label>Category</label>
                                        <select name="category" class="form-control" required> 
                                                <option value="">Select one...</option>
                                                <option value="About Food Waste">What's Food Waste?</option>
                                                <option value="Ways to Prevent Food Waste">Ways to Prevent Food Waste</option>
                                                <option value="News about Food Waste">News about Food Waste</option>
                                                <option value="Others">Others</option>
                                        </select>
                                    </div>
                                    <div class="form-group mb-3">
                                        <label>Link/ URL</label>
                                        <input type="text" name="link" class="form-control" placeholder="Enter Link/ URL" required>
                                    </div>
                                    <div class="col-6 mb-2">
                                        <p>Fetaured Image</p>
                                        <input type="file" name="file" class="box" >
                                    </div>   
                                </div>

                                <div class="modal-footer">
                                    <button type= "submit" name="create_post" class= "btn"> Save </button> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>            
    </div>
</body>
</html>

