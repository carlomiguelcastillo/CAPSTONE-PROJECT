<?php
$page_title = "Org Audit Trail";
include('../authentication.php');
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php'); 

if($_SESSION['user_type'] != 'super_admin' AND $_SESSION['user_type'] != 'sub_admin') 
{
    header("Location: ../error.html");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Trailing</title>
    <link rel="stylesheet" href="./fontawesome/css/all.min.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <script src="./js/jquery-3.6.0.min.js"></script>
    <script src="./js/popper.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./DataTables/datatables.min.css">
    <script src="./DataTables/datatables.min.js"></script>
    <script src="./fontawesome/js/all.min.js"></script>
    <script src="./js/script.js"></script>
    <style>
        .table-fixed {
        width: 100%;
        overflow-y: auto;
        height: 600px;
        table-layout: auto; /* change to auto */
    }
    
    .table-fixed thead th {
        position: sticky;
        top: 0;
        z-index: 1;
        background-color: #FFF;
        border-bottom: 2px solid #dee2e6; /* new */
    }
    
    .table-fixed tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.075);
    }
    
    .table-fixed tbody td {
        padding-top: 8px;
        padding-bottom: 8px;
    }
    
    /* new styles for Audit Trail and Refresh List */
    .audit-trail-container {
        position: fixed;
        top: 70px;
        left: 10%;
        right: 10%;
        background-color: #FFF;
        padding: 10px;
        z-index: 1;
    }
    
    .audit-trail-container .audit-trail {
        font-size: 28px;
        font-weight: bold;
    }
    
    .audit-trail-container .refresh-list {
        margin-left: 10px;
        font-size: 20px;
    }
    
    /* adjust top padding of main container to compensate for fixed container */
    .main-container {
        padding-top: 110px;
    }
    
    .refresh-list {
        margin: 0 auto;
        display: block;
    }
    
    thead th {
        border: none;
    }
    
    /* Adjust font-size */
    table.table {
        font-size: 18px;
        width: 100%;
    }
    
    .audit-trail-container .ml-auto {
        margin-left: auto;
        margin-right: 0;
    }
    
    table.table thead th {
        padding: 8px 10px; /* adjust padding */
        text-align: center; /* set text alignment */
    }
    
    table.table td {
        white-space: nowrap; /* prevent line break */
    }
    
    table.table th:nth-child(1),
    table.table td:nth-child(1) {
        width: 3.5%; /* set width for first column */
    }
    
    table.table th:nth-child(2),
    table.table td:nth-child(2) {
        width: 13.3%; /* set width for second column */
    }
    
    table.table th:nth-child(3),
    table.table td:nth-child(3) {
        width: 6.7%; /* set width for third column */
    }
    
    table.table th:nth-child(4),
    table.table td:nth-child(4) {
        width: 11.5%; /* set width for fourth column */
    }
    
    table.table th:nth-child(5),
    table.table td:nth-child(5) {
        width: 17%; /* set width for fifth column */
    }
    
    table.table th:nth-child(6),
    table.table td:nth-child(6) {
        width: 10%; /* set width for sixth column */
    }
    
    table.table th:nth-child(7),
    table.table td:nth-child(7) {
        width: 27.5;
    }

    .pagination-container {
        position: absolute;
        bottom: -60px;
        right: -1px;
    }
</style>

</head>

<body class="bg-light">
    <div class="audit-trail-container">
        <div class="d-flex">
            <div class="audit-trail">Audit Trail For Organizations</div>
            <div class="ml-auto">
                <button class="btn btn-sm btn-primary rounded-0 refresh-list" type="button" onclick="location.reload()">
                    <i class="fa fa-retweet"></i> Refresh List
                </button>
            </div>
        </div>
        <hr>
        <div class="container main-container py-5">
            <div class="card">
                <div class="card-body table-fixed">
                    <div class="table-responsive">
                        <div class="thead-container">
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th class="py-1 px-2">#</th>
                                        <th class="py-1 px-2">DateTime</th>
                                        <th class="py-1 px-2">User ID</th>
                                        <th class="py-1 px-2">Username</th>
                                        <th class="py-1 px-2">Email</th>
                                        <th class="py-1 px-2">User Type</th>
                                        <th class="py-1 px-2">Action Made</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <div class="tbody-container">
                            <table class="table table-bordered table-striped table-hover">
                                <tbody>
                                    <?php 
                                        // Define the number of rows to show per page
                                        $rows_per_page = 15;
                                            
                                        // Calculate the total number of rows in the table
                                        $total_rows_query = "SELECT COUNT(*) FROM orglog";
                                        $total_rows_result = mysqli_query($con, $total_rows_query);
                                        $total_rows = mysqli_fetch_array($total_rows_result)[0];
                                        
                                        // Calculate the total number of pages
                                        $total_pages = ceil($total_rows / $rows_per_page);
                                        
                                        // Get the current page number
                                        if (isset($_GET['page'])) {
                                            $current_page = $_GET['page'];
                                        } else {
                                            $current_page = 1;
                                        }
                                        
                                        // Calculate the offset for the SQL query
                                        $offset = ($current_page - 1) * $rows_per_page;

                                        $query = "SELECT * from orglog ORDER BY date_created DESC LIMIT $offset, $rows_per_page";
                                        $query_run = mysqli_query($con, $query);
                                        $i = $offset + 1;
                                        while($row = mysqli_fetch_assoc($query_run)):
                                    ?>
                                    <tr>
                                        <td class="py-1 px-2"><?php echo $i++ ?></td>
                                        <td class="py-1 px-2"><?php echo date("M d, Y H:i",strtotime($row['date_created'])) ?></td>
                                        <td class="py-1 px-2"><?php echo $row['user_id'] ?></td>
                                        <td class="py-1 px-2"><?php echo $row['username'] ?></td>
                                        <td class="py-1 px-2"><?php echo $row['email'] ?></td>
                                        <td class="py-1 px-2"><?php echo $row['user_type'] ?></td>
                                        <td class="py-1 px-2"><?php echo $row['action_made'] ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                    <?php if($query_run->num_rows <=0): ?>
                                    <tr>
                                        <th class="tex-center" colspan="4">No data to display.</th>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="pagination-container">
                    <ul class="pagination">
                        <?php
                            $start_page = max(1, $current_page - 4);
                            $end_page = min($total_pages, $start_page + 7);

                            if ($start_page > 1) {
                                echo '<li class="page-item"><a class="page-link" href="?page=1">&laquo; First</a></li>';
                            }

                            for ($page = $start_page; $page <= $end_page; $page++) {
                                echo '<li class="page-item ';
                                if ($page == $current_page) echo 'active';
                                echo '"><a class="page-link" href="?page=' . $page . '">' . $page . '</a></li>';
                            }

                            if ($end_page < $total_pages) {
                                echo '<li class="page-item"><a class="page-link" href="?page=' . ($end_page + 1) . '">Next &raquo;</a></li>';
                            }
                        ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>