<?php
include('../authentication.php');
$page_title = "Add Admin";
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php');

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: /ewaste/error.html");
}

$csrf_token = $_SESSION['csrf_token'];

if(isset($_POST['create_admin']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $user_type = $_POST['user_type'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];
    $c_token = $_POST['csrf_token'];

    $specialChars = preg_match('@[^\w]@', $username);
    $specialChars_password = preg_match('@[^\w]@', $password);

    $check_email_query = "SELECT email FROM admin WHERE email = ? LIMIT 1";
    $stmt = $con->prepare($check_email_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_email_query_run = $stmt->get_result();

    $check_username_query = "SELECT username FROM admin WHERE username = ? LIMIT 1";
    $stmt = $con->prepare($check_username_query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $check_username_query_run = $stmt->get_result();

    // Resto and Org

    $check_email_query_resto = "SELECT email FROM userResto WHERE email = ? LIMIT 1";
    $stmt = $con->prepare($check_email_query_resto);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_email_query_resto_run = $stmt->get_result();

    $check_email_query_org = "SELECT email FROM userOrg WHERE email = ? LIMIT 1";
    $stmt = $con->prepare($check_email_query_org);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_email_query_org_run = $stmt->get_result();

    $check_username_query_resto = "SELECT username FROM userResto WHERE username = ? LIMIT 1";
    $stmt = $con->prepare($check_username_query_resto);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $check_username_query_resto_run = $stmt->get_result();

    $check_username_query_org = "SELECT username FROM userOrg WHERE username = ? LIMIT 1";
    $stmt = $con->prepare($check_username_query_org);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $check_username_query_org_run = $stmt->get_result();

    $validate_email = preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email);


    if(mysqli_num_rows($check_username_query_run) > 0 OR mysqli_num_rows($check_username_query_resto_run) > 0 OR mysqli_num_rows($check_username_query_org_run) > 0)
    {
        $_SESSION['status-error'] = "Username already exists";
        header("Location: create-admin"); 
        exit(0);
    }

    if(strlen($username) < 5 OR $specialChars)
    {
        $_SESSION['status-error'] = "Username must be at least 5 characters with no special characters";
        header("Location: create-admin"); 
        exit(0);
    }

    if(mysqli_num_rows($check_email_query_run) > 0 OR mysqli_num_rows($check_email_query_resto_run) > 0 OR mysqli_num_rows($check_email_query_org_run) > 0)
    {
        $_SESSION['status-error'] = "Email already exists";
        header("Location: create-admin"); 
        exit(0); 
    } 

    if(!$validate_email)
    {
        $_SESSION['status-error'] = "Invalid email";
        header("Location: create-admin"); 
        exit(0);
    }

    if(strlen($password) < 8 OR ctype_upper($password) OR ctype_lower($password) OR !$specialChars_password) 
    {
        $_SESSION['status-error'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character.";
        header("Location: create-admin"); 
        exit(0);
    }

    if($password != $confirmpassword)
    {
        $_SESSION['status-error'] = "Password and confirm password must match.";
        header("Location: create-admin"); 
        exit(0);
    }
    else
    { 
        $stmt = mysqli_prepare($con, "INSERT INTO admin (username, email, password, user_type) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $password, $user_type);
        $query_run = mysqli_stmt_execute($stmt);

        $data = "SELECT MAX(id) AS id FROM admin WHERE email = '$email'"; //gets latest id from admin tbl
        $data_run = mysqli_query($con, $data);
        $row_data = mysqli_fetch_array($data_run);
        $admin_id = $row_data['id'];

        $_SESSION['action'] = "Created Sub Admin Account (ID: $admin_id)";

        $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($query_run && $log_query_run)
        {
            header('location: view-admin');
        }
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin - Super Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="css/create-admin.css">
</head>
<body>
    <div class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="alert">
                        <?php
                            if(isset($_SESSION['status-error']))
                            {
                                echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                                unset($_SESSION['status-error']);
                            }
                        ?>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h3><b><center>Add Sub Admin</center></b></h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" >
                                <div class="modal-body">
                                    <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  
                                    <div class="form-group mb-3">
                                        <label>Username</label>
                                        <input type="text" name="username" class="form-control" placeholder="Enter Username" required>
                                    </div>
                                    <div class="form-group  mb-3">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                                    </div>
                                    <div class="form-group  mb-3">
                                        <label>Admin Type</label>
                                        <select name="user_type" class="form-control" required> 
                                                <option value="">Select one...</option>
                                                <option value="sub_admin">Sub Admin</option>
                                        </select>
                                    </div>

                                    <div class="form-group  mb-3">
                                        <label>Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Enter Password" id="id_password" required>
                                        <i class="far fa-eye" id="togglePassword"></i>
                                    </div>

                                    <div class="form-group  mb-3">
                                        <label>Confirm Password</label>
                                        <input type="password" name="confirmpassword" class="form-control" placeholder="Confirm Password"  id="id_confirmpassword" required>
                                        <i class="far fa-eye" id="toggleconfirmPassword"></i>
                                    </div>
                                </div>

                                <div class="modal-footer">
                                    <button type= "submit" name="create_admin" class= "btn"> Save </button> 
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>            
    </div>
</body>
</html>

<script>
    const togglecurrentPassword = document.querySelector('#togglePassword');
    const currentpassword = document.querySelector('#id_password');

    togglecurrentPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = currentpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        currentpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>