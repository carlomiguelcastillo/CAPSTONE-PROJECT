<?php 
$page_title = "Dashboard";
include('authentication.php');
include '../includes/header.php';
include '../includes/navbar.php';
include('dbcon.php'); 

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: /ewaste/error.html");
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
	<title>Dashboard</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<style>
		body {
			background: #DCDCDC;
		}
		.card {
			box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
			transition: 0.3s;
			margin: 10px;
			text-align: center;
			padding: 10px;
		}
		.card:hover {
			box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
		}
		.card-title {
			font-size: 24px;
			font-weight: bold;
			margin-bottom: 20px;
		}
		.card-body {
			font-size: 36px;
			font-weight: bold;
		}
        .row.align-items-center {
            height: 50vh;
            transform: translateY(50%);
        }
	</style>
</head>
<body>
	<div class="row mx-auto justify-content-center align-items-center">
		<div class="col-md-3">
			<a href="view-admin" style="text-decoration: none; color: black;">
				<div class="card">
					<div class="card-title">Total # of Admin Users</div>
					<div class="card-body">
						<?php
							$query = "SELECT SUM(CASE WHEN user_type = 'super_admin' THEN 1 ELSE 0 END) AS total_super_admin,
							SUM(CASE WHEN user_type = 'sub_admin' THEN 1 ELSE 0 END) AS total_sub_admin
							FROM admin";
							$result = mysqli_query($con, $query);

							if($result) {
							$row = mysqli_fetch_assoc($result);
							$total_admin_users = $row['total_super_admin'] + $row['total_sub_admin'];
							echo $total_admin_users; 
							} else {
							echo "Error: " . mysqli_error($con);
							}

						?>
					</div>
				</div>
			</a>
		</div>
		<div class="col-md-3">
			<a href="view-resto" style="text-decoration: none; color: black;">
				<div class="card">
					<div class="card-title">Total # of Resto Users</div>
					<div class="card-body">
						<?php
							$query = "SELECT COUNT(*) AS total FROM userresto WHERE user_type='resto'";
							$result = mysqli_query($con, $query);
						
							if($result) {
								$row = mysqli_fetch_assoc($result);
								$total_resto_users = $row['total'];
								echo $total_resto_users; 
							} else {
								echo "Error: " . mysqli_error($con);
							}
						?>
					</div>
				</div>
			</a>
		</div>
		<div class="col-md-3">
			<a href="view-org" style="text-decoration: none; color: black;">
				<div class="card">
					<div class="card-title">Total # of Org Users</div>
					<div class="card-body">
						<?php
							$query = "SELECT COUNT(*) AS total FROM userorg WHERE user_type='org'";
							$result = mysqli_query($con, $query);
						
							if($result) {
								$row = mysqli_fetch_assoc($result);
								$total_org_users = $row['total'];
								echo $total_org_users; 
							} else {
								echo "Error: " . mysqli_error($con);
							}
						?>
					</div>
				</div>
			</a>
		</div>
		<div class="col-md-3">
			<a href="view-waste" style="text-decoration: none; color: black;">
				<div class="card">
					<div class="card-title">Total # of Wastes & Surplus Inputs</div>
					<div class="card-body">
						<?php
							$query = "SELECT 
							(SELECT COUNT(*) FROM waste) AS waste_count,
							(SELECT COUNT(*) FROM surplus) AS surplus_count,
							(SELECT COUNT(*) FROM recwaste) AS recwaste_count,
							(SELECT COUNT(*) FROM reswaste) AS reswaste_count,
							(SELECT COUNT(*) FROM stwaste) AS stwaste_count,
							(SELECT COUNT(*) FROM waste) + 
							(SELECT COUNT(*) FROM surplus) + 
							(SELECT COUNT(*) FROM recwaste) + 
							(SELECT COUNT(*) FROM reswaste) + 
							(SELECT COUNT(*) FROM stwaste) AS total;
							";
							$result = mysqli_query($con, $query);

							if($result) {
								$row = mysqli_fetch_assoc($result);
								$total_food_waste_records = $row['total'];
								echo $total_food_waste_records; 
							} else {
								echo "Error: " . mysqli_error($con);
							}
						?>
					</div>
				</div>
			</a>
		</div>
	</div>
</body>
</html>