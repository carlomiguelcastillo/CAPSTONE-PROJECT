<?php
include('../authentication.php');
include('dbcon.php');

$query = "SELECT * FROM posts";
$query_run = mysqli_query($con, $query);

if(isset($_POST['deletepost']))
{
    $id = $_POST['deletepost_id']; //getting from url

    $query = "DELETE FROM posts WHERE title = '$id'";
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted Post (ID: $id)";

    $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run) 
    {
        echo '<script> alert("Post Deleted"); </script>';
        header('location:view-post');
    }
    else
    {
        echo '<script> alert("Post Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}

?>