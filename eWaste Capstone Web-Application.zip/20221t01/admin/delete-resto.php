<?php
include('../authentication.php');
include('dbcon.php'); 


if(isset($_POST['deleterestodata']))
{
    $id = $_POST['deleteresto_id']; //getting from url

    $query = "DELETE FROM waste WHERE resto_id = $id";
    $query2 = "DELETE FROM userResto WHERE resto_id = $id";
    $query_run = mysqli_query($con, $query);
    $query_run2 = mysqli_query($con, $query2);

    $_SESSION['action'] = "Deleted Restaurant Account (ID: $id)";

    $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $log_query_run = mysqli_query($con, $log_query);

    if($query_run AND $query_run2 AND $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location:view-resto');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}
