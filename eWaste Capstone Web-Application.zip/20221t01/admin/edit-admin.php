<?php 
include('../authentication.php');
$page_title = "Edit Admin";
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php');

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: ../error.html");
}

$id = $_GET['updateid']; // GET id from link
$query = "SELECT * FROM admin WHERE id=$id";
$query_run = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($query_run);
$username = $row['username'];
$email = $row['email'];
$password = $row['password'];

if(isset($_POST['update_admin']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];

    $number = preg_match('@[0-9]@', $password);

    $specialChars_username = preg_match('@[^\w]@', $username);
    $specialChars = preg_match('@[^\w]@', $password);

    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);

    $check_email_query = "SELECT email FROM admin WHERE email = '$email' LIMIT 1";
    $check_email_query_run = mysqli_query($con, $check_email_query);

    $check_username_query = "SELECT username FROM admin WHERE username = '$username' LIMIT 1";
    $check_username_query_run = mysqli_query($con, $check_username_query);

    $validate_email = preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email);

        // Resto and Org

        $check_email_query_resto = "SELECT email FROM userResto WHERE email = '$email' LIMIT 1";
        $check_email_query_resto_run = mysqli_query($con, $check_email_query_resto);
    
        $check_email_query_org = "SELECT email FROM userOrg WHERE email = '$email' LIMIT 1";
        $check_email_query_org_run = mysqli_query($con, $check_email_query_org);
    
        $check_username_query_resto = "SELECT username FROM userResto WHERE username = '$username' LIMIT 1";
        $check_username_query_resto_run = mysqli_query($con, $check_username_query_resto);
    
        $check_username_query_org = "SELECT username FROM userOrg WHERE username = '$username' LIMIT 1";
        $check_username_query_org_run = mysqli_query($con, $check_username_query_org);
    
    if(mysqli_num_rows($check_username_query_run) > 1 OR mysqli_num_rows($check_username_query_resto_run) > 0 OR mysqli_num_rows($check_username_query_org_run) > 0)
    {
    $_SESSION['status-error'] = "Username already exists";
    header("Location: edit-admin.php?updateid=$id");
    exit(0);
    }

    if(strlen($username) < 4 OR $specialChars_username)
    {
    $_SESSION['status-error'] = "Username must be at least 5 characters with no special characters";
    header("Location: edit-admin.php?updateid=$id");
    exit(0);
    }
    

    if(mysqli_num_rows($check_email_query_run) > 1 OR mysqli_num_rows($check_email_query_resto_run) > 0 OR mysqli_num_rows($check_email_query_org_run) > 0)
    {
    $_SESSION['status-error'] = "Email already exists";
    header("Location: edit-admin.php?updateid=$id"); 
    exit(0); 
    }

    if(!$validate_email)
    {
    $_SESSION['status-error'] = "Invalid email";
    header("Location: edit-admin.php?updateid=$id");
    exit(0);
    }
    
    if(!empty($password))
    {
        if(strlen($password) < 8 OR !$number OR !$specialChars) 
        {
            $_SESSION['status-error'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character.";
            header("Location: edit-admin.php?updateid=$id");
            exit(0);
        }

        if(!$uppercase OR !$lowercase)
        {
            $_SESSION['status-error'] = "Password must have at least a lowercase letter, and uppercase letter"; 
            header("Location: edit-admin.php?updateid=$id");
            exit(0);
        }

        if($password != $confirmpassword)
        {
            $_SESSION['status-error'] = "Password and confirm password must match.";
            header("Location: edit-admin.php?updateid=$id"); 
            exit(0);
        }
        else
        {
            $query =  "UPDATE admin SET username='$username', email='$email', password='".md5($password)."' WHERE id = $id";
            $query_run = mysqli_query($con, $query); //runs $query

            if($query_run)
            {
                $_SESSION['status'] = "Updated Successfully!";
                header("Location: edit-admin.php?updateid=$id");
                exit(0);
            }
            else{
                $_SESSION['status-error'] = "Error";
                header("Location: edit-admin.php?updateid=$id");
                exit(0);
            }
        }
    }

    if (mysqli_num_rows($check_username_query_run) < 1 OR strlen($username) > 4 OR !$specialChars_username OR mysqli_num_rows($check_email_query_run) < 1 )
    {
        $query =  "UPDATE admin SET username='$username', email='$email' WHERE id = $id";
        $query_run = mysqli_query($con, $query); //runs $query

        $_SESSION['action'] = "Updated Sub Admin Account (ID: $id)";

        $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($query_run && $log_query_run)
        {
            $_SESSION['status'] = "Updated Successfully!";
            header("Location: edit-admin.php?updateid=$id");
            exit(0);
        }
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin - SuperAdmin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="css/edit-admin.css">
</head>
<body>
    <div class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="alert">
                        <?php
                            if(isset($_SESSION['status']))
                            {
                                echo '<h4 class="success">' . $_SESSION['status'] . '</h4>';
                                unset($_SESSION['status']);
                            }
                            if(isset($_SESSION['status-error']))
                            {
                                echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                                unset($_SESSION['status-error']);
                            }
                        ?>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h3><b><center> Update Admins </center></b></h3>
                        </div>

                        <div class="card-body">
                            <form method="POST">
                                <div class="row">

                                    <div class="col-md-12 mb-3">
                                        <label for="">Username</label>
                                        <input type="text" name="username" class="form-control"  value="<?php echo $username;?>" required>
                                    </div>
                                    
                                    <div class="col-md-12 mb-3">
                                        <label for="">Email</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo $email;?>" required>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="">Password</label>
                                        <input type="password" name="password" class="form-control" placeholder="Enter Password" id="id_password" value="<?php $password;?>">
                                        <i class="far fa-eye" id="togglePassword"></i>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <label for="">Confirm Password</label>
                                        <input type="password" name="confirmpassword" class="form-control" placeholder="Re Enter Password"  id="id_confirmpassword" value="<?php $password;?>">
                                        <i class="far fa-eye" id="toggleconfirmPassword"></i>
                                    </div>

                                    <div class="col-md-12 mb-3">
                                        <button type= "submit" name="update_admin" class= "btn"> Save </button> 
                                    </div>

                                </div>     
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script>
    const togglecurrentPassword = document.querySelector('#togglePassword');
    const currentpassword = document.querySelector('#id_password');

    togglecurrentPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = currentpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        currentpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>


