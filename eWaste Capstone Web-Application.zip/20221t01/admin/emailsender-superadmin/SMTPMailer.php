<?php
use PHPMailer\PHPMailer\PHPMailer;

include './vendor/autoload.php';

class SMTPMailer {
    public function load() {
        //phpmailer
        $mail = new PHPMailer();
        $mail -> isSMTP();
        $mail -> SMTPDebug = 0;
        $mail -> Host = "smtp.gmail.com";
        $mail -> SMTPAuth = TRUE;
        $mail -> isHTML(TRUE);
        $mail -> Username = "randomizerp00p@gmail.com";
        $mail -> Password = "gcqbyavzkpvnzcmb";
        $mail->setFrom('eWaste@mail.com', 'eWaste');
        $mail->SMTPSecure = "tls"; 
        $mail -> Port = "587";
        $mail -> Charset = "utf-8";
        $mail -> From = "thakwanir@gmail.com";
        $mail -> FromName = "eWaste";
        return $mail;

    }
}