<?php
session_start();

if(!isset($_SESSION['authenticated'])) //if not authenticated (!isset)
{
    $_SESSION['status'] = "Please login to access user dashboard";
    header('Location: /ewaaste/login');
    exit(0);
}

?>