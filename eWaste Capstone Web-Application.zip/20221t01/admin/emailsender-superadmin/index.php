<?php 
$page_title = "Send Email";
include 'authentication.php';
include('../../includes/header.php');
include('../../includes/navbar.php');
include('../../dbcon.php'); 
include 'vendor/autoload.php';

if($_SESSION['user_type'] =! 'super_admin') // Restricts resto user from entering page
{
    header("Location: ../error.php");
}
else
{
    $_SESSION['user_type'] = 'super_admin';
}

// Get range data for the current page
$sql = "SELECT resto_id as id, email, username, mobilenum, user_type FROM userresto UNION ALL SELECT id, email, username, mobilenum, user_type FROM userorg";
$users = $con->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title> Email Sender</title>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="plugins/trumbowyg/trumbowyg.min.js" type="text/javascript"></script>
    <script src="main.js" type="text/javascript"></script>
    <link rel="stylesheet" href="/ewaste/css/sendemail.css">
</head>
<body>
    <div class="container-fluid px-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;">List of Users </h4>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" id="checkall" onchange="selectAll()"> Check All
                                </th>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Mobile Number</th>
                                <th>User Type</th>
                            </tr>
                        </thead>
                        <tbody id="alluser">
                            <?php while ($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" value="<?php echo $user['email']; ?>" onclick="updateTextArea();">
                                    </td>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['mobilenum']; ?></td>
                                    <td><?php echo $user['user_type']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="card mb-3" id="compose-card">
            <div class="card-header">
                <button type="button" class="btn btn-link" onclick="toggleForm()">Compose Email</button>
            </div>
            <form action="" method="post" class="msg_container" style="display: none;">   
                <div class="card-body">   
                    <p id="multi-responce"></p> <!-- responce -->
                    <div class="form-group">
                        <textarea class="form-control" id="emails" name="emails"  onchange="updateTextArea()" placeholder="Email list" style="height: 120px;"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject" required>
                    </div>
                    <div class="form-group">
                        <textarea style="height: 220px;" id="message" name="message" class="form-control" placeholder="Your Message" rows="5" required></textarea>
                    </div>
                    <button type="button" name= "sendemail" onclick="multi_email();" class="btn btn-success btn-lg col-lg-12" id="send">Send Now </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

<script>
    function selectAll(){
        let checkboxes = document.getElementsByTagName("input");
        for(let i=0; i < checkboxes.length; i++){
            if(checkboxes[i].type == "checkbox"){
                checkboxes[i].checked = document.getElementById("checkall").checked;
            }
        }
        updateTextArea();
    }

    function toggleForm() {
        var form = document.getElementsByClassName("msg_container")[0];
        if (form.style.display === "none") {
            form.style.display = "block";
        } else {
            form.style.display = "none";
        }
    }
</script>