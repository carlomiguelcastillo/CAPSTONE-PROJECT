<?php
include 'SMTPMailer.php';
include 'authentication.php';
include 'dbcon.php';
$subject = $_POST['subject'];
$email = $_POST['emails'];
$message = $_POST['message'];
$smtp = new SMTPMailer();
$mail = $smtp->load();

foreach (explode(",", $email) as $address) {

    //call phpmailerlibrary class here 
    $mail->addAddress($address, "Hello");
    $mail->Subject = $subject;
    $mail->Body = $message;
    if ($mail->send()) {
        
        $_SESSION['action'] = "Sent email to User/s";

        $log = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log); 

        if($log_query_run)
        {
            echo "Success";
        }

    } else {
        echo $mail->ErrorInfo;
    }
}
?>

