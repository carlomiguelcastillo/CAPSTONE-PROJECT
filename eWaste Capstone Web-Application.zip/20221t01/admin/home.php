<?php 
$page_title = "Home";
include('authentication.php');
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php'); 

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: .../error.html");
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        body {
            background: #DCDCDC;
        }

        .container {
            color: white !important;
            width: 100%;
            padding: 15px;
            border-radius: 20px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .btn {
            background-color: #023020;
            color: #f2f2f2 !important;
            width: 100%;
            height: 200px;
            margin: 10px;
            padding: 20px 15px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            border-radius: 10px;
        }

        .btn i {
            font-size: 45px;
            margin-bottom: 10px;
        }

        .btn span {
            font-size: 1.5rem;
        }

        @media (max-width: 768px) {
            .btn {
                height: 150px;
                font-size: 1rem;
            }
        }

        body::-webkit-scrollbar {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row p-5 text-center">

            <div class="col-3 d-grid">
                <a href="dashboard" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-speedometer" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">Dashboard</span>
                </a>
            </div>

            <div class="col-3 d-grid">
                <a href="al-admin" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi-person-workspace" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">Audit Logs of Admin</span>
                </a>
            </div>
            
            <div class="col-3 d-grid">
                <a href="al-resto" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-buildings" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">Audit Logs of Restos</span>
                </a>
            </div>

            <div class="col-3 d-grid">
                <a href="al-org" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-person-vcard" style="font-size: 45px;;"></i>
                    <span class="fs-5" style="margin-top: 10px;">Audit Logs of Orgs</span>
                </a>
            </div>

            <div class="col-3 d-grid mt-5">
                <a href="view-admin" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-people" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">View Admins</span>
                </a>
            </div>

            <div class="col-3 d-grid mt-5">
                <a href="view-resto" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-eye" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">View Resto Users</span>
                </a>
            </div>

            <div class="col-3 d-grid mt-5">
                <a href="view-org" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-eye-fill" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">View Org Users</span>
                </a>
            </div>

            <div class="col-3 d-grid mt-5">
                <a href="view-waste" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-trash" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">View Wastes</span>
                </a>
            </div>

            <div class="row">
                
                <div class="col-3 d-grid mt-5">
                    <a href="add-post" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                        <i class="bi bi-plus-circle" style="font-size: 45px;"></i>
                        <span class="fs-5" style="margin-top: 10px;">Add Post</span>
                    </a>
                </div>

                <div class="col-3 d-grid mt-5">
                <a href="view-post" class="btn" style="height: 150px; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                    <i class="bi bi-eye" style="font-size: 45px;"></i>
                    <span class="fs-5" style="margin-top: 10px;">View Posts</span>
                </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>