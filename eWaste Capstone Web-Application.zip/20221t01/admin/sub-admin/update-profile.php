<?php
$page_title = "Update Account";
include('../../authentication.php');
include('../../includes/header.php');
include('../../includes/navbar.php');
include('../dbcon.php'); 

if($_SESSION['user_type'] != 'sub_admin') 
{
    header("Location: /ewaste/error.html");
}

$csrf_token = $_SESSION['csrf_token'];
$id = $_GET['updateid']; // GET id from link

$query = "SELECT * FROM admin WHERE id=?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$username = $row['username'];
$email = $row['email'];
$password = $row['password'];

if($id != $_SESSION['auth_user']['id'])
{
    header("Location: /ewaste/error.html");
}

if(isset($_POST['update_profile']))
{
    $submitted_username = $_POST['username'];
    $submitted_email = $_POST['email'];
    $pass = $_POST['pass'];
    $id2 = $_GET['updateid'];
    $update_pass = $_POST['update_pass'];
    $confirmpass = $_POST['confirmpass'];
    $c_token = $_POST['csrf_token'];

    $_SESSION['auth_user']['email'] = $submitted_email;

    $stmt = mysqli_prepare($con, "SELECT * FROM admin WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $id2);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    $number = preg_match('@[0-9]@', $pass);
    $specialChars_username = preg_match('@[^\w]@', $submitted_username);
    $specialChars = preg_match('@[^\w]@', $pass);

    $check_email_query = "SELECT email FROM admin WHERE email = ? LIMIT 1";
    $stmt_email = mysqli_prepare($con, $check_email_query);
    mysqli_stmt_bind_param($stmt_email, "s", $submitted_email);
    mysqli_stmt_execute($stmt_email);
    $check_email_query_run = mysqli_stmt_get_result($stmt_email);

    $check_username_query = "SELECT username FROM admin WHERE username = ? LIMIT 1";
    $stmt_username = mysqli_prepare($con, $check_username_query);
    mysqli_stmt_bind_param($stmt_username, "s", $submitted_username);
    mysqli_stmt_execute($stmt_username);
    $check_username_query_run = mysqli_stmt_get_result($stmt_username);

    $validate_email = preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $submitted_email);

    if(mysqli_num_rows($check_username_query_run) > 0 && $submitted_username != $username)
    {
        $_SESSION['status-error'] = "Username already exists"; // Each username must be unique
        header("Location: /ewaste/admin/update-subprofile/$id2");
        exit(0);
    }

    if(mysqli_num_rows($check_email_query_run) > 0 && $submitted_email != $email)
    {
        $_SESSION['status-error'] = "Email already exists"; 
        header("Location: /ewaste/admin/update-subprofile/$id2");
        exit(0);
    }

    if(strlen($submitted_username) < 5 OR $specialChars_username)
    {
        $_SESSION['status-error'] = "Username must be at least 5 characters with no special characters.";
        header("Location: /ewaste/admin/update-subprofile/$id2"); 
        exit(0);
    }

    if(!$validate_email)
    {
        $_SESSION['status-error'] = "Invalid email";
        header("Location: /ewaste/admin/update-subprofile/$id2"); 
        exit(0);
    }

    if(!empty($update_pass))
    {
        if(md5($update_pass) != $row['password'])
        {
            $_SESSION['status-error'] = "Current password is incorrect"; 
            header("Location: /ewaste/admin/update-subprofile/$id2");
            exit(0);
        }   
    }

    if(!empty($pass))
    {
        if(strlen($pass) < 8 OR ctype_upper($pass) OR ctype_lower($pass) OR !$number OR !$specialChars)
        {
            $_SESSION['status-error'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character"; 
            header("Location: /ewaste/admin/update-subprofile/$id2"); 
            exit(0);
        }

        if($pass != $confirmpass)
        {
            $_SESSION['status-error'] = "Password and Confirm Password does not match"; 
            header("Location: /ewaste/admin/update-subprofile/$id2");
            exit(0);
        }
        else
        {
            $query = "UPDATE admin SET password = ? WHERE id = ?";
            $stmt = mysqli_prepare($con, $query);
            mysqli_stmt_bind_param($stmt, "si", md5($opass), $id);
            $query_run = mysqli_stmt_execute($stmt);

            if($query_run)
            {
                $_SESSION['status'] = "Updated Successfully!"; 
                header("Location: /ewaste/admin/update-subprofile/$id2");
            }
        }
    }

   else{
        $query = "UPDATE admin SET username=?, email=? WHERE id=?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, 'ssi', $submitted_username, $submitted_email, $id);
        $query_run =mysqli_stmt_execute($stmt);
        
        $_SESSION['action'] = "Updated user infromation";

        $log_query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($query_run && $log_query_run)
        {
            $_SESSION['status'] = "Updated Successfully!"; 
            header("Location: /ewaste/admin/update-subprofile/$id2");
            exit(0);
        }
    }
}  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <title>Update Profile - Sub Admin</title>
    <link rel="stylesheet" href="/ewaste/admin/css/update-profile-admin.css">
</head>
<body> 
    <div class="update-profile-superadmin">
        <div class="card">
            <form action="" method="post" enctype="multipart/form-data">
                <?php
                    if(isset($_SESSION['status']))
                    {
                        echo "<h4>" . $_SESSION['status'] . "</h4>";
                        unset($_SESSION['status']);
                    }
                    if(isset($_SESSION['status-error']))
                    {
                        echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                        unset($_SESSION['status-error']);
                    }
                ?>
            <div class="flex">
                <div class="inputBox">
                    <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  
                    <span>Username:</span>
                    <input type="text" name="username" value="<?php echo $username; ?>" class="box" required>
                    <span>Email:</span>
                    <input type="email" name="email" value="<?php echo $email; ?>" class="box" required>
                    <?php echo '<a href="/ewaste/admin/subview-profile" class="btn btn-back" style="text-decoration: none;">Back</a>'; ?> 
                </div>
                <div class="inputBox">
                    <span>Current Password:</span>
                    <div class="password-input">
                        <input type="password" name="update_pass" value="" class="box" placeholder="enter previous password" id="id_currentpassword">
                        <i class="far fa-eye" id="togglecurrentPassword"></i>
                    </div>
                    <span>New Password:</span>
                    <div class="password-input">
                        <input type="password" name="pass" value="" class="box" placeholder="enter new password" id="id_newpassword">
                        <i class="far fa-eye" id="togglenewPassword"></i> 
                    </div>
                    <span>Confirm New Password:</span>
                    <div class="password-input">
                        <input type="password" name="confirmpass" value="" class="box" placeholder="re enter new password" id="id_confirmpassword"> 
                        <i class="far fa-eye" id="toggleconfirmPassword"></i>
                    </div>
                    <button type="submit" name="update_profile" class="btn">Update Profile</button>     
                </div>
            </div>
            </form>       
        </div>
    </div>
</body>
</html>

<script>
    const togglecurrentPassword = document.querySelector('#togglecurrentPassword');
    const currentpassword = document.querySelector('#id_currentpassword');

    togglecurrentPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = currentpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        currentpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const togglenewPassword = document.querySelector('#togglenewPassword');
    const newpassword = document.querySelector('#id_newpassword');

    togglenewPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = newpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        newpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
    
    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>