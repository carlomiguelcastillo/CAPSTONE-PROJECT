<?php 
$page_title = "View Waste";
include('../../authentication.php');
include('../../includes/header.php');
include('../../includes/navbar.php');
include('../dbcon.php'); 

if($_SESSION['user_type'] != 'sub_admin') 
{
    header("Location: ../../logout.php");
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/view-pages.css">  
    <style>
        .card{
            z-index:-1;
        }
    </style>  
</head>
<body>
    <!-- DELETE POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="deletewastemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Food Waste Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="delete-waste.php" method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="deletewaste_id" id="deletewaste_id">

                        <h4> Are you sure you want to delete it? </h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deletewastedata" class="btn btn-primary"> Yes. Delete it. </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container-fluid px-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Wastes Added </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> User ID </th>
                                <th> Waste ID </th>
                                <th> Type of Food </th> 
                                <th> Raw Cost </th>
                                <th> Weight </th>                           
                                <th> Frequency</th>
                                <th> Reason of Wastage </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $query = "SELECT * FROM waste"; // Shows resto users
                                $query_run = mysqli_query($con, $query);

                                if($query_run) //if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {   
                                        $id = $row['id'];  
                                        $userid = $row['resto_id'];                            
                                        $resto_id = $row['resto_id'];
                                        $foodtype = $row['foodtype'];
                                        $rawcost = $row['rawcost'];
                                        $weight = $row['weight']; 
                                        $frequency = $row['frequency'];
                                        $reason = $row['reason'];
                                        $created_at = date("M d, Y H:i",strtotime($row['created_at']));  
                                        if($row['updated_at'] === null) 
                                        {
                                            $row['updated_at'] = " "; 
                                        } else{
                                            $row['updated_at'] = date("M d, Y H:i", strtotime($row['updated_at']));  
                                        }   

                                        $_SESSION['auth_waste'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>
                                        <td scope="row">' . $userid . '</td>
                                        <td scope="row">' . $foodtype . '</td>
                                        <td scope="row">' . $rawcost . '</td>
                                        <td scope="row">' . $weight . '</td>
                                        <td scope="row">' . $frequency . '</td>
                                        <td scope="row">' . $reason . '</td>
                                        <td scope="row">' . $created_at . '</td>
                                        <td scope="row">' . $row['updated_at'] . '</td>
                                        </tr>';
                                    }
                                }
                            ?>
                        </tbody>
                    </table>            
                </div>
            </div>
        </div>
    </div>
</body>
</html>