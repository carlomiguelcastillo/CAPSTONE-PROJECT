<?php 
$page_title = "View Admin";
include('authentication.php');
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php'); 

if($_SESSION['user_type'] != 'super_admin' && $_SESSION['user_type'] != 'org') 
{
    header("Location: /ewaste/error.html");
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Added Articles</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-cfPvX8W6j/Tl6U67PpsU/ZNHl8ru6Mz/xgRyiYRfhjRVZ9XrvZPI+GSqC3Q+znoISjK8xWcLT4fouz4Z4tWKsQ==" crossorigin="anonymous" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet" href="css/view-pages.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/js/all.min.js" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</head>
<body>
    <div class="modal fade" id="deletepostmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Post details </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="delete-post.php" method="POST">
                    <div class="modal-body">

                        <input type="hidden" name="deletepost_id" id="deletepost_id">

                        <h4> Are you sure you want to delete it? </h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deletepost" class="btn btn-primary"> Yes. Delete it. </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container-fluid px-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4> All Posts </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th> 
                                <th> Title </th>
                                <th> Category </th>
                                <th> Link </th>
                                <th> Image </th>
                                <th> Created At </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM posts"; 
                                    $query_run = mysqli_query($con, $query);

                                    if($query_run) //if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($row = mysqli_fetch_assoc($query_run))
                                        {                                 
                                            $id = $row['id'];
                                            $title = $row['title']; 
                                            $category = $row['category']; 
                                            $link= $row['link']; 
                                            $img = $row['featuredimg'];
                                            $created_at = date("M d, Y H:i",strtotime($row['date_created'])); 
                                            echo '<tr>
                                            <th scope="row">' . $id . '</th>
                                            <td>' . $title . '</td>
                                            <td>' . $category . '</td>
                                            <td>' . $link . '</td>
                                            <td><a href="download.php?file=' . $row['featuredimg'] . '">Download</a></td>
                                            <td>' . $created_at . '</td>
                                            <td>
                                                <div class="text-center">
                                                    <span style="display: inline-block;">  
                                                        <button type="button" class="post_del_btn btn btn-danger btn-sm post_btns" data-id="' . $id . '"><i class="fas fa-trash-alt"></i></button>
                                                    </span>
                                                    </div>
                                                </td>
                                            </tr>';
                                        }
                                    } 
                                ?>
                            </tbody>
                    </table>            
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script>
    $(document).ready(function () {

        $('.post_del_btn').on('click', function () {

            $('#deletepostmodal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();

            console.log(data);

            $('#deletepost_id').val(data[0]);

        });
    });
</script>