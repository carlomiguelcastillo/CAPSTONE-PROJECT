<?php 
$page_title = "Account";
include('authentication.php');
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php'); 

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: /ewaste/error.html");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>View Profile</title>
   <link rel="stylesheet" href="/ewaste/admin/css/view-profile-admin.css">
</head>
<body>
   
<div class="card">

   <div class="profile">
      <?php        

        $logged_user = $_SESSION['auth_user']['email'];
        $query = "SELECT * FROM admin WHERE email = '$logged_user'";
        $query_run = mysqli_query($con, $query);

        if($query_run)
        {
            $row = mysqli_fetch_array($query_run);
            $id = $row['id'];
            echo $row['username'];
            echo ', ' . $_SESSION['user_type'];
            echo '<a href="/ewaste/admin/update-profile/' . $id . ' " class="btn">Update Account</a>'; 
        }  
        ?>
         
      <a href="/ewaste/logout.php" class="btn">Logout</a>
   </div>

</div>

</body>
</html>
