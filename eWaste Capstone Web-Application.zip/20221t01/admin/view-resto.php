<?php 
$page_title = "View Resto";
include('../authentication.php');
include('../includes/header.php');
include('../includes/navbar.php');
include('dbcon.php');

if($_SESSION['user_type'] != 'super_admin') 
{
    header("Location: ../error.html");
}

?>

<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/view-pages.css">
</head>
<body>

    <div class="modal fade"  id="deleterestomodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Restaurant details </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="delete-resto.php" method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="deleteresto_id" id="deleteresto_id">

                        <h4> Are you sure you want to delete it? </h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deleterestodata" class="btn btn-primary"> Yes. Delete it. </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container-fluid px-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4> Registered Restaurants </h4>
                </div>

                <div class="card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th> 
                                <th> Full Name </th>
                                <th> Username </th>                           
                                <th> Mobile # </th>
                                <th> Birthday </th>
                                <th> Email </th>
                                <th> Address </th>
                                <th> City </th>                
                                <th> Verified </th>
                                <th> Role </th>
                                <th> Registered Date </th>
                                <th> Actions </th>
                                <th> License </th>
                            </tr>   
                        </thead>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM userResto"; // Shows resto users
                                    $query_run = mysqli_query($con, $query);

                                    if($query_run) //if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($row = mysqli_fetch_assoc($query_run))
                                        {                                 
                                            $id = $row['resto_id'];
                                            $fname = $row['fname'];
                                            $lname = $row['lname'];
                                            $username = $row['username']; 
                                            $mobilenum = $row['mobilenum'];
                                            $birthdate = $row['birthdate'];
                                            $email = $row['email']; 
                                            $raddress = $row['raddress'];
                                            $rcity = $row['rcity'];
                                            $fel = $row['fel'];
                                            $verify_status = $row['verify_status']; 
                                            $user_type = "resto"; 
                                            $created_at = date("M d, Y H:i",strtotime($row['created_at'])); 
                                            
                                            echo '<tr>
                                            <td scope="row">' . $id . '</td>               
                                            <td scope="row">' . $fname, ' ', $lname . '</td>
                                            <td scope="row">' . $username . '</td>
                                            <td scope="row">' . $mobilenum . '</td>
                                            <td scope="row">' . $birthdate . '</td>
                                            <td scope="row">' . $email . '</td>
                                            <td scope="row">' . $raddress . '</td>
                                            <td scope="row">' . $rcity . '</td>
                                            <td scope="row">' . $verify_status . '</td>
                                            <td scope="row">' . $user_type . '</td>
                                            <td scope="row">' . $created_at . '</td>
                                                                        
                                            <td>                                            
                                            <button type="button" class="resto_del_btn btn btn-danger btn-sm admin_btns" data-id="<?php echo $id; ?>"><i class="fas fa-trash-alt"></i></button>
                                            </td> <td>'

                                            ?><a href="download.php?file=<?php echo $row['fel'] ?>">Download <?php
                                            '</td></tr>';
                                        }
                                    } 
                                ?>
                            </tbody>
                    </table>            
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<script>
    $(document).ready(function () {

        $('.resto_del_btn').on('click', function () {

            $('#deleterestomodal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();

            console.log(data);

            $('#deleteresto_id').val(data[0]);

        });
    });
</script>