<?php
session_start();
include('dbcon.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader test
require 'vendor/autoload.php';

function sendemail_verify($username, $email, $verify_token)
{
    $mail = new PHPMailer(true);

    // $mail -> SMTPDebug -2;
    $mail->isSMTP(); //Send using SMTP
    $mail->SMTPAuth = true; //Enable SMTP authentication

    $mail->Host = 'smtp.gmail.com';       //Set the SMTP server to send through
    $mail->Username = 'randomizerp00p@gmail.com';   //SMTP username
    $mail->Password = 'gcqbyavzkpvnzcmb';             //SMTP password

    $mail->SMTPSecure = "tls";              //Enable implicit TLS encryption
    $mail->Port       = 587;

    $mail->setFrom('randomizerp00p@gmail.com', 'eWaste');
    $mail->addAddress($email);  

    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Email verification from eWaste';

    $email_template = 
    "<h2> You have registered with eWaste </h2>
    <h5> Verify your email address with the link given below </h5>
    <br/><br/>
    <a href='http://localhost/eWaste/verify-email.php?token=$verify_token'> Click here </a>
    ";

    $mail->Body = $email_template;
    $mail->send();
    echo 'Message has been sent';
}

if (isset($_POST['registerResto_btn'])) { 
    $file = $_FILES['file'];

    $fileName = $_FILES['file'] ['name'];
    $fileTmpName = $_FILES['file'] ['tmp_name'];
    $fileSize = $_FILES['file'] ['size'];
    $fileError = $_FILES['file'] ['error'];
    $fileType = $_FILES['file'] ['type']; 

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpeg', 'jpg', 'png', 'pdf');

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $mobilenum = $_POST['mobilenum'];
    //$birthdate = $_POST['birthdate'];
    $birthdate = date('Y-m-d', strtotime($_POST['birthdate']));
    $email = $_POST['email'];
    $restoname = $_POST['restoname'];
    $restotype = $_POST['restotype'];
    $region = $_POST['region'];
    $rcity = $_POST['rcity'];
    $barangay = $_POST['barangay'];
    $raddress = $_POST['raddress'];
    $raddress2 = $_POST['raddress2'];
    //$fel = $_POST['fel'];
    $rpass = $_POST['rpass'];
    $rconfirmpass = $_POST['rconfirmpass'];
    $verify_token = md5(rand());

    $number_fname = preg_match('@[0-9]@', $fname);
    $number_lname = preg_match('@[0-9]@', $lname);
    $number_restoname = preg_match('@[0-9]@', $restoname);
    $number_address = preg_match('@[0-9]@', $raddress);
    $number = preg_match('@[0-9]@', $rpass);

    $specialChars_fname = preg_match('@[^\w\s]@', $fname);
    $specialChars_lname = preg_match('@[^\w\s]@', $lname);
    $specialChars_username = preg_match('@[^\w]@', $username);
    $specialChars_restoname = preg_match('@[^\w\s]@', $restoname);
    //$specialChars_address = preg_match('@[^\w\s]@', $raddress);
    $specialChars = preg_match('@[^\w]@', $rpass);

    $validatephone = preg_match('/^(09[0-9]{9})$/', $mobilenum);
    $validate_address = preg_match('/^(?![0-9]+$)[a-zA-Z0-9\s.\-\/]+$/i', $raddress);
    $validate_email = preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email);

    $uppercase = preg_match('@[A-Z]@', $rpass);
    $lowercase = preg_match('@[a-z]@', $rpass);

    $stmt = $con->prepare("SELECT email FROM userResto WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_email_query_run = $stmt->get_result();
    
    $stmt2 = $con->prepare("SELECT email FROM userOrg WHERE email = ? LIMIT 1");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $check_email_query_run_2 = $stmt2->get_result();
    
    $stmt3 = $con->prepare("SELECT username FROM userResto WHERE username = ? LIMIT 1");
    $stmt3->bind_param("s", $username);
    $stmt3->execute();
    $check_username_query_run = $stmt3->get_result();
    
    $stmt4 = $con->prepare("SELECT username FROM userOrg WHERE username = ? LIMIT 1");
    $stmt4->bind_param("s", $username);
    $stmt4->execute();
    $check_username_query_run_2 = $stmt4->get_result();
    
    $stmt5 = $con->prepare("SELECT mobilenum FROM userResto WHERE mobilenum = ? LIMIT 1");
    $stmt5->bind_param("s", $mobilenum);
    $stmt5->execute();
    $check_mobilenum_query_run = $stmt5->get_result();
    
    $stmt6 = $con->prepare("SELECT mobilenum FROM userOrg WHERE mobilenum = ? LIMIT 1");
    $stmt6->bind_param("s", $mobilenum);
    $stmt6->execute();
    $check_mobilenum_query_run_2 = $stmt6->get_result();

    function is_insecure_password($password) {
        $insecure_patterns = [
            "/\bOR\b/i",
            "/\bDROP\b/i",
            "/;/",
            "/<script>/i"
        ];
    
        foreach ($insecure_patterns as $pattern) {
            if (preg_match($pattern, $password)) {
                return true;
            }
        }
    
        return false;
    }

    $city_names = array(
        '133902' => 'Binondo',
        '137501' => 'Caloocan',
        '137601' => 'Las Piñas',
        '137602' => 'Makati',
        '137502' => 'Malabon',
        '137401' => 'Mandaluyong',
        '137402' => 'Marikina',
        '137603' => 'Muntinlupa',
        '137503' => 'Navotas',
        '137604' => 'Parañaque',
        '137403' => 'Pasig',
        '137405' => 'San Juan',
        '137504' => 'Valenzuela',
        '133908' => 'Ermita',
        '133909' => 'Intramuros',
        '133910' => 'Malate',
        '133911' => 'Paco',
        '133912' => 'Pandacan',
        '137605' => 'Pasay',
        '137606' => 'Pateros',
        '133913' => 'Port Area',
        '137404' => 'Quezon City',
        '133903' => 'Quiapo',
        '133933' => 'Sampaloc',
        '133907' => 'San Miguel',
        '133904' => 'San Nicolas',
        '133914' => 'Santa Ana',
        '133905' => 'Santa Cruz',
        '137607' => 'Taguig City',
        '133901' => 'Tondo I / II'
    );

    if (isset($city_names[$rcity])) {
        $city = $city_names[$rcity];
    } else {
        $city = ''; // Set a default value or handle the case when the city code is not found
    }
    
    if(strlen($fname) < 2 OR strlen($lname) < 2)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;

        $_SESSION['status'] = "First and Last name must at least have 2 or more characters.";
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if($number_fname OR $number_lname OR $specialChars_fname OR $specialChars_lname)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;

        $_SESSION['status'] = "First and Last name must only be letters.";
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if(mysqli_num_rows($check_username_query_run) > 0 OR mysqli_num_rows($check_username_query_run_2) > 0)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;

        $_SESSION['status'] = "Username already exists"; // Each username must be unique
        header("Location: /ewaste/register-restaurant");
        exit(0);
    }

    if(strlen($username) < 5 OR $specialChars_username)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Username must be at least 5 characters with no special characters.";
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if(mysqli_num_rows($check_mobilenum_query_run) > 0 OR mysqli_num_rows($check_mobilenum_query_run_2) > 0)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Phone number already exists"; // Each username must be unique
        header("Location: /ewaste/register-restaurant");
        exit(0);
    }

    if(!$validatephone)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Phone number must be 11 digits and start with 09"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if($birthdate > '2005-01-01')
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;

        $_SESSION['status'] = "Users must be 18 years old or older."; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }
    
    if(mysqli_num_rows($check_email_query_run) > 0 OR mysqli_num_rows($check_email_query_run_2) > 0)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Email already exists"; // 1 EMAIL = 1 USER ROLE Ex: ab@yahoo.com is Resto but CANNOT be Org and VICE VERSA
        header("Location: /ewaste/register-restaurant");
        exit(0);
    }

    if($number_restoname OR $specialChars_restoname OR strlen($restoname) < 2)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
           
        $_SESSION['status'] = "Invalid Restaurant Name"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if(!$number_address OR !$validate_address OR strlen($raddress) < 5)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Invalid Address"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }
 
    if(is_insecure_password($rpass))
    {
        $_SESSION['status'] = "Invalid password"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if(strlen($rpass) < 8 OR !$number OR !$specialChars)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }
    
    if(!$uppercase OR !$lowercase)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Password must have at least a lowercase letter, and uppercase letter"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if(!$validate_email)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;

        $_SESSION['status'] = "Invalid Email";
        header("Location: /ewaste/register-restaurant");
        exit(0);
    }

    if($rpass != $rconfirmpass)
    {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        $_SESSION['status'] = "Password and Confirm Password does not match"; 
        header("Location: /ewaste/register-restaurant"); 
        exit(0);
    }

    if (in_array($fileActualExt, $allowed)) {
        $_SESSION['fname'] = $fname;
        $_SESSION['lname'] = $lname;
        $_SESSION['username-register-resto'] = $username;
        $_SESSION['mobilenum'] = $mobilenum;
        $_SESSION['restoname'] = $restoname;
        $_SESSION['birthdate'] = $birthdate;
        $_SESSION['email'] = $email;
        $_SESSION['raddress'] = $raddress;
        $_SESSION['rpass'] = $rpass;
        $_SESSION['restotype'] = $restotype;
        $_SESSION['rcity'] = $rcity;
        
        if ($fileError === 0) {
            if ($fileSize < 10000000) {
                $fileNameNew = uniqid('', true).".".$fileActualExt;
                $fileDestination = 'admin/uploads/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);

                $user_type = 'resto';
                $stmt = $con->prepare("INSERT INTO userResto (fname, lname, username, mobilenum, birthdate, email, restoname, restotype, region, barangay, rcity, raddress, raddress2, fel, rpass, verify_token, user_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssssssssssssss", $fname, $lname, $username, $mobilenum, $birthdate, $email, $restoname, $restotype, $region, $barangay, $rcity, $raddress, $raddress2, $fileNameNew, md5($rpass), $verify_token, $user_type);
                $query_run = $stmt->execute();

                $resto_data = "SELECT resto_id, username, email FROM userResto WHERE username = '$username' AND email = '$email'";
                $resto_data_run = mysqli_query($con, $resto_data);
                $row = mysqli_fetch_array($resto_data_run);
                $resto_id = $row['resto_id'];

                $_SESSION['action'] = "Created an account.";

                $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('$resto_id', '$username', '$email', 'resto', '{$_SESSION['action']}')";
                $log_query_run = mysqli_query($con, $log_query);
    
                    if($query_run && $log_query)
                    {   
                        sendemail_verify("$username", "$email", "$verify_token");
                        $_SESSION['status'] = "Registration successful! Please verify your email address.";
                        header("Location: /ewaste/login");

                        unset($_SESSION['fname']);
                        unset($_SESSION['lname']);
                        unset($_SESSION['username-register-resto']);
                        unset($_SESSION['mobilenum']);
                        unset($_SESSION['restoname']);
                        unset($_SESSION['birthdate']);
                        unset($_SESSION['email']);
                        unset($_SESSION['raddress']);
                        unset($_SESSION['rpass']);
                        unset($_SESSION['restotype']);
                        unset($_SESSION['rcity']);

                    }
                    else
                    {
                        $_SESSION['status'] = "Registration failed";
                        header("Location: /ewaste/register-restaurant");
                    }
            }
        }
    }
    else
    {
        $_SESSION['status'] = "Food Establishment License must be jpeg, jpg, png, or pdf files";
        header("Location: /ewaste/register-restaurant");
        exit(0);
    }
}

if (isset($_POST['registerOrg_btn'])) {
    $file = $_FILES['file'];

    $fileName = $_FILES['file'] ['name'];
    $fileTmpName = $_FILES['file'] ['tmp_name'];
    $fileSize = $_FILES['file'] ['size'];
    $fileError = $_FILES['file'] ['error'];
    $fileType = $_FILES['file'] ['type']; 

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpeg', 'jpg', 'png', 'pdf');

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $mobilenum = $_POST['mobilenum'];
    $birthdate = date('Y-m-d', strtotime($_POST['birthdate']));
    $email = $_POST['email'];
    $orgName = $_POST['orgName'];
    $services = $_POST['services'];
    $desc = $_POST['desc'];
    $region = $_POST['region'];
    $ocity = $_POST['city'];
    $barangay = $_POST['barangay'];
    $offAddress = $_POST['offAddress'];
    $offAddress2 = $_POST['offAddress2'];
    $services = $_POST['services'];
    $opass = $_POST['opass'];
    $oconfirmpass = $_POST['oconfirmpass'];
    $verify_token = md5(rand());

    $number_fname = preg_match('@[0-9]@', $fname);
    $number_lname = preg_match('@[0-9]@', $lname);
    $number_orgName = preg_match('@[0-9]@', $orgName);
    $number_address = preg_match('@[0-9]@', $offAddress);
    $number = preg_match('@[0-9]@', $opass);

    $specialChars_fname = preg_match('@[^\w\s]@', $fname);
    $specialChars_lname = preg_match('@[^\w\s]@', $lname);
    $specialChars_username = preg_match('@[^\w]@', $username);
    $specialChars_orgName = preg_match('@[^\w\s]@', $orgName);
    //$specialChars_address = preg_match('@[^\w\s]@', $offAddress);
    $specialChars = preg_match('@[^\w]@', $opass);

    $uppercase = preg_match('@[A-Z]@', $opass);
    $lowercase = preg_match('@[a-z]@', $opass);

    $validatephone = preg_match('/^(09[0-9]{9})$/', $mobilenum);
    $validate_address = preg_match('/^(?![0-9]+$)[a-zA-Z0-9\s.\-\/]+$/i', $offAddress);
    $validate_email = preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email);

    $stmt = $con->prepare("SELECT email FROM userResto WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_email_query_run = $stmt->get_result();
    
    $stmt2 = $con->prepare("SELECT email FROM userOrg WHERE email = ? LIMIT 1");
    $stmt2->bind_param("s", $email);
    $stmt2->execute();
    $check_email_query_run_2 = $stmt2->get_result();
    
    $stmt3 = $con->prepare("SELECT username FROM userResto WHERE username = ? LIMIT 1");
    $stmt3->bind_param("s", $username);
    $stmt3->execute();
    $check_username_query_run = $stmt3->get_result();
    
    $stmt4 = $con->prepare("SELECT username FROM userOrg WHERE username = ? LIMIT 1");
    $stmt4->bind_param("s", $username);
    $stmt4->execute();
    $check_username_query_run_2 = $stmt4->get_result();
    
    $stmt5 = $con->prepare("SELECT mobilenum FROM userResto WHERE mobilenum = ? LIMIT 1");
    $stmt5->bind_param("s", $mobilenum);
    $stmt5->execute();
    $check_mobilenum_query_run = $stmt5->get_result();
    
    $stmt6 = $con->prepare("SELECT mobilenum FROM userOrg WHERE mobilenum = ? LIMIT 1");
    $stmt6->bind_param("s", $mobilenum);
    $stmt6->execute();
    $check_mobilenum_query_run_2 = $stmt6->get_result();

    function is_insecure_password($password) {
        $insecure_patterns = [
            "/\bOR\b/i",
            "/\bDROP\b/i",
            "/;/",
            "/<script>/i"
        ];
    
        foreach ($insecure_patterns as $pattern) {
            if (preg_match($pattern, $password)) {
                return true;
            }
        }
    
        return false;
    }

    $city_names = array(
        '133902' => 'Binondo',
        '137501' => 'Caloocan',
        '137601' => 'Las Piñas',
        '137602' => 'Makati',
        '137502' => 'Malabon',
        '137401' => 'Mandaluyong',
        '137402' => 'Marikina',
        '137603' => 'Muntinlupa',
        '137503' => 'Navotas',
        '137604' => 'Parañaque',
        '137403' => 'Pasig',
        '137405' => 'San Juan',
        '137504' => 'Valenzuela',
        '133908' => 'Ermita',
        '133909' => 'Intramuros',
        '133910' => 'Malate',
        '133911' => 'Paco',
        '133912' => 'Pandacan',
        '137605' => 'Pasay',
        '137606' => 'Pateros',
        '133913' => 'Port Area',
        '137404' => 'Quezon City',
        '133903' => 'Quiapo',
        '133933' => 'Sampaloc',
        '133907' => 'San Miguel',
        '133904' => 'San Nicolas',
        '133914' => 'Santa Ana',
        '133905' => 'Santa Cruz',
        '137607' => 'Taguig City',
        '133901' => 'Tondo I / II'
    );

    if (isset($city_names[$ocity])) {
        $city = $city_names[$ocity];
    } else {
        $city = ''; // Set a default value or handle the case when the city code is not found
    }
   
    if(strlen($fname) < 2 OR strlen($lname) < 2)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "First and Last name must at least have 2 or more characters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if($number_fname OR $number_lname OR $specialChars_fname OR $specialChars_lname)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "First and Last name must only be letters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(mysqli_num_rows($check_username_query_run) > 0 OR mysqli_num_rows($check_username_query_run_2) > 0)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Username already exists"; // Each username must be unique
        header("Location: /ewaste/register-organization");
        exit(0);
    }

    if(strlen($username) < 5 OR $specialChars_username)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Username must be at least 5 characters with no special characters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(mysqli_num_rows($check_mobilenum_query_run) > 0 OR mysqli_num_rows($check_mobilenum_query_run_2) > 0)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Phone number already exists"; // Each username must be unique
        header("Location: /ewaste/register-organization");
        exit(0);
    }
    
    if(!$validatephone)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Phone number must be 11 digits and start with 09"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if($birthdate > '2005-01-01')
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Users must be 18 years old or older."; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(mysqli_num_rows($check_email_query_run) > 0 OR mysqli_num_rows($check_email_query_run_2) > 0)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Email already exists"; // 1 EMAIL = 1 USER ROLE Ex: ab@yahoo.com is Resto but CANNOT be Org and VICE VERSA
        header("Location: /ewaste/register-organization");
        exit(0);
    }

    if(!$validate_email)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Invalid Email";
        header("Location: /ewaste/register-organization");
        exit(0);
    }
    
    if(strlen($orgName) < 2)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Organization name must at least have 2 or more characters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if($number_orgName OR $specialChars_orgName)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Organization name must only be letters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(strlen($desc) < 15)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Description must have at least 15 or more characters.";
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }


    if(!$number_address OR strlen($offAddress) < 7 OR !$validate_address)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Invalid Address"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(is_insecure_password($opass))
    {
        $_SESSION['status'] = "Invalid password"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(strlen($opass) < 8  OR !$number OR !$specialChars)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if(!$uppercase OR !$lowercase)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Password must have at least a lowercase letter, and uppercase letter"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if($opass != $oconfirmpass)
    {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        $_SESSION['offAddress-org'] = $offAddress;
        $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        $_SESSION['status'] = "Password and Confirm Password does not match"; 
        header("Location: /ewaste/register-organization"); 
        exit(0);
    }

    if (in_array($fileActualExt, $allowed)) {
        $_SESSION['fname-org'] = $fname;
        $_SESSION['lname-org'] = $lname;
        $_SESSION['username-register-org'] = $username;
        $_SESSION['mobilenum-org'] = $mobilenum;
        $_SESSION['birthdate-org'] = $birthdate;
        $_SESSION['email-org'] = $email;
        $_SESSION['orgname-org'] = $orgName;
        $_SESSION['desc-org'] = $desc;
        // $_SESSION['offAddress-org'] = $offAddress;
        // $_SESSION['city-org'] = $city;
        $_SESSION['services-org'] = $services;
        $_SESSION['opass'] = $opass;

        if ($fileError === 0) {
            if ($fileSize < 10000000) {
                $fileNameNew = uniqid('', true).".".$fileActualExt;
                $fileDestination = 'admin/uploads/'.$fileNameNew;
                move_uploaded_file($fileTmpName, $fileDestination);

                $user_type = 'org';

                $query = "INSERT INTO userOrg (fname, lname, username, mobilenum, birthdate, email, orgName, services, description, permit, region, city, offAddress, offAddress2, opass, verify_token, user_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $query_stmt = mysqli_prepare($con, $query);
                mysqli_stmt_bind_param($query_stmt, 'sssssssssssssssss', $fname, $lname, $username, $mobilenum, $birthdate, $email, $orgName, $services, $desc, $fileNameNew, $region, $city, $offAddress, $offAddress2, md5($opass), $verify_token, $user_type);
                $query_run = mysqli_stmt_execute($query_stmt);

                $org_data = "SELECT id, username, email FROM userOrg WHERE username = '$username' AND email = '$email'";
                $org_data_run = mysqli_query($con, $org_data);
                $row = mysqli_fetch_array($org_data_run);
                $org_id = $row['id'];

                $_SESSION['action'] = "Created an account.";

                $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('$org_id', '$username', '$email', 'org', '{$_SESSION['action']}')";
                $log_query_run = mysqli_query($con, $log_query);

                if($query_run && $log_query_run)
                {   
                    sendemail_verify("$username", "$email", "$verify_token");
                    $_SESSION['status'] = "Registration successful. Please verify your email address.";
                    header("Location: /ewaste/login");

                    unset($_SESSION['fname-org']);
                    unset($_SESSION['lname-org']);
                    unset($_SESSION['username-register-org']);
                    unset($_SESSION['mobilenum-org']);
                    unset($_SESSION['birthdate-org']);
                    unset($_SESSION['email-org']);
                    unset($_SESSION['orgname-org']);
                    unset($_SESSION['desc-org']);
                    // unset($_SESSION['offAddress-org']);
                    // unset($_SESSION['city-org']);
                    unset($_SESSION['services-org']);
                    unset($_SESSION['opass']);
                }
                else
                {
                    $_SESSION['status'] = "Registration failed";
                    header("Location: /ewaste/register-organization");
                }
            }
        }
    }
    else
    {
        $_SESSION['status'] = "Permit must be jpeg, jpg, png, or pdf files";
        header("Location: /ewaste/register-organization");
        exit(0);
    }
}
?>




