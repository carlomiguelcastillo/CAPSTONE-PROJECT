<?php
    $page_title = "Dashboard";
    include 'dbcon.php';
    include 'authentication.php';
    include 'includes/header.php';
    include 'includes/navbar.php';

    if($_SESSION['user_type'] != 'org') 
    {
        header("Location: error.html");
    }

    // Get the CSRF token from the session
    $sessionCsrfToken = $_SESSION['csrf_token'];

    // Get the user's CSRF token from the database
    $userCsrfTokenQuery = "SELECT csrf_token FROM userorg WHERE id = {$_SESSION['auth_user']['id']}";
    $userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
    $userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
    $userCsrfToken = $userCsrfTokenRow['csrf_token'];

    // Validate the CSRF token
    if ($sessionCsrfToken !== $userCsrfToken) {
        // CSRF token does not match, handle the error (e.g., redirect to an error page)
        header("Location: error.html");
        exit;
    }

    // CSRF token is valid, continue with further processing
    // ...
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style-compare.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <!-- Bootstrap JavaScript and jQuery -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
    <style>
        body{    
        background: #DCDCDC;
        }

        thead {
            border: 1px solid black;
        }
        th {
            border: 1px solid black;
            padding: 5px;
            text-align:center;
        }
        td {
            border: 1px solid black;
        }

    </style>

</head>
<body>
    <div class="sidebar">
        <div class="col-md-11 mx-auto">    
            <div class="card shadow mt-3">     
                <form action="" method="GET">                   
                    <div class="card-header">
                        <h5>                              
                            <button onClick="window.print();" class="btn btn-success btn-sm float-en" style="font-size: 15px">Print  </button> 
                            <button onClick="location.href='/ewaste/compare'" type="button" class="btn btn-success btn-sm float-en"> Reset </button>
                            <button type="submit" class="btn btn-success btn-sm float-en" name="search">Search</button>                        
                        </h5>
                    </div>     
                   
                    <!-- WASTE DROPDOWN FILTER -->   
                    <div class="card-body">                                                  
                        <div class="dropdown d-inline-flex">
                            <button class="btn btn-success dropdown-toggle" type="button" id="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Select Waste Type
                            </button>
                            <div class="dropdown-menu w-100">
                                <?php                              
                                    $query = "SELECT datatype FROM waste GROUP BY datatype
                                        UNION
                                        SELECT datatype FROM surplus GROUP BY datatype
                                        ;"; 
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0) 
                                    {                               
                                        foreach($query_run as $list)
                                        {
                                            $ddatatype = "'" . $list['datatype'] . "'";
                                            $checked = [];
                                            if(isset($_GET['filter']) && !empty($_GET['filter'])) 
                                            {                                                                                                         
                                                $checked = $_GET['filter'];                                                                           
                                            }                                                                                                 
                                                ?>
                                            <div class="form-check mx-2">
                                                <input class="form-check-input" type="checkbox" name="filter[]" value="<?= $ddatatype; ?>" 
                                                    <?php 
                                                    if(in_array($ddatatype, $checked)) 
                                                    {
                                                        $datatypelog = $list['datatype'];
                                                        $_SESSION['action'] = "Filtered DataType: $datatypelog";

                                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES
                                                        ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                                        $log_query_run = mysqli_query($con, $log_query);

                                                        if($log_query_run)
                                                        {
                                                            echo "checked";
                                                        }
                                                    } 
                                                    ?>
                                                />
                                                <label class="form-check-label"><?= $list['datatype']; ?></label> 
                                            </div>
                                    <?php
                                        } 
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- DURATION FILTER --> 
                        <div class="card-body">   
                            <h6>Duration</h6>
                                                                                                                
                                <lable>From Date</label>

                                <?php 
                                    if (!empty(($_GET['from_date'])))
                                    {                                        
                                        $timelog = $_GET['from_date'];
                                        $_SESSION['action'] = "Filtered Time Start: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $fromDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="from_date" class="form-control" value="<?php if (isset($_GET['from_date'])){echo $fromDate;};?>" >

                                <lable>To Date</label>

                                <?php 
                                    if (!empty(($_GET['to_date'])))
                                    {                                        
                                        $timelog = $_GET['to_date'];
                                        $_SESSION['action'] = "Filtered Time End: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $toDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="to_date" class="form-control" value="<?php if (isset($_GET['to_date'])){echo $toDate;};?>" >          
                        </div>                                
                                                      
                </form>      
                       
                <form action="excel-download.php" method="POST"> <!-- DOWNLOAD BUTTON --> 
                    <?php       
                    //DATA FILTER          
                        if(isset($_GET['filter']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {         
                            $data[] = array("Restaurant Name", "Restaurant Type", "City", "Email", "Data Type", "Food Type", "Raw Cost", "Weight", "Created At", "Updated At");                       
                            foreach($checked as $row)
                            {
                                $query = "SELECT w.datatype, w.rawcost, w.weight, w.foodtype AS food, u.restoname, u.rcity, u.email, u.restotype, w.created_at, w.updated_at
                                FROM waste w 
                                JOIN userresto u ON w.resto_id = u.resto_id
                                WHERE w.datatype IN ($row)
                                UNION ALL
                                SELECT s.datatype, s.rawcost, s.weight, s.surplus AS food, u.restoname, u.rcity, u.email, u.restotype, s.created_at, s.updated_at
                                FROM surplus s 
                                JOIN userresto u ON s.resto_id = u.resto_id
                                WHERE s.datatype IN ($row);
                                ";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $restotype = $result['restotype'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $food = $result['food'];
                                    $datatype = $result['datatype'];
                                    $rawcost = $result['rawcost'];
                                    $weight = $result['weight'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }   

                                    $data[] = array($restoname, $restotype, $city, $email, $datatype, $food, $rawcost, $weight, $created_at, $result['updated_at']);                              
                                }
                            }                       
                            ?>
                            <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                            <?php
                        }
                    //DURATION DATE FILTER
                        elseif(empty($_GET['filter']) && isset($_GET['from_date']))
                        {      
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "Restaurant Type", "City", "Email", "Data Type", "Food Type", "Raw Cost", "Weight", "Created At", "Updated At");                      
                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                                                           
                                $query = "SELECT w.datatype, w.rawcost, w.weight, w.foodtype AS food, u.restoname, u.rcity, u.email, u.restotype, w.created_at, w.updated_at
                                FROM waste w 
                                JOIN userresto u ON w.resto_id = u.resto_id
                                WHERE w.created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT s.datatype, s.rawcost, s.weight, s.surplus AS food, u.restoname, u.rcity, u.email, u.restotype, s.created_at, s.updated_at
                                FROM surplus s 
                                JOIN userresto u ON s.resto_id = u.resto_id
                                WHERE s.created_at BETWEEN '$from_date' AND '$to_date';
                                ";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $restotype = $result['restotype'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $food = $result['food'];
                                        $datatype = $result['datatype'];
                                        $rawcost = $result['rawcost'];
                                        $weight = $result['weight'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else{
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }   
    
                                        $data[] = array($restoname, $restotype, $city, $email, $datatype, $food, $rawcost, $weight, $created_at, $result['updated_at']);                                   
                                    }
                                                        
                                    ?>
                                    <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                        <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                    <?php
                                }
                            }

                            //FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))                              
                            {                                                 
                                $query = "SELECT w.datatype, w.rawcost, w.weight, w.foodtype AS food, u.restoname, u.rcity, u.email, u.restotype, w.created_at, w.updated_at
                                FROM waste w 
                                JOIN userresto u ON w.resto_id = u.resto_id
                                WHERE w.created_at BETWEEN '$from_date' AND NOW()
                                UNION ALL
                                SELECT s.datatype, s.rawcost, s.weight, s.surplus AS food, u.restoname, u.rcity, u.email, u.restotype, s.created_at, s.updated_at
                                FROM surplus s 
                                JOIN userresto u ON s.resto_id = u.resto_id
                                WHERE s.created_at BETWEEN '$from_date' AND NOW();
                                ";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $restotype = $result['restotype'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $food = $result['food'];
                                    $datatype = $result['datatype'];
                                    $rawcost = $result['rawcost'];
                                    $weight = $result['weight'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }   

                                    $data[] = array($restoname, $restotype, $city, $email, $datatype, $food, $rawcost, $weight, $created_at, $result['updated_at']);                               
                                }
                                                    
                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php
                            }
                        }
                    //ALL FILTERS
                        elseif(isset($_GET['filter']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                        {                             
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "Restaurant Type", "City", "Email", "Data Type", "Food Type", "Raw Cost", "Weight", "Created At", "Updated At");                        
                            foreach($checked as $row)
                            {
                                $query = "SELECT w.datatype, w.rawcost, w.weight, w.foodtype AS food, u.restoname, u.rcity, u.email, u.restotype, w.created_at, w.updated_at
                                FROM waste w 
                                JOIN userresto u ON w.resto_id = u.resto_id
                                WHERE w.datatype IN ($row) AND w.created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT s.datatype, s.rawcost, s.weight, s.surplus AS food, u.restoname, u.rcity, u.email, u.restotype, s.created_at, s.updated_at
                                FROM surplus s 
                                JOIN userresto u ON s.resto_id = u.resto_id
                                WHERE s.datatype IN ($row) AND s.created_at BETWEEN '$from_date' AND '$to_date';
                                ";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $restotype = $result['restotype'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $food = $result['food'];
                                    $datatype = $result['datatype'];
                                    $rawcost = $result['rawcost'];
                                    $weight = $result['weight'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                    
                                    
                                    $data[] = array($restoname, $restotype, $city, $email, $datatype, $food, $rawcost, $weight, $created_at, $result['updated_at']);                                
                                }
                            }                    
                            
                            //NO TO DATE FILTER
                            if(isset($_GET['filter']) && isset($_GET['from_date']) && empty($_GET['to_date'])) 
                            {  
                                $from_date = $_GET['from_date'];                    
                                foreach($checked as $row)
                                {
                                    $query = "SELECT w.datatype, w.rawcost, w.weight, w.foodtype AS food, u.restoname, u.rcity, u.email, u.restotype, w.created_at, w.updated_at
                                    FROM waste w 
                                    JOIN userresto u ON w.resto_id = u.resto_id
                                    WHERE w.datatype IN ($row) AND w.created_at BETWEEN '$from_date' AND NOW()
                                    UNION ALL
                                    SELECT s.datatype, s.rawcost, s.weight, s.surplus AS food, u.restoname, u.rcity, u.email, u.restotype, s.created_at, s.updated_at
                                    FROM surplus s 
                                    JOIN userresto u ON s.resto_id = u.resto_id
                                    WHERE s.datatype IN ($row) AND s.created_at BETWEEN '$from_date' AND NOW();
                                    ";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $restotype = $result['restotype'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $food = $result['food'];
                                        $datatype = $result['datatype'];
                                        $rawcost = $result['rawcost'];
                                        $weight = $result['weight'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else{
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                           
                                        
                                        $data[] = array($restoname, $restotype, $city, $email, $datatype, $food, $rawcost, $weight, $created_at, $result['updated_at']);                                
                                    }
                                
                                }        
                            }      

                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php                    
                        }  
                    ?>                            
                </form>
                
                <hr>
               

            </div>
        </div>      
    </div> 

    <div class="space"></div>
    
    <!-- CHARTS --> 
    <div class="visuals - script"> 
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // PIE CHART
                google.charts.load('current', {'packages':['corechart']});
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                    ['', ''], 
                    
                    <?php

                        // FILTER BY DATA 
                        if(isset($_GET['filter']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {                            
                            foreach($checked as $row)
                            {
                                $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE datatype IN ($row)
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE datatype IN ($row)
                                ) AS combined_data
                                GROUP BY datatype;";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $datatype = $result['datatype'];
                                    $rawcost = $result['rawcost'];                                     

                                    $datatypes[] = $datatype; // store all restonames in an array
                                    $rawcosts[] = $rawcost; 
                                    
                                    ?>

                                    ['<?php echo $datatype;?>', <?php echo $rawcost ;?>], 
                                    <?php 
                                }                                             
                            }                        
                        }

                        // FILTER BY DATE 
                        elseif(empty($_GET['filter']) && isset($_GET['from_date']))
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];

                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                              
                                $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                ) AS combined_data
                                GROUP BY datatype;";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $datatype = $result['datatype'];
                                        $rawcost = $result['rawcost'];   

                                        ?>      
                                        ['<?php echo $datatype;?>', <?php echo $rawcost ;?>],  
                                        <?php                 
                                    }    
                                                                                                        
                                }    
                            }
                                                    
                            // FILTER FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))
                            {
                                $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND NOW()
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND NOW()
                                ) AS combined_data
                                GROUP BY datatype;";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $datatype = $result['datatype'];
                                        $rawcost = $result['rawcost'];  
                                        
                                        ?>      
                                        ['<?php echo $datatype;?>', <?php echo $rawcost ;?>],  
                                        <?php                 
                                    }                                                                                                       
                                }             
                            }     
                        }  

                        // ALL FILTERS USED
                        elseif(isset($_GET['filter']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                        {
                            foreach($checked as $row)
                            { 
                                $from_date = $_GET['from_date'];
                                $to_date = $_GET['to_date'];      
                                $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE datatype IN ($row) AND created_at BETWEEN '$from_date' AND '$to_date'
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE datatype IN ($row) AND created_at BETWEEN '$from_date' AND '$to_date'
                                ) AS combined_data
                                GROUP BY datatype;";
                                $query_run = mysqli_query($con, $query);
                            
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $datatype = $result['datatype'];
                                        $rawcost = $result['rawcost'];   

                                        ?>

                                        ['<?php echo $datatype;?>', <?php echo $rawcost ;?>],
                                        <?php
                                        
                                    }
                                }
                            }

                            // NO TO DATE FILTER
                            if(isset($_GET['filter']) && isset($_GET['from_date']) && empty($_GET['to_date']))
                            {
                                foreach($checked as $row)
                                { 
                                    $from_date = $_GET['from_date'];   
                                    $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                    FROM (
                                        SELECT datatype, rawcost FROM waste WHERE datatype IN ($row) AND created_at BETWEEN '$from_date' AND NOW()
                                        UNION ALL
                                        SELECT datatype, rawcost FROM surplus WHERE datatype IN ($row) AND created_at BETWEEN '$from_date' AND NOW()
                                    ) AS combined_data
                                    GROUP BY datatype;";
                                    $query_run = mysqli_query($con, $query);
                                
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($result = mysqli_fetch_array($query_run))
                                        {
                                            $datatype = $result['datatype'];
                                            $rawcost = $result['rawcost'];   
                                            ?>

                                            ['<?php echo $datatype;?>', <?php echo $rawcost ;?>],
                                            <?php
                                            
                                        }                                        
                                    }
                                    
                                }
                            }  
                        } 

                        // NULL
                        else
                        {                                      
                            ?>
                            ['<?php echo "null";?>', <?php echo "null" ;?>],
                            <?php          
                            
                        }
           
                    ?>

                    ]);

                    var options = {
                        title: 'Average Raw Cost (₱) of Food Waste and/or Food Surplus',
                        pieSliceText: 'value',
                        sliceVisibilityThreshold: 0,
                        colors: ['#008000', '#0000FF', '#FF0000', '#800080', '#4682B4', '#D2691E', '#808000', '#800000', '#808080', '#FFFF00'],
                        tooltip: {
                            trigger: 'selection',
                            isHtml: true
                        },

                        titleTextStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '16',                           
                        },
                        pieSliceTextStyle: {                         
                            fontSize: '11',
                        },

                        legend: {           
                            position: 'right',
                            alignment: 'center',                
                            textStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '14',                            
                            },
                            maxLines: 1,
                        },
                        chartArea: {
                            width: '85%' // increase the chart area width
                        },

                        backgroundColor: {
                            'stroke': 'black',
                            'strokeWidth': 10
                        }
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);

                    var svgElement = document.querySelector('#piechart svg');
                        svgElement.setAttribute('style', 'border-radius: 5px;');

                        document.getElementById('chart-container').innerHTML += '<div class="info-icon"><i class="fa fa-info-circle"></i></div>';
        
                        document.querySelector('.info-icon').addEventListener('click', function() {

                        document.getElementById('myModal').style.display = "block";
                    });

                    document.querySelector('.close').addEventListener('click', function() {
       
                    document.getElementById('myModal').style.display = "none";

                    });                    
                }
        </script>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // COLUMN CHART
            google.charts.load("current", {packages:['corechart']});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([
            ["", "Cost (₱)"],
                        
                <?php 
                    $data = []; 

                    // FILTER BY DATA 
                    if(isset($_GET['filter']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {               
                        $list = implode(',', $checked); //implode() function returns a string from the elements of an array
                        $query = "SELECT datatype, AVG(rawcost) AS rawcost
                        FROM (
                            SELECT datatype, rawcost FROM waste WHERE datatype IN ($list)
                            UNION ALL
                            SELECT datatype, rawcost FROM surplus WHERE datatype IN ($list)
                        ) AS combined_data
                        GROUP BY datatype;";
                        $query_run = mysqli_query($con, $query);

                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $datatype = $result['datatype'];
                            $rawcost = $result['rawcost'];                            

                            ?>

                            ['<?php echo $datatype;?>', <?php echo number_format($rawcost, 2, '.', ''); ?>],                          
                            <?php
                        }                       
                    }

                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && isset($_GET['from_date']))
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                ) AS combined_data
                                GROUP BY datatype;";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date']) && !empty($_GET['from_date']))
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND NOW()
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND NOW()
                                ) AS combined_data
                                GROUP BY datatype;";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                            {
                                $datatype = $row['datatype'];
                                $rawcost = $row['rawcost'];
                                $data[] = ['datatype' => $datatype, 'rawcost' => $rawcost];   
                                ?>      
                                ['<?php echo $datatype;?>', <?php echo number_format($rawcost, 2, '.', ''); ?>],     
                                <?php                 
                            }                                                                                                           
                        }   

                        if(count($data) == 0) 
                        {
                            echo "['No data', 0]";
                        }
                    }

                    // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);   
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE datatype IN ($list) AND created_at BETWEEN '$from_date' AND '$to_date'
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE datatype IN ($list) AND created_at BETWEEN '$from_date' AND '$to_date'
                                ) AS combined_data
                                GROUP BY datatype;";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date']) && !empty($_GET['from_date']))
                        {
                            $list = implode(',', $checked);   
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                                FROM (
                                    SELECT datatype, rawcost FROM waste WHERE datatype IN ($list) AND created_at BETWEEN '$from_date' AND NOW()
                                    UNION ALL
                                    SELECT datatype, rawcost FROM surplus WHERE datatype IN ($list) AND created_at BETWEEN '$from_date' AND NOW()
                                ) AS combined_data
                                GROUP BY datatype;";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $datatype = $result['datatype'];
                                $rawcost = $result['rawcost'];                          
                                $data[] = ['datatype' => $datatype, 'rawcost' => $rawcost];  

                                ?>

                                ['<?php echo $datatype;?>', <?php echo number_format($rawcost, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }   

                    else           
                    {                                
                        ?>
                        ['<?php echo "";?>', <?php echo 0 ;?>],
                        <?php                        
                    }
                ?>

            ]);

                var view = new google.visualization.DataView(data);
                
                var options = {
                    colors: ['#008000'],
                    title: 'Average Raw Cost (₱) Based on the Different Factors Leading to Food Wastage',    
                    bar: {groupWidth: "35%"},
                    legend: { position: "none" },        
                    chartArea: {                          
                        backgroundColor: {
                        //fill: '#9CBE8C',
                    }
                    },                   

                    titleTextStyle: {
                        color: '#000000',
                        bold: true,
                        fontSize: '20',
                    },
                    
                    vAxis: {
                        textStyle:{
                            color: '#000000',
                            bold: true,                           
                        },
                    },
                    hAxis: {                           
                        textStyle:{
                            color: '#000000',
                            bold: true,
                            fontSize: 10,                                                             
                        },                          
                        slantedText: true,
                        slantedTextAngle: 25                        
                    },

                    backgroundColor: {
                        //fill: '#9CBE8C',
                        'stroke': 'black', 
                        'strokeWidth': 10,                           
                    },                                    
                };

                    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
                    chart.draw(view, options);

                    var svgElement = document.querySelector('#columnchart_values svg');
                    svgElement.setAttribute('style', 'border-radius: 5px;');

                    document.getElementById('column-chart-container').innerHTML += '<div class="info-icon-column"><i class="fa fa-info-circle"></i></div>';
      
                    document.querySelector('.info-icon-column').addEventListener('click', function() {

                    document.getElementById('myModal-column-chart').style.display = "block";

                    // Select the close button inside the currently displayed modal
                    const closeBtn = document.querySelector('#myModal-column-chart .close');
                    
                        closeBtn.addEventListener('click', function() {
        
                            document.getElementById('myModal-column-chart').style.display = "none";

                        });
                    });           
                }
        </script> 
    </div>
    
    <!-- VS CARDS -->  
    <div id="vscard2" class="card">
        <div class="card-header" style="font-size:110%;"><b><center>Total Cost of Food Wasted/Surplused</b></center>
            <div class="info-icon-vscard2">
                <i class="fa fa-info-circle" data-toggle="modal" data-target="#infoModal-vscard2"></i>
            </div>
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 2
                        
                    // FILTER BY DATA 
                    if(isset($_GET['filter']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $card_list = implode(',', $checked);
                        $query = "SELECT datatype, SUM(rawcost) AS rawcost
                        FROM (
                            SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list)
                            UNION ALL
                            SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list)
                        ) AS combined_data;";
                        $query_run = mysqli_query($con, $query);
                        
                        $total_rawcost = 0;
                        while ($result = mysqli_fetch_array($query_run)) {
                            $rawcost = $result['rawcost'];                          
                            
                            // Add the rawcost of the current restaurant to the total rawcost
                            $total_rawcost += $rawcost;
                        }                      
                        // Output the total rawcost for the selected restaurants
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ',');
                    }

                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && isset($_GET['from_date']))
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        $total_rawcost = 0;
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT datatype, SUM(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND '$to_date'
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }          
                        }                                    

                        if(empty($_GET['to_date']) && !empty($_GET['from_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT datatype, SUM(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND NOW()
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND NOW()
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;

                            }       
                        }
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ','); 
                    }

                    // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                            
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT datatype, SUM(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND '$to_date'
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }                             
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT datatype, SUM(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND NOW()
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND NOW()
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }                           
                        }  
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ','); 
                    }  

                ?>
            </div>                    
    </div>

    <div id="vscard3" class="card">
        <div class="card-header" style="font-size:110%;"><b><center>Average Cost of Food Wasted/Surplused</b></center>
            <div class="info-icon-vscard3">
                <i class="fa fa-info-circle" data-toggle="modal" data-target="#infoModal-vscard3"></i>
            </div>
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 3
                        
                    // FILTER BY DATA 
                    if(isset($_GET['filter']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $card_list = implode(',', $checked);
                        $query = "SELECT datatype, AVG(rawcost) AS rawcost
                        FROM (
                            SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list)
                            UNION ALL
                            SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list)
                        ) AS combined_data;";
                        $query_run = mysqli_query($con, $query);
                        
                        $total_rawcost = 0;
                        while ($result = mysqli_fetch_array($query_run)) {
                            $rawcost = $result['rawcost'];                          
                            
                            // Add the rawcost of the current restaurant to the total rawcost
                            $total_rawcost += $rawcost;
                        }                      
                        // Output the total rawcost for the selected restaurants
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ',');
                    }
  
                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && isset($_GET['from_date']))
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND '$to_date'
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }          
                        }                                    

                        if(empty($_GET['to_date']) && !empty($_GET['from_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE created_at BETWEEN '$from_date' AND NOW()
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE created_at BETWEEN '$from_date' AND NOW()
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;

                            }       
                        }
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ','); 
                    }
  
                    // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                            
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND '$to_date'
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND '$to_date'
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }                             
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT datatype, AVG(rawcost) AS rawcost
                            FROM (
                                SELECT datatype, rawcost FROM waste WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND NOW()
                                UNION ALL
                                SELECT datatype, rawcost FROM surplus WHERE datatype IN ($card_list) AND created_at BETWEEN '$from_date' AND NOW()
                            ) AS combined_data;";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }                           
                        }  
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ','); 
                    }  
                    
                ?>
            </div>                    
    </div>
    
    <!-- VISUALS & MODALS--> 
    <div class="visuals">

        <!-- MODALS -->             
            <!-- PLACE HERE -->     

        <div class="chart-wrapper">
            <div id="piechart"></div>
            <div id="chart-container"></div>
        </div>

        <div class="chart-wrapper-column">
            <div id="columnchart_values"></div>  
            <div id="column-chart-container"></div> <!-- info icon columnchart-->
        </div>    
        
        <div id="vscard2-container"></div>
                    
        <div id="vscard3-container"></div>
    </div>

    <a href="/ewaste/compare-weight" id="visual-link">Compare Weight Data</a>

</body>
</html>

