<?php 
include('authentication.php');
$page_title = "Dashboard";
include('includes/header.php');
include('includes/navbar.php');
?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">

            <?php
                if(isset($_SESSION['status']))
                {
                    ?>
                    <div class="alert alert-sucess">
                        <h5><?= $_SESSION['status']; ?></h5>
                    </div>
                    <?php
                    unset($_SESSION['status']);
                }
            ?>
            
            </div>           
        </div>  
    </div>   
</div>