<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php'); 


if(isset($_POST['deletedata']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM waste WHERE id = $id" ;
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted waste data (Waste ID: $id)";

     $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
     $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location: /ewaste/view-waste');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}


if(isset($_POST['deletedata']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM surplus WHERE id = $id" ;
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted surplus data (Surplus ID: $id)";

     $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
     $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location: /ewaste/view-waste');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}

if(isset($_POST['deletedata']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM recwaste WHERE id = $id" ;
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted recwaste data (Recwaste ID: $id)";

     $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
     $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location: /ewaste/view-waste');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}

if(isset($_POST['deletedata']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM reswaste WHERE id = $id" ;
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted reswaste data (Reswaste ID: $id)";

     $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
     $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location: /ewaste/view-waste');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}

if(isset($_POST['deletedata']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM stwaste WHERE id = $id" ;
    $query_run = mysqli_query($con, $query);

    $_SESSION['action'] = "Deleted stwaste data (Stwaste ID: $id)";

     $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
     $log_query_run = mysqli_query($con, $log_query);

    if($query_run && $log_query_run)
    {
        echo '<script> alert("Data Deleted"); </script>';
        header('location: /ewaste/view-waste');
    }
    else
    {
        echo '<script> alert("Data Not Deleted"); </script>';
        die(mysqli_error($con));
    }
}


