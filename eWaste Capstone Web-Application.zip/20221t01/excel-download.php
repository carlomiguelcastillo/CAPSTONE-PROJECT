<?php
include_once("dbcon.php");

if (isset($_POST['download'])) {
    $data = unserialize(base64_decode($_POST['data']));
  
    header('Content-Encoding: UTF-8');
    header("Content-Type: text/csv; charset=UTF-8");
    header("Content-Disposition: attachment; filename=waste_data.csv");
    echo "\xEF\xBB\xBF"; // UTF-8 BOM // Fixes Enye

    $output = fopen("php://output", "w");
  
    foreach ($data as $row) {
      fputcsv($output, $row);
    }
  
    fclose($output);
    exit;
  }
?>


