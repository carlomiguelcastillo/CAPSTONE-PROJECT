<?php
include 'dbcon.php';
include 'authentication.php';
include 'includes/header.php';
include 'includes/navbar.php';

$username =  $_SESSION['auth_user']['username'];
$query = "SELECT * FROM userOrg WHERE username = '$username'";
$query_run = mysqli_query($con, $query);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="css/home-org.css">
</head>
<body>
<div class="vertical-rectangle">
    <a href="articles"> <img src="image/news.png" style="border-radius: 10px;"> </a>
</div>
<div class="rectangle">
    <!-- Slideshow Images -->
    <a href="org-options"><img class="slideshow-image" src="image/viz.png"></a>
    <a href="about-us-org"><img class="slideshow-image" src="image/aboutus.png" style="margin-left: 10px; width: 530px; height: 400px;"></a>
    <div class="slideshow-arrow prev" onclick="previousImage()">&#8249;</div>
    <div class="slideshow-arrow next" onclick="nextImage()">&#8250;</div>
</div>

<div class="squares-container">
    <div class="square">
        <a href="emailsender/main"> <img src="image/sendemail.png" style="width: 215px; height: 170px; position: absolute; top: 55%; left: 25%; transform: translate(-50%, -50%);"> </a>
    </div>

    <div class="square">
        <?php
            if($query_run)
            {
                $row = mysqli_fetch_array($query_run);
                $username = $row['username'];
                ?>
                <a href="/ewaste/profile/<?php echo $username?>"><img src="image/acc-home.png"> </a></a>
                <?php
            }
        ?>
    </div>
</div>

</body>
</html>

<script>
   var images = document.querySelectorAll('.slideshow-image');
    var currentIndex = 0;

    // Show the first image immediately when the page loads
    showImage(currentIndex);

    function showImage(index) {
    // Hide all images
    for (var i = 0; i < images.length; i++) {
        images[i].style.display = 'none';
    }

    // Show the image at the given index
    images[index].style.display = 'block';
    }

    function previousImage() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    showImage(currentIndex);
    }

    function nextImage() {
    currentIndex = (currentIndex + 1) % images.length;
    showImage(currentIndex);
    }
</script>