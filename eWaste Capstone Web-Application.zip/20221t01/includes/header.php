<html>
<head>
    <meta charset="UTF-8">
    <title>
        <?php
            if(isset($page_title)){
                echo "$page_title";
            }
        ?> - eWaste
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" >
</head>
<body>