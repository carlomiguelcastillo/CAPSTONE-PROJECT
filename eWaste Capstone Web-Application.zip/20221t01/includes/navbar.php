<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" >
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" ></script>
<style>
  
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    position: fixed;
    overflow: hidden;
    top: 0;
    left: 0;
    width: 100%;
    height: 60px;
    background-color: #023020;
    z-index: 1;
  }

  .topnav a {
    float: left;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    transform: scale(1.24);
    background-color: #ddd;
    color: black;
  }

  .topnav-right {
    float: right;
  }

  .logo-image{
    transform: scale(1.2);
    width: 55px;
    height: 45px;
    border-radius: 15%;
    overflow: hidden;
    margin-top:-17px;
  }

  @media screen and (max-width: 1400px) {
    .topnav 
    {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
      width: 1268px;
    }
  }

</style>
</head>
<body>

<div class="topnav">
  <a class="navbar-brand" href="/ewaste/index.php"> 
    <div class="logo-image">
          <img src="/ewaste/image/ewaste_icon.png" class="img-fluid">
    </div>
  </a>
  
  <div class="topnav-right">

    <?php if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'resto') : ?>

      <a href="/ewaste/home-resto"><b>Home</b></a>

      <a href="/ewaste/add-waste"><b>Add Data</b></a>   

      <a href="/ewaste/view-waste"><b>View Data</b></a>

      <a href="/ewaste/articles"><b>Articles</b></a>
          
      <a href="/ewaste/organizations"><b>Organizations</b></a>
          
      <a href="/ewaste/about-us-resto"><b>About Us</b></a>

      <?php
        include './dbcon.php';
        
        $username =  $_SESSION['auth_user']['username'];
        $query = "SELECT * FROM userResto WHERE username = '$username'";
        $query_run = mysqli_query($con, $query);

        if($query_run)
        {
          $row = mysqli_fetch_array($query_run);
          $username = $row['username'];
          ?>
          <a href="/ewaste/account/<?php echo $username?>"><b>Account</b></a>
          <?php
        }
      ?>
  
    <?php endif ?>

    <?php if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'org') : ?>

      <a href="/ewaste/home-org"><b>Home</b></a>
          
      <a href="/ewaste/org-options"><b>Dashboard</b></a>

      <a href="/ewaste/articles"><b>Articles</b></a>

      <a href="/ewaste/emailsender/main"><b>Send Email</b></a>
                  
      <a href="/ewaste/about-us-org"><b>About Us</b></a>

      <?php
        include './dbcon.php';
        
        $username =  $_SESSION['auth_user']['username'];
        $query = "SELECT * FROM userOrg WHERE username = '$username'";
        $query_run = mysqli_query($con, $query);

        if($query_run)
        {
          $row = mysqli_fetch_array($query_run);
          $username = $row['username'];
          ?>
          <a href="/ewaste/profile/<?php echo $username?>"><b>Account</b></a>
          <?php
        }
      ?>
      
    <?php endif ?>

    <?php if(!isset($_SESSION['authenticated'])) : ?>

      <a href="/ewaste/about-us"><b>About Us</b></a>
          
      <a href="/ewaste/register"><b>Register</b></a>
            
      <a href="/ewaste/login"><b>Login</b></a>
          
    <?php endif ?>

    <?php if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'super_admin') : ?>
        
        <a href="/ewaste/admin/home"><b>Home</b></a>
      
        <a href="/ewaste/admin/emailsender"><b>Send Email</b></a>
      
        <a href="/ewaste/admin/view-profile"><b>Account</b></a>  
      
  <?php endif ?>

  <?php if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'sub_admin') : ?>
    
    <a href="/ewaste/home-org"><b>Home</b></a>

  <?php endif ?>

    <?php if(isset($_SESSION['authenticated'])) : ?>

      <a href="/ewaste/logout"><b>Logout</b></a>

    <?php endif ?>

  </div>
</div>

</body>
</html>
