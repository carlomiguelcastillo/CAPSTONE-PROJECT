<!--pop up display for add-form.php button -->
<script src="uploads/sweetalert.min.js"></script>
<?php
    if(isset($_SESSION['progress']) && $_SESSION['progress'] !='')
    {
        ?>
            <style>
                /* Center the sweet alert button */
                .swal-button-container {
                    display: flex;
                    justify-content: center;
                }

                .swal-modal {
                    width: 600px;
                }
            </style>

            <script>
                swal({
                        title: "<?php echo $_SESSION['progress']; ?>",
                        // text: "You clicked the button!",
                        icon: "<?php echo $_SESSION['progress_code']; ?>",
                        button: "OK",
                    });
            </script>
            
        <?php
            unset($_SESSION['progress']);
    }
?>
