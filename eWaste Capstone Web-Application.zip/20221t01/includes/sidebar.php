<div class="col-md-4">
  <!-- Search Widget -->
  <div class="card mb-4">
    <h5 class="card-header">Search</h5>
    <div class="card-body">
      <form name="search" action="search" method="post">
        <div class="input-group">
          <input type="text" name="searchtitle" class="form-control" placeholder="Search article title" style="z-index: 0;" required>
            <span class="input-group-btn">
              <button class="btn btn-secondary" type="submit" style="z-index: 0;">Go!</button>
            </span>
      </form>
    </div>
  </div>
</div>

<!-- Categories Widget -->
<div class="card my-4">
  <h5 class="card-header">Categories</h5>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <ul class="list-unstyled mb-0">
        <?php
          $query = mysqli_query($con, "SELECT DISTINCT category FROM posts"); // Fetch distinct categories
          while ($row = mysqli_fetch_array($query)) {
              $category = $row['category'];
              ?>
              <li>
                <b><a href="category.php?category=<?php echo urlencode($category); ?>" style="display: inline-block; width: 200%;"><?php echo htmlentities($category); ?></a></b>
              </li>
          <?php } ?>
          </ul>
        </div>
      </div>
    </div>
  </div>

 <!-- Custom Widget with 2 Links -->
<?php
// Assuming $userType contains the user type of the current user
if ($_SESSION['user_type'] === 'org') {
?>
<div class="card my-4">
  <h5 class="card-header">Actions</h5>
  <div class="card-body">
    <ul class="mb-0">
      <li>
        <a href="/ewaste/admin/add-post.php">Add Article</a>
      </li>
    </ul>
  </div>
</div>
<?php
}
?>


<!-- Side Widget -->
<div class="card my-4">
  <h5 class="card-header">Recent Additions</h5>
  <div class="card-body">
    <ul class="mb-0">
      <?php
      $query=mysqli_query($con,"select id, link, title from posts limit 8");
      while ($row=mysqli_fetch_array($query)) {
      ?>
      <li>
        <a href="<?php echo $row['link']; ?>" target="_blank"><?php echo htmlentities($row['title']);?></a>
      </li>
        <?php } ?>
      </ul>
      </div>
  </div>
</div>




