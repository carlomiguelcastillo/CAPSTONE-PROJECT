<?php 
include('authentication.php');
$page_title = "Home Page";
include('includes/header.php');
include('includes/navbar.php');

if($_SESSION['user_type'] == 'org')
{
    header('location:visuals.php');
}
if($_SESSION['user_type'] == 'resto')
{
    header('location:add-form.php');
}

?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <hr><h2>eWaste</h2>
            </div>           
        </div>  
    </div>   
</div>

