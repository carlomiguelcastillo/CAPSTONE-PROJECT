<?php
session_start();

if(isset($_SESSION['authenticated'])) //if already logged in
{
    $_SESSION['status'] = "You are already logged in"; // not working
    header('Location: index.php'); // maybe make a page that shows you are already logged in
    exit(0);
}

?>