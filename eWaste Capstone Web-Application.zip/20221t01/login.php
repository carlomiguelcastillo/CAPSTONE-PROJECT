<?php 
session_start();

if(isset($_SESSION['authenticated'])) //if not authenticated (!isset)
{
    $_SESSION['status'] = "You are already logged in";
    header('Location: dashboard.php');
    exit(0);
}

$page_title = "Login Page";
include('includes/header.php');
include('includes/navbar.php');

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eWaste</title>

    <!-- BOOTSTRAP PACKAGE CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        body {
            background-image: url('image/bg.jpg');
            height: 500px; 
            background-repeat: no-repeat;
            background-size: cover;  
            background-attachment: fixed;
        }

        form{
            width: 100%;
            padding: 10px 20px;
            margin: 8px 0;
            display: inline-block;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        .cardshadow{
            width:500px;
            margin:15% auto;
            padding:10px;
            border-radius: 20px;
            background-color: rgba(0,0,0,0.23);
            box-shadow: 0 0 17px rgb(25, 24, 24);
        }

        .btn {
            width: 15%;
            background: black;
            color: white!important;
            font-size: large;
            font-weight: 600;
        }

        h4 {
            color: white;
        }

        .error {
            color: #A52A2A;
        }

        #recaptcha-error {
            display: none;
            color: #A52A2A;
            font-weight: 600;
            font-size: 23px;
        }

    </style>
</head>
<body>
    <div class="cardshadow">
        <form action="logincode.php" method="POST">
            <div class="col-10 m-auto text-center">
                <?php
                if(isset($_SESSION['status']))
                {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }
                if(isset($_SESSION['status-error'])) {
                    echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                    unset($_SESSION['status-error']);
                }
                ?>
                <span id="recaptcha-error" style="display:none;">Please complete the reCAPTCHA</span>
                    <div class="head mb-3 mt-5" style="font-size: 80px; font-weight: 700; color: white; position: relative; top: -30px; left: -10px;">eWaste</div>
            
                <div class="container">

                    <div class="form-group mb-3">
                        <input type="text" name="email" class="form-control" placeholder="Email" style="border-radius:8px; width:300px; height:35px;" required>
                    </div>
                    
                    <div class="form-group  mb-3">
                        <input type="password" name="password" class="form-control" placeholder="Password" style="border-radius:8px; width:300px; height:35px;" id="id_password" required >
                        <i class="far fa-eye" id="togglePassword" style="margin-right: -250px; margin-top: -26px; cursor: pointer;"></i>
                    </div>
                    
                    <div class="g-recaptcha" data-sitekey="6LeqsEclAAAAAPe0qg2sDpTDIf3A0hAVcs7BZJa9"></div>
                    
                    <div class="d-flex justify-content-center">
                        <p style="font-size: 14px; color:white; font-style:italic;">No Account?</p> &nbsp; <a href="/ewaste/register" style="font-size: 14px; color:black; font-style:italic;">Register</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                        <a href="/ewaste/password-reset" style="font-size: 14px; color: white; font-style:italic;">Forgot Password</a> 
                    </div>

                    <div class="form-group">
                        <button type="submit" name="login_now_btn" class="btn" onclick="return validateForm()" style="margin-right: 250px; border-radius:8px; width:300px;">Sign In</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
      
</body>
</html>
<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>

<script>
    function validateForm() {
    var response = grecaptcha.getResponse();
    if (response.length == 0) {
        document.getElementById('recaptcha-error').style.display = 'block';
        return false;
    } else {
        return true;
    }
    }
</script>