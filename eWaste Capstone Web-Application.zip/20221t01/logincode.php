<?php 
session_start();
include('dbcon.php');

if(isset($_POST['login_now_btn'])) // if or once login button is clicked
{
    if(!empty(trim($_POST['email'])) && !empty(trim($_POST['password'])) && isset($_POST['g-recaptcha-response']) && !empty(trim($_POST['g-recaptcha-response'])))
    {
        $email = stripcslashes($_POST['email']);
        $password = stripcslashes($_POST['password']);

        $email = mysqli_real_escape_string($con, $email);
        $password = mysqli_real_escape_string($con, $password);

        $login_query = "SELECT * FROM userResto WHERE email = ? AND rpass = ? LIMIT 1";
        $login_stmt = mysqli_prepare($con, $login_query);
        mysqli_stmt_bind_param($login_stmt, "ss", $email, md5($password));
        mysqli_stmt_execute($login_stmt);
        $login_query_run = mysqli_stmt_get_result($login_stmt);
        
        $login_query_2 = "SELECT * FROM userOrg WHERE email = ? AND opass = ? LIMIT 1";
        $login_stmt_2 = mysqli_prepare($con, $login_query_2);
        mysqli_stmt_bind_param($login_stmt_2, "ss", $email, md5($password));
        mysqli_stmt_execute($login_stmt_2);
        $login_query_run_2 = mysqli_stmt_get_result($login_stmt_2);
        
        $login_query_admin = "SELECT * FROM admin WHERE email = ? AND password = ? LIMIT 1";
        $login_stmt_admin = mysqli_prepare($con, $login_query_admin);
        mysqli_stmt_bind_param($login_stmt_admin, "ss", $email, md5($password));
        mysqli_stmt_execute($login_stmt_admin);
        $login_query_run_admin = mysqli_stmt_get_result($login_stmt_admin);
       
        $secretkey = "6LeqsEclAAAAAD4b_ryhi1bdnrDlE060HuEJ_fwl";
        $ip = $_SERVER['REMOTE_ADDR'];
        $response = $_POST['g-recaptcha-response'];
        $url = "https://www.google.com/recaptcha/api/siteverify?secret=$secretkey&response=$response&remoteip=$ip";
        $file = file_get_contents($url);
        $data = json_decode($fire);
        if($data->success==true){
            echo "success";
        }

        if(mysqli_num_rows($login_query_run) > 0 OR mysqli_num_rows($login_query_run_2) > 0 OR mysqli_num_rows($login_query_run_admin)) // if resto/ org/ admin is logged in
        {
            $row = mysqli_fetch_array($login_query_run);
            
            if($row['verify_status'] == "1") // when resto logins
            {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                $_SESSION['authenticated'] = TRUE;
                $_SESSION['user_type'] = 'resto';
                $_SESSION['action'] = "Logged in the system."; 
                $_SESSION['auth_user'] = [
                    'username' => $row['username'], 
                    'email' => $row['email'], 
                    'id' => $row['resto_id'],
                    'csrf_token' => $_SESSION['csrf_token'],
                ];

                $query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                $query_run = mysqli_query($con, $query);

                $query_2 = "UPDATE userresto SET csrf_token = '{$_SESSION['csrf_token']}' WHERE resto_id = {$_SESSION['auth_user']['id']}";
                $query_run_2 = mysqli_query($con, $query_2);

                if($query_run)
                {
                    $csrf_token = $_SESSION['csrf_token'];
                    header("Location: /ewaste/home-resto");
                    exit(0);
                }
                
            }

            $row_2 = mysqli_fetch_array($login_query_run_2); // when org logins
            
            if($row_2['verify_status'] == "1")
            {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                $_SESSION['authenticated'] = TRUE;
                $_SESSION['user_type'] = 'org';
                $_SESSION['action'] = "Logged in the system."; 
                $_SESSION['auth_user'] = [
                    'username' => $row_2['username'], 
                    'email' => $row_2['email'],                
                    'id' => $row_2['id'],
                    'csrf_token' => $_SESSION['csrf_token'],
                ];     
                
                $query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                $query_run = mysqli_query($con, $query);

                $query_2 = "UPDATE userorg SET csrf_token = '{$_SESSION['csrf_token']}' WHERE id = {$_SESSION['auth_user']['id']}";
                $query_run_2 = mysqli_query($con, $query_2);

                if($query_run)
                {
                    $csrf_token = $_SESSION['csrf_token'];
                    header("Location: /ewaste/home-org ");
                    exit(0);
                }
                
            }

            $row_admin = mysqli_fetch_array($login_query_run_admin);

            if($row_admin['user_type'] == "super_admin")
            {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                $_SESSION['authenticated'] = TRUE;
                $_SESSION['user_type'] = 'super_admin';
                $_SESSION['action'] = "Logged in the system.";              
                $_SESSION['auth_user'] = [
                    'username' => $row_admin['username'], 
                    'email' => $row_admin['email'],                
                    'id' => $row_admin['id'],
                    'csrf_token' => $_SESSION['csrf_token'],
                ];              

                $query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                $query_run = mysqli_query($con, $query);

                
                $query_2 = "UPDATE admin SET csrf_token = '{$_SESSION['csrf_token']}' WHERE id = {$_SESSION['auth_user']['id']}";
                $query_run_2 = mysqli_query($con, $query_2);

                if($query_run)
                {
                    $csrf_token = $_SESSION['csrf_token'];
                    header("Location: admin/home ");
                    exit(0);
                }
            }

            if($row_admin['user_type'] == "sub_admin")
            {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

                $_SESSION['authenticated'] = TRUE;
                $_SESSION['user_type'] = 'sub_admin';
                $_SESSION['action'] = "Logged in the system.";              
                $_SESSION['auth_user'] = [
                    'username' => $row_admin['username'], 
                    'email' => $row_admin['email'],                
                    'id' => $row_admin['id'],
                    'csrf_token' => $_SESSION['csrf_token'],
                ];              

                $query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                $query_run = mysqli_query($con, $query);

                $query_2 = "UPDATE admin SET csrf_token = '{$_SESSION['csrf_token']}' WHERE id = {$_SESSION['auth_user']['id']}";
                $query_run_2 = mysqli_query($con, $query_2);

                if($query_run)
                {
                    $csrf_token = $_SESSION['csrf_token'];
                    header("Location: admin/sub-home ");
                    exit(0);
                }
            }
            else
            {
                $_SESSION['status'] = "Please verify your email address to login";
                header("Location: login");
                exit(0);
            }
        }

        else if(mysqli_num_rows(mysqli_query($con, "SELECT * FROM userResto WHERE email = '$email' LIMIT 1")) > 0 
        || mysqli_num_rows(mysqli_query($con, "SELECT * FROM userOrg WHERE email = '$email' LIMIT 1")) > 0 
        || mysqli_num_rows(mysqli_query($con, "SELECT * FROM admin WHERE email = '$email' LIMIT 1")) > 0)
        {
            $_SESSION['status-error'] = "Incorrect email or password";
            header("Location: login");
            exit(0);
        }
        
        else
        {
            $_SESSION['status-error'] = "Email does not exist";
            header("Location: login");
            exit(0);
        }
    
    }

    else 
    {
        $_SESSION['status-error'] = "Please fill in all the required fields and verify that you are not a robot";
        header("Location: login");
        exit(0);
    }
}


?>