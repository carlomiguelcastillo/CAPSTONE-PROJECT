<?php
session_start();
include "dbcon.php";

if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'resto')
{
    $_SESSION['action'] = "Logged out the system.";

    $query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        unset($_SESSION['authenticated']);
        unset($_SESSION['auth_user']);
        $_SESSION['status'] = "Logged out successfully";
        header("Location: /ewaste/login");
    }
}

if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'org')
{
    $_SESSION['action'] = "Logged out the system.";

    $query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        unset($_SESSION['authenticated']);
        unset($_SESSION['auth_user']);
        $_SESSION['status'] = "Logged out successfully";
        header("Location: /ewaste/login");
    }
}

if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'super_admin')
{
    $_SESSION['action'] = "Logged out the system.";

    $query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        unset($_SESSION['authenticated']);
        unset($_SESSION['auth_user']);
        $_SESSION['status'] = "Logged out successfully";
        header("Location: /ewaste/login");
    }
}

if(isset($_SESSION['authenticated']) && $_SESSION['user_type'] == 'sub_admin')
{
    $_SESSION['action'] = "Logged out the system.";

    $query = "INSERT INTO adminlog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        unset($_SESSION['authenticated']);
        unset($_SESSION['auth_user']);
        $_SESSION['status'] = "Logged out successfully";
        header("Location: /ewaste/login");
    }
}


?>