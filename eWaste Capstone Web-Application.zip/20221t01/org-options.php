<?php 
$page_title = "Dashboard";
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');
include('includes/scripts.php');

if ($_SESSION['user_type'] != 'org') {
    header("Location: /ewaste/error.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #DCDCDC;
            height: 300px;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
        }

        .container {
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .text-container {
            text-align: center;
            margin-bottom: 30px;
        }

        .text-container h1 {
            font-size: 48px;
            /* Increase the font size for impact */
            font-weight: bold;
            color: #333;
            text-transform: uppercase;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .button-container {
            display: flex;
            Justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            max-width: 1100px;
            /* Adjust the maximum width to fit the buttons */
            margin: 0 auto;
            /* Center the container horizontally */
        }

        .button-container a {
            text-decoration: none;
            color: black;
        }

        .button-container .btn {
            padding: 10px;
            /* Decrease the padding to increase button size */
            width: calc(20% - 20px);
            /* Adjust the width to distribute buttons evenly */
            height: 160px;
            font-size: 18px;
            /* Decrease the font size to fit the button */
            border-radius: 10px;
            background-color: #E6F1FF;
            border: none;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .button-container .btn i {
            font-size: 48px;
            /* Increase the font size for the icon */
            margin-bottom: 10px;
            /* Add some space between icon and text */
        }

        .button-container .btn:hover {
            background-color: #BDD8FF;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .button-container .btn-compare {
            width: 210px; /* Adjust the width to your preference */
            margin: 60px; /* Add margin to create space around the button */
        }

        .button-container .btn-compare i {
            font-size: 48px;
            margin-bottom: 10px;
        }

        .button-container .btn-compare:hover {
            background-color: #8EB5FF;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="text-container">
            <h1>Which data would you like to view?</h1>
        </div>
        <div class="button-container">
            <a href="visuals" class="btn">
                <i class="bi bi-bag"></i> Food Waste
            </a>
            <a href="surplus-visuals" class="btn">
                <i class="bi bi-basket2-fill"></i> Food Surplus
            </a>
            <a href="recwaste-visuals" class="btn">
                <i class="bi bi-recycle"></i> Recyclable Waste
            </a>
            <a href="reswaste-visuals" class="btn">
                <i class="bi bi-trash-fill"></i> Residual Residual
            </a>
            <a href="stwaste-visuals" class="btn">
                <i class="bi bi-exclamation-triangle-fill"></i> Special or Toxic Waste
            </a>
            <a href="compare" class="btn btn-compare">
                <i class="bi bi-bar-chart-fill"></i> Compare Data
            </a>
        </div>
    </div>
</body>
</html>