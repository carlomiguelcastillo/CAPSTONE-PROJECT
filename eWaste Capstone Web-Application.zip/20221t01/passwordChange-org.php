<?php

session_start();

$page_title = "Password Change";
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

if(!isset($_GET["code"]))
{
    exit("Can't find page");
}

$code = $_GET["code"];

$getEmailQuery = mysqli_query($con, "SELECT email FROM resetPass WHERE code='$code'");
if(mysqli_num_rows($getEmailQuery) == 0) // if no row is found in database table
{
    exit("Can't find page");
}

if(isset($_POST["changepass_btn"])) 
{
    $new_pass = $_POST["new_pass"];
    $confirm_new_pass = $_POST["confirm_new_pass"];

    $number = preg_match('@[0-9]@', $new_pass);
    $specialChars = preg_match('@[^\w]@', $new_pass);

    if(strlen($new_pass) < 8 )
    {      
        $_SESSION['status'] = "New password must be more than 8 characters"; 
        header("Location: /ewaste/change-password/$code");
        exit(0);
    }

    if(ctype_upper($new_pass) OR ctype_lower($new_pass))
    {
        $_SESSION['status'] = "New password must at least have 1 lower case letter and 1 upper case letter"; 
        header("Location: /ewaste/change-password/$code");
        exit(0);
    }

    if(!$number) 
    {
        $_SESSION['status'] = "New password must have a number"; 
        header("Location: /ewaste/change-password/$code");
        exit(0);
    }

    if(!$specialChars) 
    {
        $_SESSION['status'] = "New password must have a special character"; 
        header("Location: /ewaste/change-password/$code");
        exit(0);
    }

    if($new_pass != $confirm_new_pass)
    {
        $_SESSION['status'] = "Password and Confirm Password must match"; 
        header("Location: /ewaste/change-password/$code");
        exit(0);
    }
   

    $row = mysqli_fetch_array($getEmailQuery);
    $email = $row["email"];

    $query_2 = mysqli_query($con, "UPDATE userOrg SET opass = '".md5($new_pass)."' WHERE email = '$email' ");

    if($query_2) 
    {
        $_SESSION['action'] = "Resetted Password";

        $org_data = "SELECT id, username, email FROM userorg WHERE email = '$email' ";
        $org_data_run = mysqli_query($con, $org_data);
        $row = mysqli_fetch_array($org_data_run);
        $id = $row['id'];
        $username = $row['username'];
        $email = $row['email'];

        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('$id', '$username', '$email', 'org', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($log_query_run)
        {
            $_SESSION['status'] = "Password updated"; 
            header("Location: /ewaste/login");
            exit(0);
        }
    }
    else
    {
        exit("Something went wrong");
    }
}


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link rel="stylesheet" href="/ewaste/css/login-pages.css">
</head>
<body>
    <div class="cardshadow">
        <div class="col-10 m-auto text-center">
            <?php
                if(isset($_SESSION['status']))
                {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }
            ?>
            <div class="head mb-3 mt-4" style="font-size: 40px; font-weight: 700; color:white;">Change Password</div>
        
            <form method="POST">
                <div class="form-group mb-3">
                    <label style="color:#1e1e2d; font-weight:500; margin:0;font-size:15px; color:white; position: relative; top: 1px; left: -145px; text-align: left;">New Password</label>
                    <input type="password" name="new_pass" class="form-control" placeholder="Enter New Password"  id="id_password" required>
                    <i class="far fa-eye" id="togglePassword" style="margin-right: -360px; margin-top: -26px; cursor: pointer;"></i>
                </div>

                <div class="form-group mb-3">
                <label style="color:#1e1e2d; font-weight:500; margin:0;font-size:15px; color:white; position: relative; top: 1px; left: -115px; text-align: left;">Confirm New Password</label>
                    <input type="password" name="confirm_new_pass" class="form-control" placeholder="Re Enter New Password"  id="id_confirm_password" required>
                    <i class="far fa-eye" id="toggleconfirmPassword" style="margin-right: -360px; margin-top: -26px; cursor: pointer;"></i>
                </div>

                <div class="form-group mb-3">
                    <button type="submit" name="changepass_btn" class="btn">Update Password</button>
                </div>
                
            </form>
        </div>
    </div>
</body>
</html>

<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirm_password');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>