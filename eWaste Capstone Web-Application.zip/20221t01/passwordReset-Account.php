<?php

session_start();

$page_title = "Password Change Update";
include('includes/header.php');
include('includes/navbar.php');

include('dbcon.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/login-pages.css">
    <style>
        .btn {
            width: 60% !important;
        }
    </style>
</head>
<body>
    <div class="cardshadow">
        <div class="col-10 m-auto text-center">
            <?php
                if(isset($_SESSION['status']))
                {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }
            ?>

            <div class="head mb-3 mt-5" style="font-size: 40px; font-weight: 700; color: white; position: relative; top: -30px; left: -10px;">Forgot Password?</div>

                <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:15px; color: white; position: relative; top: -30px; left: 15px; text-align: left;"> Please choose which account type you would want to recover your password from:</h1>
                <div class="form-group mb-3">
                    <button onClick="location.href='/ewaste/password-reset-restaurant'" class="btn">Restaurant</button>
                </div>

                <div class="form-group mb-3">
                    <button onClick="location.href='/ewaste/password-reset-organization'" class="btn">Organization</button>
                </div>
                    
            
        </div>
    </div>
</body>
</html>

