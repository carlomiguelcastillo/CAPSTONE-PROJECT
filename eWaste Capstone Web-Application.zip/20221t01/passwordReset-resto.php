<?php

session_start();

$page_title = "Password Change Update";
include('includes/header.php');
include('includes/navbar.php');

include('dbcon.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if(isset($_POST["resetpassbtn_resto"]))
{
    $email = $_POST['email'];

    $check_email_query = "SELECT email FROM userResto WHERE email = ? AND verify_status = '1' LIMIT 1";
    $stmt = mysqli_prepare($con, $check_email_query);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $check_email_query_run = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($check_email_query_run) > 0)
    {
        $emailTo = $_POST["email"];

        $code = uniqid(true);
        $query = mysqli_query($con, "INSERT INTO resetPass(code, email) VALUES ('$code' , '$emailTo')");
        if(!$query)
        {
            exit("Error");
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP(); //Send using SMTP
            $mail->SMTPAuth = true; //Enable SMTP authentication
        
            $mail->Host = 'smtp.gmail.com';       //Set the SMTP server to send through
            $mail->Username = 'randomizerp00p@gmail.com';   //SMTP username
            $mail->Password = 'gcqbyavzkpvnzcmb';             //SMTP password
        
            $mail->SMTPSecure = "tls";              //Enable implicit TLS encryption
            $mail->Port       = 587;
        
            $mail->setFrom('randomizerp00p@gmail.com', 'eWaste'); // Coming from which  email and the title of the email
            $mail->addAddress($emailTo);  
        
            $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]) . "/change-password-resto/$code";
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Reset Password Notification from eWaste';
            $mail->Body    = "<h1> <a href='$url'> Click this link to reset your password </a></h1>"; // Inside the email
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        
            $mail->send();
            $_SESSION['status'] = "Reset password link has been sent to your email"; 
            header("Location: /ewaste/password-reset-restaurant");
            exit(0);
        } catch (Exception $e) {
            echo 'Message could not be sent. Mailer error' , $mail->ErrorInfo;
        }
        exit();
    }
    else
    {
        $_SESSION['status'] = "Email not found"; 
        header("Location: /ewaste/password-reset-restaurant");
        exit(0);
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/login-pages.css">
</head>
<body>
    <div class="cardshadow">
        <div class="col-10 m-auto text-center">
            <?php
            if(isset($_SESSION['status']))
            {
                echo "<h4>" . $_SESSION['status'] . "</h4>";
                unset($_SESSION['status']);
            }
            ?>
                <div class="head mb-3 mt-4" style="font-size: 40px; font-weight: 700; color: white;">Forgot Password?</div>
                
                <h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:15px; color: white; position: relative; top: 1px; left: 10px; text-align: left;"> Please enter the email 
                address that is associated with your account and we will email you the link to reset your password. </h1>
                                
                <form action="/ewaste/password-reset-restaurant" method="POST">

                    <div class="d-flex justify-content-center mt-4">
                        <input type="text" name="email" class="form-control" placeholder="Enter Email Address" required>
                    </div>

                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" name="resetpassbtn_resto" class="btn">Reset Password</button>
                    </div>
                    
                </form>
            
        </div>
    </div>
</body>
</html>

