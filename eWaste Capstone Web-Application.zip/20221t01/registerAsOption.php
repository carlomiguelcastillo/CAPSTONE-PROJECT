<?php 
$page_title = "Register Page";
include('includes/header.php');
include('includes/navbar.php');
include('logged.php');

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Register As Organization</title>
        <!-- BOOTSTRAP PACKAGE CDN -->
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
        <style>
           body {
            background-image: url('image/bg.jpg');
            height: 300px; 
            background-repeat: no-repeat;
            background-size: cover;  
            background-attachment: fixed;
            overflow: hidden; 
            }
          
            .container {
            width:500px;
            margin:13% auto;
            padding:10px;
            border-radius: 20px;
            background-color: rgba(0,0,0,0.23);
            box-shadow: 0 0 17px rgb(25, 24, 24);
           
            }
           
            .card-body {
            width:400px;
            margin:5% auto;
            padding:10px;
            border-radius: 20px;
            text-align: center;
            }
            
            .btn {
            width: 50%;
	        background: black;
	        color: white !important;
            font-size: large;
            font-weight: bold;
            margin-bottom: 25px;
            
            }
        </style>
</head>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="head mb-3 mt-5" style="font-size: 40px; font-weight:700; color: white;">Register As</div>
            </div>
                <div class="card-body">
                    <form action="register-restaurant">
                        <div class="form-group">
                        <button name="submit" class="btn" type="submit">Restaurant</button>
                        </div>
                    </form>
                        
                    <form action="register-organization">
                        <div class="form-group">
                        <button name="submit" class="btn" type="submit">Organization</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


