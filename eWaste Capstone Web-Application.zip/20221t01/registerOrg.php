<?php 
session_start();

$page_title = "Register Page for Organizations";
include('includes/header.php');
include('includes/navbar.php');
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register As Organization</title>
    <!-- BOOTSTRAP PACKAGE CDN -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="stylesheet" href="css/register.css">
    <style>
        .g-recaptcha {
            position: relative;
            top: 10px;
            left: 1;
            width: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <form action="code.php" method="POST" enctype="multipart/form-data">
            <div class="register-org">
                <div class="col-12 text-center mb-2">
                <?php
                    if(isset($_SESSION['status']))
                    {
                        echo "<h4 class='status'>" . $_SESSION['status'] . "</h4>";
                        unset($_SESSION['status']);
                    }
                ?>
                <h3>REGISTER AS ORGANIZATION</h3>
                </div>
                                    
                <div class="row p-3">
                    <h1>User Information</h1>
                    <div class="col-6 mb-2">
                        <p>First Name</p>
                        <input type="text" name="fname" class="box" value="<?php echo isset($_SESSION['fname-org']) ? $_SESSION['fname-org'] : ''; ?>" required>
                        <div class="validation-message-fname-org"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Last Name</p>
                        <input type="text" name="lname" class="box" value="<?php echo isset($_SESSION['lname-org']) ? $_SESSION['lname-org'] : ''; ?>" required>
                        <div class="validation-message-lname-org"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Username</p>
                        <input type="text" name="username" class="box" value="<?php echo isset($_SESSION['username-register-org']) ? $_SESSION['username-register-org'] : ''; ?>" required>
                        <div class="validation-message-username-org"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Mobile Number</p>
                        <input type="text" name="mobilenum" class="box" value="<?php echo isset($_SESSION['mobilenum-org']) ? $_SESSION['mobilenum-org'] : ''; ?>" required>
                        <div class="validation-message-mobilenum-org"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Birthdate</p>
                        <input type="date" name="birthdate" class="box" value="<?php echo isset($_SESSION['birthdate-org']) ? $_SESSION['birthdate-org'] : ''; ?>" required>
                        <div class="validation-message-birthdate-org"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Email</p>
                        <input type="email" name="email" class="box" value="<?php echo isset($_SESSION['email-org']) ? $_SESSION['email-org'] : ''; ?>" required>
                        <div class="validation-message-email-org"></div>
                    </div>
                </div>

                <div class="row p-3">       
                    <h1>Organization Details</h1>
                        <div class="col-6 mb-2">
                            <p>Name of Organization</p>
                            <input type="text" name="orgName" class="box" value="<?php echo isset($_SESSION['orgname-org']) ? $_SESSION['orgname-org'] : ''; ?>" required>
                            <div class="validation-message-orgname-org"></div>
                        </div>

                        <div class="col-6 mb-2">
                            <p>Services Offered</p>
                            <select name="services" class="form-control" required> 
                                <option value="">Select one...</option>
                                <option value="Food Rescue/ Charity"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Food Rescue/ Charity' ? ' selected' : ''; ?>>Food Rescue/ Charity</option>
                                <option value="Composting"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Composting' ? ' selected' : ''; ?>>Composting</option>
                                <option value="Data Collection"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Data Collection' ? ' selected' : ''; ?>>Data Collection</option>
                                <option value="Environmental"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Environmental' ? ' selected' : ''; ?>>Environmental</option>
                                <option value="Social"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Social' ? ' selected' : ''; ?>>Social</option>
                                <option value="Advocacy"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Advocacy' ? ' selected' : ''; ?>>Advocacy</option>
                                <option value="Human Rights"<?php echo isset($_SESSION['services-org']) && $_SESSION['services-org'] == 'Human Rights' ? ' selected' : ''; ?>>Human Rights</option>
                            </select>
                        </div>              

                        <div class="col-6 mb-2">
                            <p>Description of Organization</p>
                            <textarea autofocus name="desc" id="desc" rows="4" cols="30" style="width: 300px; height: 100px; border-radius:6px; border: 1px solid black;" 
                            placeholder= "Say something about your organization and describe its business" maxlength="512" minlength="15" 
                            required><?php echo isset($_SESSION['desc-org']) ? $_SESSION['desc-org'] : ''; ?></textarea>
                            <div class="validation-message-desc"></div>
                        </div>

                        <div class="col-6 mb-2">
                            <p>Building Permit</p>
                            <input type="file" name="file" required>
                        </div>

                        <div class="col-6 mb-2">
                        <p>Region</p>
                        <select name="region" id="region" class="form-control" required> 
                            <option value="">Select one...</option>
                            <option value="NCR">National Capital Region (NCR)</option>
                        </select>
                    </div>

                    <div class="col-6 mb-2">
                        <p>City</p>
                        <select name="city" id="city" class="form-control cityList" required> 
                            <option value="">Select one...</option>
                            <option value="Caloocan"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Caloocan' ? ' selected' : ''; ?>>Caloocan</option>
                            <option value="Las Piñas"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Las Piñas' ? ' selected' : ''; ?>>Las Piñas</option>
                            <option value="Makati"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Makati' ? ' selected' : ''; ?>>Makati</option>
                            <option value="Malabon"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Malabon' ? ' selected' : ''; ?>>Malabon</option>
                            <option value="Mandaluyong"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Mandaluyong' ? ' selected' : ''; ?>>Mandaluyong</option>
                            <option value="Manila"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Manila' ? ' selected' : ''; ?>>Manila</option>
                            <option value="Marikina"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Marikina' ? ' selected' : ''; ?>>Marikina</option>
                            <option value="Muntinlupa"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Muntinlupa' ? ' selected' : ''; ?>>Muntinlupa</option>
                            <option value="Navotas"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Navotas' ? ' selected' : ''; ?>>Navotas</option>
                            <option value="Parañaque"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Parañaque' ? ' selected' : ''; ?>>Parañaque</option>
                            <option value="Pasay"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Pasay' ? ' selected' : ''; ?>>Pasay</option>
                            <option value="Pasig"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Pasig' ? ' selected' : ''; ?>>Pasig</option>
                            <option value="Quezon City"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Quezon City' ? ' selected' : ''; ?>>Quezon City</option>
                            <option value="San Juan"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'San Juan' ? ' selected' : ''; ?>>San Juan</option>
                            <option value="Taguig"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Taguig' ? ' selected' : ''; ?>>Taguig</option>
                            <option value="Valenzuela"<?php echo isset($_SESSION['city']) && $_SESSION['city'] == 'Valenzuela' ? ' selected' : ''; ?>>Valenzuela</option>
                        </select>
                    </div>

                    <p>Barangay: </p>
                    <div class="col-6 mb-2" id="result">
                        <select class="form-control">
                            <option value="">Select one...</option>
                            
                        </select>
                    </div>

                        <div class="col-6 mb-2" style="margin-top: -31px;">
                            <p>House No./ Bldg./ Street</p>
                            <input type="text" name="offAddress" class="box" value="" required>
                            <div class="validation-message-offaddress-org"></div>
                        </div>
                        
                        <div class="col-6 mb-2">
                            <p>Password</p>
                            <input type="password" name="opass"id="id_password" class="box" required>
                            <i class="far fa-eye" id="togglePassword" style="margin-right: -200px; margin-top: -30px; margin-left: -30px; cursor: pointer;"></i>
                            <div class="validation-message-password-org"></div>
                        </div>

                        <div class="col-6 mb-2">
                            <p>Address Line 2 (Optional)</p>
                            <input type="text" name="offAddress2" class="box" >
                            <div class="validation-message-offaddress2-org"></div>
                        </div>
                                                     
                        <div class="col-6 mb-2">
                            <p>Confirm Password</p>
                            <input type="password" name="oconfirmpass" id="id_confirmpassword"  class="box" required>
                            <i class="far fa-eye" id="toggleconfirmPassword" style="margin-right: -200px; margin-top: -30px; margin-left: -30px; cursor: pointer;"></i>
                            <div class="validation-message-confirm-password-org"></div>
                        </div>

                        <div class="g-recaptcha" data-sitekey="6LeqsEclAAAAAPe0qg2sDpTDIf3A0hAVcs7BZJa9"></div>  


                    <div class="col-12 mb-2" style="padding-top: 25px;"> <label style="font-weight: 600;">
                        <input type="checkbox" name="privacy_policy" required> By ticking this box I agree that I have read the Privacy Policy.
                    </div> </label>
                    <p style="font-size: 16px;">Read our <a href="javascript:void(0);" onclick="openPrivacyPolicy()">Privacy Policy</a> 
                    for information on how we handle your data and what your rights are.</p> <hr>
                    
                    <div class="d-flex justify-content-center">
                        <button type="submit" name="registerOrg_btn" class="btn" onclick="return validateForm()" style="margin-right:15px; font-weight: bold;">Register</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

</body>
</html>

<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    function openPrivacyPolicy() {
        window.open('privacy_policy.html', 'Privacy Policy', 'width=600,height=400');
        }
</script>

<script>
    const inputFieldFname = document.querySelector('input[name="fname"]');
    const validationMessageFname = document.querySelector('.validation-message-fname-org');
    inputFieldFname.addEventListener('input', (event) => {
        const inputValueFname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueFname);
        if (inputValueFname.length < 2) {
            validationMessageFname.textContent = 'First name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageFname.textContent = 'First name should not contain numbers or special characters';
        } else {
            validationMessageFname.textContent = '';
        }
    });

    const inputFieldLname = document.querySelector('input[name="lname"]');
    const validationMessageLname = document.querySelector('.validation-message-lname-org');
    inputFieldLname.addEventListener('input', (event) => {
        const inputValueLname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueLname);
        if (inputValueLname.length < 2) {
            validationMessageLname.textContent = 'Last name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageLname.textContent = 'Last name should not contain numbers or special characters';
        } else {
            validationMessageLname.textContent = '';
        }
    });

    const inputFieldUsername = document.querySelector('input[name="username"]');
    const validationMessageUsername = document.querySelector('.validation-message-username-org');
    inputFieldUsername.addEventListener('input', (event) => {
        const inputValueUsername = event.target.value;
        const hasSpecialChars = /[^a-zA-Z0-9]/.test(inputValueUsername);
        if (inputValueUsername.length < 5) {
            validationMessageUsername.textContent = 'Username must be at least 5 characters long';
        } else if (hasSpecialChars) {
            validationMessageUsername.textContent = 'Username should not contian special characters';
        } else {
            validationMessageUsername.textContent = '';
        }
    });

    const inputFieldMobileNum = document.querySelector('input[name="mobilenum"]');
    const validationMessageMobileNum = document.querySelector('.validation-message-mobilenum-org');
    inputFieldMobileNum.addEventListener('input', (event) => {
        const inputValueMobileNum = event.target.value;
        const hasSpecialChars = /[^0-9]/.test(inputValueMobileNum);
        if (inputValueMobileNum.length !== 11) {
            validationMessageMobileNum.textContent = 'Mobile Number should be 11 digits';
        } else if (hasSpecialChars) {
            validationMessageMobileNum.textContent = 'Mobile Number should only contain numbers';
        } else {
            validationMessageMobileNum.textContent = '';
        }
    });

    const inputFieldBirthdate = document.querySelector('input[name="birthdate"]');
    const validationMessageBirthdate = document.querySelector('.validation-message-birthdate-org');
    inputFieldBirthdate.addEventListener('input', (event) => {
        const inputValueBirthdate = event.target.value;
        const inputDate = new Date(inputValueBirthdate);
        const maxDate = new Date('2005-01-01');

        if (inputDate > maxDate) {
            validationMessageBirthdate.textContent = 'Must be older than 18';
        } else {
            validationMessageBirthdate.textContent = '';
        }
        });

    const inputFieldEmail = document.querySelector('input[name="email"]');
    const validationMessageEmail = document.querySelector('.validation-message-email-org');
        inputFieldEmail.addEventListener('input', (event) => {
        const inputValueEmail = event.target.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(inputValueEmail)) {
            validationMessageEmail.textContent = 'Please enter a valid email address';
        } else {
            validationMessageEmail.textContent = '';
        }
        });

    const inputFieldRestoname = document.querySelector('input[name="orgName"]');
    const validationMessageRestoname = document.querySelector('.validation-message-orgname-org');
    inputFieldRestoname.addEventListener('input', (event) => {
        const inputValueRestoname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueRestoname);
        if (inputValueRestoname.length < 2) {
            validationMessageRestoname.textContent = 'Organization name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageRestoname.textContent = 'Organization name should not contain numbers or special characters';
        } else {
            validationMessageRestoname.textContent = '';
        }
    });

    const inputFieldDescription = document.querySelector('textarea[name="desc"]');
    const validationMessageDescription = document.querySelector('.validation-message-desc');
    inputFieldDescription.addEventListener('input', (event) => {
        const inputValueDescription = event.target.value;
        if (inputValueDescription.length < 15) {
            validationMessageDescription.textContent = 'Description must be at least 15 characters long';
        } else {
            validationMessageDescription.textContent = '';
        }
    });

    const inputFieldAddress = document.querySelector('input[name="offAddress"]');
    const validationMessageAddress = document.querySelector('.validation-message-offaddress-org');
    inputFieldAddress.addEventListener('input', (event) => {
    const inputValueAddress = event.target.value.trim();
    const addressRegex = /^[a-zA-Z0-9\s,'-]*$/;
    
    if (inputValueAddress.length < 5) {
        validationMessageAddress.textContent = 'Address must be at least 5 characters long';
    } else if (!addressRegex.test(inputValueAddress)) {
        validationMessageAddress.textContent = 'Address can only contain letters, numbers, spaces, commas, apostrophes, and dashes';
    } else {
        validationMessageAddress.textContent = '';
    }
    });

    const inputFieldAddress2 = document.querySelector('input[name="offAddress2"]');
    const validationMessageAddress2 = document.querySelector('.validation-message-offaddress2-org');
    inputFieldAddress2.addEventListener('input', (event) => {
    const inputValueAddress2 = event.target.value.trim();
    const addressRegex = /^[a-zA-Z0-9\s,'-]*$/;
    
    if (inputValueAddress2.length < 5) {
        validationMessageAddress2.textContent = 'Address must be at least 5 characters long';
    } else if (!addressRegex.test(inputValueAddress)) {
        validationMessageAddress2.textContent = 'Address can only contain letters, numbers, spaces, commas, apostrophes, and dashes';
    } else {
        validationMessageAddress2.textContent = '';
    }
    });

    const inputFieldPassword = document.querySelector('input[name="opass"]');
    const inputFieldConfirmPassword = document.querySelector('input[name="oconfirmpass"]');
    const validationMessagePassword = document.querySelector('.validation-message-password-org');
    const validationMessageConfirmPassword = document.querySelector('.validation-message-confirm-password-org');
    inputFieldPassword.addEventListener('input', (event) => {
    const inputValuePassword = event.target.value;
    const inputValueConfirmPassword = inputFieldConfirmPassword.value;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;
    
    if (!passwordRegex.test(inputValuePassword)) {
        validationMessagePassword.textContent = 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character';
    } else {
        validationMessagePassword.textContent = '';
    }
    
    if (inputValuePassword !== inputValueConfirmPassword) {
        validationMessageConfirmPassword.textContent = 'Passwords do not match';
    } else {
        validationMessageConfirmPassword.textContent = '';
    }
    });

    inputFieldConfirmPassword.addEventListener('input', (event) => {
    const inputValuePassword = inputFieldPassword.value;
    const inputValueConfirmPassword = event.target.value;
    
    if (inputValuePassword !== inputValueConfirmPassword) {
        validationMessageConfirmPassword.textContent = 'Passwords do not match';
    } else {
        validationMessageConfirmPassword.textContent = '';
    }
    });

</script>

<script>
    function validateForm() {
    var response = grecaptcha.getResponse();
    if (response.length == 0) {
        document.getElementById('recaptcha-error').style.display = 'block';
        return false;
    } else {
        return true;
    }
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $(".cityList").change(function () {
            var selectedCity = $(".cityList option:selected").val();
            $.ajax({
                type: "POST",
                url: "fetch.php",
                data: { cityList: selectedCity },
            }).done(function (data) {
                $("#result").html(data);
            }); 
        });
    });
</script>