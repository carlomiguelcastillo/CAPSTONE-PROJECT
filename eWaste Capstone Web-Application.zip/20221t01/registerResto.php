<?php 
session_start();
$page_title = "Register Page for Restaurants";
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register As Restaurant</title>
    <!-- BOOTSTRAP PACKAGE CDN -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="stylesheet" href="css/register.css">
    <style>
        .g-recaptcha {
            position: relative;
            top: -70px;
            left: 1;
            width: 10px;
            height: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="code.php" method="POST" enctype="multipart/form-data">
            <div class="register-resto">
                <div class="col-12 text-center mb-2">
                    <?php
                        if(isset($_SESSION['status']))
                        {
                            echo "<h4 class='status'>" . $_SESSION['status'] . "</h4>";
                            unset($_SESSION['status']);
                        }
                    ?>
                    <span id="recaptcha-error" style="display:none;">Please complete the reCAPTCHA</span>
                <h3>REGISTER AS RESTAURANT</h2>
                </div>
                <div class="row p-3">
                    <h1>General Info</h1>
                    <div class="col-6 mb-2">
                        <p>First Name</p>
                        <input type="text" name="fname" class="box" value="<?php echo isset($_SESSION['fname']) ? $_SESSION['fname'] : ''; ?>" required>
                        <div class="validation-message-fname"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Last Name</p>
                        <input type="text" name="lname" class="box" value="<?php echo isset($_SESSION['lname']) ? $_SESSION['lname'] : ''; ?>" required>
                        <div class="validation-message-lname"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Username</p>
                        <input type="text" name="username" class="box" value="<?php echo isset($_SESSION['username-register-resto']) ? $_SESSION['username-register-resto'] : ''; ?>" required>
                        <div class="validation-message-username"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Mobile Number</p>
                        <input type="text" name="mobilenum" class="box" value="<?php echo isset($_SESSION['mobilenum']) ? $_SESSION['mobilenum'] : ''; ?>" required>
                        <div class="validation-message-mobilenum"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Birthdate</p>
                        <input type="date" name="birthdate" class="box" value="<?php echo isset($_SESSION['birthdate']) ? $_SESSION['birthdate'] : ''; ?>" required>
                        <div class="validation-message-birthdate"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Email</p>
                        <input type="email" name="email" class="box" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>" required>
                        <div class="validation-message-email"></div>
                    </div>
                </div>
             
                <div class="row p-3" >       
                    <h1>Restaurant Details</h1>      
                    <div class="col-6 mb-2">
                        <p>Restaurant Name</p>
                        <input type="text" name="restoname" class="box" value="<?php echo isset($_SESSION['restoname']) ? $_SESSION['restoname'] : ''; ?>" required>
                        <div class="validation-message-restoname"></div>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Restaurant Type</p>
                        <select name="restotype" class="form-control" required> 
                            <option value="">Select one...</option>
                            <option value="Fast Food"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Fast Food' ? ' selected' : ''; ?>>Fast Food</option>
                            <option value="Casual Dining"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Casual Dining' ? ' selected' : ''; ?>>Casual Dining</option>
                            <option value="Fine Dining"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Fine Dining' ? ' selected' : ''; ?>>Fine Dining</option>
                            <option value="Cafe Style/Coffee"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Cafe Style/Coffee' ? ' selected' : ''; ?>>Cafe Style/Coffee</option>
                            <option value="Buffet"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Buffet' ? ' selected' : ''; ?>>Buffet</option>
                            <option value="Food Truck"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Food Truck' ? ' selected' : ''; ?>>Food Truck</option>
                            <option value="Concession Stand"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Concession Stand' ? ' selected' : ''; ?>>Concession Stand</option>
                            <option value="Pop-Up"<?php echo isset($_SESSION['restotype']) && $_SESSION['restotype'] == 'Pop-Up' ? ' selected' : ''; ?>>Pop-Up</option>
                        </select>
                    </div>
                   
                    <div class="col-6 mb-2">
                        <p>Region</p>
                        <select name="region" id="region" class="form-control" required> 
                            <option value="">Select one...</option>
                            <option value="NCR">National Capital Region (NCR)</option>
                        </select>
                    </div>

                    <div class="col-6 mb-2">
                        <p>City</p>
                        <select name="rcity" id="city" class="form-control cityList" required> 
                            <option value="">Select one...</option>
                            <option value="Caloocan"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Caloocan' ? ' selected' : ''; ?>>Caloocan</option>
                            <option value="Las Piñas"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Las Piñas' ? ' selected' : ''; ?>>Las Piñas</option>
                            <option value="Makati"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Makati' ? ' selected' : ''; ?>>Makati</option>
                            <option value="Malabon"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Malabon' ? ' selected' : ''; ?>>Malabon</option>
                            <option value="Mandaluyong"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Mandaluyong' ? ' selected' : ''; ?>>Mandaluyong</option>
                            <option value="Manila"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Manila' ? ' selected' : ''; ?>>Manila</option>
                            <option value="Marikina"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Marikina' ? ' selected' : ''; ?>>Marikina</option>
                            <option value="Muntinlupa"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Muntinlupa' ? ' selected' : ''; ?>>Muntinlupa</option>
                            <option value="Navotas"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Navotas' ? ' selected' : ''; ?>>Navotas</option>
                            <option value="Parañaque"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Parañaque' ? ' selected' : ''; ?>>Parañaque</option>
                            <option value="Pasay"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Pasay' ? ' selected' : ''; ?>>Pasay</option>
                            <option value="Pasig"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Pasig' ? ' selected' : ''; ?>>Pasig</option>
                            <option value="Quezon City"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Quezon City' ? ' selected' : ''; ?>>Quezon City</option>
                            <option value="San Juan"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'San Juan' ? ' selected' : ''; ?>>San Juan</option>
                            <option value="Taguig"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Taguig' ? ' selected' : ''; ?>>Taguig</option>
                            <option value="Valenzuela"<?php echo isset($_SESSION['rcity']) && $_SESSION['rcity'] == 'Valenzuela' ? ' selected' : ''; ?>>Valenzuela</option>
                        </select>
                    </div>

                    <p>Restaurant's Barangay: </p>
                    <div class="col-6 mb-2" id="result">
                        <select class="form-control">
                            <option value="">Select one...</option>
                            
                        </select>
                    </div>

                    <div class="col-6 mb-2" style="margin-top: -31px;">
                        <p>Restaurant's House No./ Bldg./ Street</p>
                        <input type="text" name="raddress" class="box" value="<?php echo isset($_SESSION['raddress']) ? $_SESSION['raddress'] : ''; ?>" required>
                        <div class="validation-message-raddress"></div>
                    </div>

                    <div class="col-6 mb-2">
                        <p>Restaurant's Address Line 2 (Optional)</p>
                        <input type="text" name="raddress2" class="box" >
                        <div class="validation-message-raddress2"></div>
                    </div>

                    <div class="col-6 mb-2">
                        <p>Food Establishment License</p>
                        <input type="file" name="file" class="box" required>
                    </div>   

                    <div class="col-6 mb-2">
                        <p>Password</p>
                        <input type="password" name="rpass" class="box" id="id_password" required>
                        <i class="far fa-eye" id="togglePassword" style="margin-right: -200px; margin-top: -30px; margin-left: -30px; cursor: pointer;"></i>
                        <div class="validation-message-password"></div>
                        
                    </div>
                    <div class="col-6 mb-2">
                        <p style="font-size: 18px; margin-bottom:4px;"></p>
                        <input type="hidden" name="" class="box" required>
                    </div>
                    <div class="col-6 mb-2">
                        <p>Confirm Password</p>
                        <input type="password" name="rconfirmpass" class="box" id="id_confirmpassword" required>
                        <i class="far fa-eye" id="toggleconfirmPassword" style="margin-right: -200px; margin-top: -30px; margin-left: -30px; cursor: pointer;"></i>
                        <div class="validation-message-confirm-password"></div>
                    </div>

                    <div class="g-recaptcha" data-sitekey="6LeqsEclAAAAAPe0qg2sDpTDIf3A0hAVcs7BZJa9"></div>                 

                    <div class="col-12 mb-2" > <label style="font-weight: 600;">
                        <input type="checkbox" name="privacy_policy" required> By ticking this box I agree that I have read the Privacy Policy.
                    </div> </label>
                    <p style="font-size: 16px;">Read our <a href="javascript:void(0);" onclick="openPrivacyPolicy()">Privacy Policy</a> 
                    for information on how we handle your data and what your rights are.</p><hr>
                
                    <div class="d-flex justify-content-center">
                        <button type="submit" name="registerResto_btn" class="btn" onclick="return validateForm()">Register</button>
                    </div>
                </div>
            </div>                                            
        </form>
    </div>
</body>
</html>
<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    function openPrivacyPolicy() {
    window.open('privacy_policy.html', 'Privacy Policy', 'width=600,height=400');
    }
</script>

<script>
    const inputFieldFname = document.querySelector('input[name="fname"]');
    const validationMessageFname = document.querySelector('.validation-message-fname');
    inputFieldFname.addEventListener('input', (event) => {
        const inputValueFname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueFname);
        if (inputValueFname.length < 2) {
            validationMessageFname.textContent = 'First name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageFname.textContent = 'First name should not contain numbers or special characters';
        } else {
            validationMessageFname.textContent = '';
        }
    });

    const inputFieldLname = document.querySelector('input[name="lname"]');
    const validationMessageLname = document.querySelector('.validation-message-lname');
    inputFieldLname.addEventListener('input', (event) => {
        const inputValueLname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueLname);
        if (inputValueLname.length < 2) {
            validationMessageLname.textContent = 'Last name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageLname.textContent = 'Last name should not contain numbers or special characters';
        } else {
            validationMessageLname.textContent = '';
        }
    });

    const inputFieldUsername = document.querySelector('input[name="username"]');
    const validationMessageUsername = document.querySelector('.validation-message-username');
    inputFieldUsername.addEventListener('input', (event) => {
        const inputValueUsername = event.target.value;
        const hasSpecialChars = /[^a-zA-Z0-9]/.test(inputValueUsername);
        if (inputValueUsername.length < 5) {
            validationMessageUsername.textContent = 'Username must be at least 5 characters long';
        } else if (hasSpecialChars) {
            validationMessageUsername.textContent = 'Username should not contian special characters';
        } else {
            validationMessageUsername.textContent = '';
        }
    });

    const inputFieldMobileNum = document.querySelector('input[name="mobilenum"]');
    const validationMessageMobileNum = document.querySelector('.validation-message-mobilenum');
    inputFieldMobileNum.addEventListener('input', (event) => {
        const inputValueMobileNum = event.target.value;
        const hasSpecialChars = /[^0-9]/.test(inputValueMobileNum);
        if (inputValueMobileNum.length !== 11) {
            validationMessageMobileNum.textContent = 'Mobile Number should be 11 digits';
        } else if (hasSpecialChars) {
            validationMessageMobileNum.textContent = 'Mobile Number should only contain numbers';
        } else {
            validationMessageMobileNum.textContent = '';
        }
    });

    const inputFieldBirthdate = document.querySelector('input[name="birthdate"]');
    const validationMessageBirthdate = document.querySelector('.validation-message-birthdate');
    inputFieldBirthdate.addEventListener('input', (event) => {
        const inputValueBirthdate = event.target.value;
        const inputDate = new Date(inputValueBirthdate);
        const maxDate = new Date('2005-01-01');

        if (inputDate > maxDate) {
            validationMessageBirthdate.textContent = 'Must be older than 18';
        } else {
            validationMessageBirthdate.textContent = '';
        }
        });

    const inputFieldEmail = document.querySelector('input[name="email"]');
    const validationMessageEmail = document.querySelector('.validation-message-email');
        inputFieldEmail.addEventListener('input', (event) => {
        const inputValueEmail = event.target.value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(inputValueEmail)) {
            validationMessageEmail.textContent = 'Please enter a valid email address';
        } else {
            validationMessageEmail.textContent = '';
        }
        });

    const inputFieldRestoname = document.querySelector('input[name="restoname"]');
    const validationMessageRestoname = document.querySelector('.validation-message-restoname');
    inputFieldRestoname.addEventListener('input', (event) => {
        const inputValueRestoname = event.target.value;
        const hasNumbersOrSpecialChars = /[^a-zA-Z\s]/.test(inputValueRestoname);
        if (inputValueRestoname.length < 2) {
            validationMessageRestoname.textContent = 'Restaurant name must be at least 2 characters long';
        } else if (hasNumbersOrSpecialChars) {
            validationMessageRestoname.textContent = 'Restaurant name should not contain numbers or special characters';
        } else {
            validationMessageRestoname.textContent = '';
        }
    });

    const inputFieldAddress = document.querySelector('input[name="raddress"]');
    const validationMessageAddress = document.querySelector('.validation-message-raddress');
    inputFieldAddress.addEventListener('input', (event) => {
    const inputValueAddress = event.target.value.trim();
    const addressRegex = /^[a-zA-Z0-9\s,'-]*$/;
    
    if (inputValueAddress.length < 5) {
        validationMessageAddress.textContent = 'Address must be at least 5 characters long';
    } else if (!addressRegex.test(inputValueAddress)) {
        validationMessageAddress.textContent = 'Address can only contain letters, numbers, spaces, commas, apostrophes, and dashes';
    } else {
        validationMessageAddress.textContent = '';
    }
    });

    const inputFieldAddress2 = document.querySelector('input[name="raddress2"]');
    const validationMessageAddress2 = document.querySelector('.validation-message-raddress2');
    inputFieldAddress2.addEventListener('input', (event) => {
    const inputValueAddress2 = event.target.value.trim();
    const addressRegex = /^[a-zA-Z0-9\s,'-]*$/;
    
    if (inputValueAddress2.length < 5) {
        validationMessageAddress2.textContent = 'Address must be at least 5 characters long';
    } else if (!addressRegex.test(inputValueAddress2)) {
        validationMessageAddress2.textContent = 'Address can only contain letters, numbers, spaces, commas, apostrophes, and dashes';
    } else {
        validationMessageAddress2.textContent = '';
    }
    });

    const inputFieldPassword = document.querySelector('input[name="rpass"]');
    const inputFieldConfirmPassword = document.querySelector('input[name="rconfirmpass"]');
    const validationMessagePassword = document.querySelector('.validation-message-password');
    const validationMessageConfirmPassword = document.querySelector('.validation-message-confirm-password');
    inputFieldPassword.addEventListener('input', (event) => {
    const inputValuePassword = event.target.value;
    const inputValueConfirmPassword = inputFieldConfirmPassword.value;
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]).{8,}$/;
    
    if (!passwordRegex.test(inputValuePassword)) {
        validationMessagePassword.textContent = 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character';
    } else {
        validationMessagePassword.textContent = '';
    }
    
    if (inputValuePassword !== inputValueConfirmPassword) {
        validationMessageConfirmPassword.textContent = 'Passwords do not match';
    } else {
        validationMessageConfirmPassword.textContent = '';
    }
    });

    inputFieldConfirmPassword.addEventListener('input', (event) => {
    const inputValuePassword = inputFieldPassword.value;
    const inputValueConfirmPassword = event.target.value;
    
    if (inputValuePassword !== inputValueConfirmPassword) {
        validationMessageConfirmPassword.textContent = 'Passwords do not match';
    } else {
        validationMessageConfirmPassword.textContent = '';
    }
    });

</script>

<script>
    function validateForm() {
    var response = grecaptcha.getResponse();
    if (response.length == 0) {
        document.getElementById('recaptcha-error').style.display = 'block';
        return false;
    } else {
        return true;
    }
    }
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $(".cityList").change(function () {
            var selectedCity = $(".cityList option:selected").val();
            $.ajax({
                type: "POST",
                url: "fetch.php",
                data: { cityList: selectedCity },
            }).done(function (data) {
                $("#result").html(data);
            }); 
        });
    });
</script>