<?php
$page_title = "Update Account";
include 'dbcon.php';
include 'authentication.php';
include('includes/header.php');
include('includes/navbar.php');

if($_SESSION['user_type'] != 'org') 
{
    header("Location: error.html");
}

$csrf_token = $_SESSION['csrf_token'];
$user = $_GET['user']; // GET id from link

$query = "SELECT * FROM userOrg WHERE username=?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);


$orgname = $row['orgName'];
$services = $row['services'];
$desc = $row['description'];
$offaddress = $row['offAddress'];
$city = $row['city'];

if($user != $_SESSION['auth_user']['username'])
{
    header("Location: error.html");
}

if(isset($_POST['update_profile_org']))
{
    $orgname = htmlspecialchars($_POST['orgname']);
    $offaddress = htmlspecialchars($_POST['offaddress']);
    $city = htmlspecialchars($_POST['city']);
    $services = htmlspecialchars($_POST['services']);
    $desc = htmlspecialchars($_POST['desc']);
    $file = $_FILES['file'];
    $opass = htmlspecialchars($_POST['opass']);
    $update_opass = htmlspecialchars($_POST['update_opass']);
    $oconfirmpass = htmlspecialchars($_POST['oconfirmpass']);
    $fileName = $_FILES['file'] ['name'];
    $fileTmpName = $_FILES['file'] ['tmp_name'];
    $fileSize = $_FILES['file'] ['size'];
    $fileError = $_FILES['file'] ['error'];
    $fileType = $_FILES['file'] ['type']; 
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpeg', 'jpg', 'png', 'pdf');

    $number_orgname = preg_match('@[0-9]@', $orgname);
    $number_address = preg_match('@[0-9]@', $offaddress);
    $number_city = preg_match('@[0-9]@', $city);
    $number = preg_match('@[0-9]@', $opass);

    $specialChars_orgname = preg_match('@[^\w\s]@', $orgname);
    $specialChars_address = preg_match('@[^\w\s]@', $offaddress);
    $specialChars_city = preg_match('@[^\w\s]@', $city);
    $specialChars = preg_match('@[^\w]@', $opass);

    $query = "SELECT * FROM userOrg WHERE username=?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $user);
    $query_run = mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    function is_insecure_password($password) {
        $insecure_patterns = [
            "/\bOR\b/i",
            "/\bDROP\b/i",
            "/;/",
            "/<script>/i"
        ];
    
        foreach ($insecure_patterns as $pattern) {
            if (preg_match($pattern, $password)) {
                return true;
            }
        }
    
        return false;
    }

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if(strlen($orgname) < 2 OR $number_orgname OR $specialChars_orgname)
    {
        $_SESSION['status-error'] = "Invalid Organization Name"; 
        header("Location:/ewaste/edit-profile/$user");
        exit(0);
    }

    if(strlen($offaddress) < 7 OR !$number_address OR $specialChars_address)
    {
        $_SESSION['status-error'] = "Invalid Address"; 
        header("Location:/ewaste/edit-profile/$user");
        exit(0);
    }

    if(!empty($update_opass) || !empty($oconfirmpass))
    {
        if(md5($update_opass) != $row['opass'])
        {
            $_SESSION['status-error'] = "Current password is incorrect"; 
            header("Location:/ewaste/edit-profile/$user");
            exit(0);
        }
    }

    if(!empty($opass))
    {
        if(is_insecure_password($opass))
        {
            $_SESSION['status-error'] = "Invalid password"; 
            header("Location:/ewaste/edit-profile/$user");
            exit(0);
        }

        if(strlen($opass) < 8 OR ctype_upper($opass) OR ctype_lower($opass) OR !$number OR !$specialChars)
        {
            $_SESSION['status-error'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character"; 
            header("Location:/ewaste/edit-profile/$user"); 
            exit(0);
        }

        if($opass != $oconfirmpass)
        {
            $_SESSION['status-error'] = "Password and Confirm Password does not match"; 
            header("Location:/ewaste/edit-profile/$user");
            exit(0);
        }
        else
        {
            $query = "UPDATE userOrg SET opass = ? WHERE username = ?";
            $stmt = mysqli_prepare($con, $query);
            mysqli_stmt_bind_param($stmt, "ss", md5($opass), $user);
            $query_run = mysqli_stmt_execute($stmt);
        
            if($query_run)
            {
                $_SESSION['status'] = "Updated Successfully!"; 
                header("Location:/ewaste/edit-profile/$user");
            }
        }
    }

    if($fileSize > 1)
    {
        if (in_array($fileActualExt, $allowed)) {
            if ($fileError === 0) {
                if ($fileSize < 10000000) {
                    $fileNameNew = uniqid('', true).".".$fileActualExt;
                    $fileDestination = 'admin/uploads/'.$fileNameNew;
                    move_uploaded_file($fileTmpName, $fileDestination);

                    $query = "UPDATE userOrg SET permit = ? WHERE username = ?";
                    $stmt = mysqli_prepare($con, $query);
                    mysqli_stmt_bind_param($stmt, 'ss', $fileNameNew, $user);
                    $query_run = mysqli_stmt_execute($stmt);

                        if($query_run)
                        {
                            $_SESSION['status'] = "Updated Successfully!"; 
                            header("Location:/ewaste/edit-profile/$user"); 
                        }
                    }
                    else
                    {
                        $_SESSION['status-error'] = "File Size is too big";
                        header("Location:/ewaste/edit-profile/$user");
                        exit(0);
                    }
                }
        }
        else
        {
            $_SESSION['status-error'] = "Permit must be jpeg, jpg, png, or pdf files";
            header("Location:/ewaste/edit-profile/$user");
            exit(0);
        }
    }

    if(strlen($orgname) > 2 OR !$number_orgname OR !$specialChars_orgname OR strlen($offaddress) > 7 OR $number_address OR !$specialChars_address OR strlen($rcity) > 2 OR !$number_city OR !$specialChars_city)
    {
        $stmt = mysqli_prepare($con, "UPDATE userOrg SET orgName=?, services=?, description=?, offAddress=?, city=? WHERE username=?");
        mysqli_stmt_bind_param($stmt, "ssssss", $orgname, $services, $desc, $offaddress, $city, $user);
        $query_run = mysqli_stmt_execute($stmt);
        
        $_SESSION['action'] = "Updates user information.";

        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($query_run && $log_query_run)
        {
            $_SESSION['status'] = "Updated Successfully!"; 
            header("Location: /ewaste/edit-profile/$user");
            exit(0);
        }
    }
  
}  


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update profile</title>

    <link rel="stylesheet" href="/ewaste/css/update-profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
</head>

<body class="update-body-org"> 
    <div class="update-profile-org">
        <form action="" method="post" enctype="multipart/form-data">
            <?php
                if(isset($_SESSION['status']))
                {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }

                if(isset($_SESSION['status-error']))
                {
                    echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                    unset($_SESSION['status-error']);
                }
            ?>
            <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  
            <div class="flex">
                <div class="inputBox">
                    <span>Name of Organization: </span>
                        <input type="text" name="orgname" value="<?php echo $orgname; ?>" class="box">
                    <span>Office Address: </span>
                        <input type="text" name="offaddress" value="<?php echo $offaddress; ?>" class="box">
                    <span>Description: </span>
                        <textarea class="box" name="desc" style="width: 800px; height: 200px; border-radius:6px;" ><?php echo $desc; ?></textarea>
                    <span>Permit: </span>
                        <input type="file" name="file" accept="image/jpg, image/jpeg, image/png, image/pdf" class="box">   
                    <?php echo '<a href="/ewaste/profile/' . $username . '" class="btn btn-back">Back</a>'; ?>        
                </div>
                <div class="inputBox">     
                    <span class="services">Services: </span>   
                        <select name="services" class="form-control-services" required> 
                            <option value="<?php echo $services; ?>"><?php echo $services; ?></option>
                            <option>Food Rescue/ Charity</option>
                            <option>Composting</option>
                            <option>Data Collection</option>
                            <option>Environmental</option>
                            <option>Social</option>
                            <option>Advocacy</option>
                            <option>Human Rights</option>
                        </select>      
                        
                    <span class="city">City Name: </span>   
                        <select name="city" class="form-control-city" required> 
                            <option value="<?php echo $city; ?>"><?php echo $city; ?></option>
                            <option>Caloocan</option>
                            <option>Malabon</option>
                            <option>Navotas</option>
                            <option>Valenzuela</option>
                            <option>Quezon City</option>
                            <option>Marikina</option>
                            <option>Pasig</option>
                            <option>Taguig</option>
                            <option>Makati</option>
                            <option>Manila</option>
                            <option>Mandaluyong</option>
                            <option>San Juan</option>
                            <option>Pasay</option>
                            <option>Parañaque</option>
                            <option>Las Piñas</option>
                            <option>Muntinlupa</option>
                        </select>           
                    <span class="cpass">Current Password: </span>   
                        <input type="password" name="update_opass" value="<?php $rpass?>" class="box box-cpass" placeholder="enter previous password" id="id_currentpassword">   
                        <i class="far fa-eye" id="togglecurrentPassword"></i>
                    <span class="npass">New Password: </span>   
                        <input type="password" name="opass" value="" class="box box-npass" placeholder="enter new password" id="id_newpassword"> 
                        <i class="far fa-eye" id="togglenewPassword"></i> 
                    <span class="cnpass">Confirm New Password: </span>   
                        <input type="password" name="oconfirmpass" value="" class="box box-cnpass" placeholder="re enter new password" id="id_confirmpassword"> 
                        <i class="far fa-eye" id="toggleconfirmPassword"></i>
                    <button type="submit" name="update_profile_org" class="btn btn-update-profile">Make Changes</button>     
                </div>
            </div>
        </form>        
    </div>
</body>
</html>
<script>
    const togglecurrentPassword = document.querySelector('#togglecurrentPassword');
    const currentpassword = document.querySelector('#id_currentpassword');

    togglecurrentPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = currentpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        currentpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const togglenewPassword = document.querySelector('#togglenewPassword');
    const newpassword = document.querySelector('#id_newpassword');

    togglenewPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = newpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        newpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>
