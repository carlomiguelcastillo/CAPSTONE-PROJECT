<?php
$page_title = "Update Account";
include 'dbcon.php';
include 'authentication.php';
include('includes/header.php');
include('includes/navbar.php');

if($_SESSION['user_type'] != 'resto') 
{
    header("Location: error.html");
}

$csrf_token = $_SESSION['csrf_token'];
$user = $_GET['user']; // GET user from link

$query = "SELECT * FROM userresto WHERE username=?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "s", $user);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);

$raddress = $row['raddress'];
$rcity = $row['rcity'];
$rpass = $row['rpass'];

if($user != $_SESSION['auth_user']['username'])
{
    header("Location: error.html");
}

if(isset($_POST['update_profile_resto']))
{
    $raddress = htmlspecialchars($_POST['raddress']);
    $rcity = htmlspecialchars($_POST['rcity']);
    $file = $_FILES['file'];
    $rpass = $_POST['rpass'];
    $update_rpass = htmlspecialchars($_POST['update_rpass']);
    $rconfirmpass = htmlspecialchars($_POST['rconfirmpass']);
    $fileName = $_FILES['file'] ['name'];
    $fileTmpName = $_FILES['file'] ['tmp_name'];
    $fileSize = $_FILES['file'] ['size'];
    $fileError = $_FILES['file'] ['error'];
    $fileType = $_FILES['file'] ['type']; 
    $c_token = htmlspecialchars($_POST['csrf_token']);

    $fileExt = explode('.', $fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpeg', 'jpg', 'png', 'pdf');

    $number_address = preg_match('@[0-9]@', $raddress);
    $number_city = preg_match('@[0-9]@', $rcity);
    $number = preg_match('@[0-9]@', $rpass);

    $specialChars_address = preg_match('@[^\w\s]@', $raddress);
    $specialChars_city = preg_match('@[^\w\s]@', $rcity);
    $specialChars = preg_match('@[^\w]@', $rpass);

    $query = "SELECT * FROM userResto WHERE username=?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "s", $user);
    $query_run = mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    function is_insecure_password($password) {
        $insecure_patterns = [
            "/\bOR\b/i",
            "/\bDROP\b/i",
            "/;/",
            "/<script>/i"
        ];
    
        foreach ($insecure_patterns as $pattern) {
            if (preg_match($pattern, $password)) {
                return true;
            }
        }
    
        return false;
    }

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if(strlen($raddress) < 7 OR !$number_address OR $specialChars_address)
    {
        $_SESSION['status-error'] = "Invalid Address"; 
        header("Location: /ewaste/edit-account/$user");
        exit(0);
    }

    if(!empty($update_rpass) || !empty($rconfirmpass))
    {
        if(md5($update_rpass) != $row['rpass'])
        {
            $_SESSION['status-error'] = "Current password is incorrect"; 
            header("Location: /ewaste/edit-account/$user");
            exit(0);
        }
       
    }

    if(!empty($rpass))
    {
        if(is_insecure_password($rpass))
        {
            $_SESSION['status-error'] = "Invalid password"; 
            header("Location: /ewaste/edit-account/$user"); 
            exit(0);
        }

        if(strlen($rpass) < 8 OR ctype_upper($rpass) OR ctype_lower($rpass) OR !$number OR !$specialChars)
        {
            $_SESSION['status-error'] = "Password must be more than 8 characters with a lowercase letter,  uppercase letter, number and special character"; 
            header("Location: /ewaste/edit-account/$user"); 
            exit(0);
        }

        if($rpass != $rconfirmpass)
        {
    
            $_SESSION['status-error'] = "Password and Confirm Password does not match"; 
            header("Location: /ewaste/edit-account/$user");
            exit(0);
        }
        else
        {
            $stmt = mysqli_prepare($con, "UPDATE userResto SET rpass = ? WHERE username = ?");
            mysqli_stmt_bind_param($stmt, "ss", md5($rpass), $user);
            $query_run = mysqli_stmt_execute($stmt);
        
            if($query_run)
            {
                $_SESSION['status'] = "Updated Successfully!"; 
                header("Location: /ewaste/edit-account/$user");
            }
        }
    }

    if($fileSize > 1)
    {
        if (in_array($fileActualExt, $allowed)) {
            if ($fileError === 0) {
                if ($fileSize < 10000000) {
                    $fileNameNew = uniqid('', true).".".$fileActualExt;
                    $fileDestination = 'admin/uploads/'.$fileNameNew;
                    move_uploaded_file($fileTmpName, $fileDestination);

                    $query = "UPDATE userResto SET fel = ? WHERE username = ?";
                    $stmt = mysqli_prepare($con, $query);
                    mysqli_stmt_bind_param($stmt, "ss", $fileNameNew, $user);
                    $query_run = mysqli_stmt_execute($stmt);

                        if($query_run)
                        {
                            $_SESSION['status'] = "Updated Successfully!"; 
                            header("Location: /ewaste/edit-account/$user"); 
                        }
                    }
                    else
                    {
                        $_SESSION['status-error'] = "File Size is too big";
                        header("Location: /ewaste/edit-account/$user");
                        exit(0);
                    }
                }   
        }
        else
        {
            $_SESSION['status-error'] = "Food Establishment License must be jpeg, jpg, png, or pdf files";
            header("Location: /ewaste/edit-account/$user");
            exit(0);
        }
    }

    if(strlen($raddress) > 7 OR $number_address OR !$specialChars_address OR strlen($rcity) > 2 OR !$number_city OR !$specialChars_city)
    {
        $id = $_SESSION['auth_user']['id'];

        $query = "UPDATE userResto SET raddress=?, rcity=? WHERE resto_id=?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, "ssi", $raddress, $rcity, $id);
        $query_run = mysqli_stmt_execute($stmt);

        $query2 = "UPDATE waste SET rcity=? WHERE resto_id=?";
        $stmt2 = mysqli_prepare($con, $query2);
        mysqli_stmt_bind_param($stmt2, "si", $rcity, $id);
        $query_run2 = mysqli_stmt_execute($stmt2);

        $_SESSION['action'] = "Updated user information.";

        $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);
        
        if($query_run && $query_run2 && $log_query_run)
        {
            $_SESSION['status'] = "Updated Successfully!"; 
            header("Location: /ewaste/edit-account/$user");
            exit(0);
        }
    }
  
}  

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update profile</title>

    <!-- custom css file link  -->
    <link rel="stylesheet" href="/ewaste/css/update-profile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
</head>
<body class="update-body-resto"> 
    <div class="update-profile-resto">
        <form action="" method="post" enctype="multipart/form-data">
            <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>"> 
            <?php
                if(isset($_SESSION['status']))
                {
                    echo "<h4>" . $_SESSION['status'] . "</h4>";
                    unset($_SESSION['status']);
                }
                if(isset($_SESSION['status-error'])) {
                    echo '<h4 class="error">' . $_SESSION['status-error'] . '</h4>';
                    unset($_SESSION['status-error']);
                }
            ?>
            <div class="flex">
                <div class="inputBox">
                    <span>Restaurant Address: </span>
                    <input type="text" name="raddress" value="<?php echo $raddress; ?>" class="box">
                    <span>Restaurant City: </span>    
                    <select name="rcity" class="form-control" required> 
                        <option value="<?php echo $rcity; ?>"><?php echo $rcity; ?></option>
                        <option>Caloocan</option>
                        <option>Malabon</option>
                        <option>Navotas</option>
                        <option>Valenzuela</option>
                        <option>Quezon City</option>
                        <option>Marikina</option>
                        <option>Pasig</option>
                        <option>Taguig</option>
                        <option>Makati</option>
                        <option>Manila</option>
                        <option>Mandaluyong</option>
                        <option>San Juan</option>
                        <option>Pasay</option>
                        <option>Parañaque</option>
                        <option>Las Piñas</option>
                        <option>Muntinlupa</option>
                    </select>      
                    <span>Update Food Establishment License: </span>
                    <input type="file" name="file" accept="image/jpg, image/jpeg, image/png, image/pdf" class="box"> 
                    <?php echo '<class="btn"><a href="/ewaste/account/' . $username . '" class="btn">Back</a></button>'; ?>          
                </div>
                <div class="inputBox">         
                    <span>Current Password: </span>   
                    <input type="password" name="update_rpass" value="<?php $rpass?>" class="box" placeholder="enter previous password" id="id_currentpassword">  
                    <i class="far fa-eye" id="togglecurrentPassword" style="margin-right:-350px; margin-top: -32px; cursor: pointer;"></i> 
                    <span>New Password: </span>   
                    <input type="password" name="rpass" value="" class="box" placeholder="enter new password" id="id_newpassword">  
                    <i class="far fa-eye" id="togglenewPassword" style="margin-right:-350px; margin-top: -32px; cursor: pointer;"></i>
                    <span>Confirm New Password: </span>   
                    <input type="password" name="rconfirmpass" value="" class="box" placeholder="re enter new password" id="id_confirmpassword"> 
                    <i class="far fa-eye" id="toggleconfirmPassword" style="margin-right:-350px; margin-top: -32px; cursor: pointer;"></i>
                    <button type="submit" name="update_profile_resto" class="btn">Make Changes</button>  
                </div>
            </div>
        </form>
    </div>
</body>
</html>

<script>
    const togglecurrentPassword = document.querySelector('#togglecurrentPassword');
    const currentpassword = document.querySelector('#id_currentpassword');

    togglecurrentPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = currentpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        currentpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });

    const togglenewPassword = document.querySelector('#togglenewPassword');
    const newpassword = document.querySelector('#id_newpassword');

    togglenewPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = newpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        newpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
    
    const toggleconfirmPassword = document.querySelector('#toggleconfirmPassword');
    const confirmpassword = document.querySelector('#id_confirmpassword');

    toggleconfirmPassword.addEventListener('click', function (e) {
        // toggle the type attribute
        const type = confirmpassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmpassword.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script>