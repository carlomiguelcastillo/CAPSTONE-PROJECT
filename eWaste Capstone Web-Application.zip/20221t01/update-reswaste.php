<?php 
include('authentication.php');

$page_title = "Edit Residual Waste";
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');
include('includes/scripts.php');

$sessionCsrfToken = $_SESSION['csrf_token'];

$userCsrfTokenQuery = "SELECT csrf_token FROM userresto WHERE resto_id = {$_SESSION['auth_user']['id']}";
$userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
$userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
$userCsrfToken = $userCsrfTokenRow['csrf_token'];

if ($sessionCsrfToken !== $userCsrfToken) {
    header("Location: error.html");
    exit;
}

$csrf_token = $_SESSION['csrf_token'];
$id = $_SESSION['auth_reswaste']['id'];
$query = "SELECT * FROM reswaste WHERE id=?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
$id2 = $row['resto_id'];
$reswaste = $row['reswaste'];
$weight = $row['weight']; 
$containers = $row['containers'];
$frequency = $row['frequency'];
$updated_at = $row['updated_at'];
              
if($id2 != $_SESSION['auth_reswaste']['resto_id']) // has to be waste id not user id
{
    header("Location: error.html");
}

if(isset($_POST['update_reswaste']))
{
    $reswaste = $_POST['reswaste'];
    $weight = $_POST['weight']; 
    $containers = $_POST['containers'];
    $frequency = $_POST['frequency'];
    $c_token = $_POST['csrf_token'];

    if (!hash_equals($c_token, $csrf_token)) 
    {
        header("Location: /ewaste/error.html");
        exit;
    }

    if($weight <= 0) 
    {
        $_SESSION['status'] = "Weight cannot be 0 or less than 0";
        header("location:/ewaste/update-reswaste.php/$id");  
        exit(0);
    }
    else
    {
        $query =  "UPDATE reswaste SET reswaste=?, weight=?, containers=?, frequency=?, updated_at=NOW() WHERE id = ?";
        $stmt = mysqli_prepare($con, $query);
        mysqli_stmt_bind_param($stmt, 'sdssi', $reswaste, $weight, $containers, $frequency, $id);
        $query_run = mysqli_stmt_execute($stmt);
        
        $_SESSION['action'] = "Edited reswaste data (Reswaste ID: $id)";

        $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
        $log_query_run = mysqli_query($con, $log_query);

        if($query_run && $log_query_run)
        {
            $_SESSION['progress'] = "Residual Waste data updated!";
            $_SESSION['progress_code'] = "success";
            header("location:/ewaste/update-reswaste.php?updateid=$id");  
        }
        else
        {
            die(mysqli_error($con));
        }
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            background-image: url('/ewaste/image/img.jpg');
            height: 300px; 
            background-repeat: no-repeat;
            background-size: cover;  
            background-attachment: fixed;
        }
        .container {
            width:1000px;
            margin:4% auto;
            padding:10px;
            border-radius: 20px;

        }
        .card-header{  
            width: 420px;
            margin: 7px;
            height:100px;
            padding: 1px;
            text-align: center;
            font-weight: 1000;
            background-color: #E2DFD2;
        }
        .card {
            width: 500px;
            margin:10% auto;
            padding:20px;
            border-radius: 20px;
            background-color: #E2DFD2;
        }
        .form-control {
            width: 420px;            
        }

        .btn {
            width: 35%;
            padding: 10px;
            color: white;
            font-weight: 1000;
            background-color: black;
        }

        .status {
            color: #A52A2A;
            text-align: center;
            background-color: #E2DFD2; 
            padding: 10px; /* Add padding for readability */
            border-radius: 20px; 
            position: relative;
            left: 10px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">    
            
                <div class="alert">
                    <?php
                        if(isset($_SESSION['status']))
                        {
                            echo '<h3 class="status">' . $_SESSION['status'] . '</h3>';
                            unset($_SESSION['status']);
                        }
                    ?>
                </div>

                <div class="card">
                    <div class="card-header">
                    <div class="head mb-3 mt-4" style="font-size: 40px; font-family: Georgia; font-weight: 700; margin-left: 22px;">UPDATE DATA</div>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <input name="csrf_token" type="hidden" value="<?php echo $csrf_token ?>">  
                                        <label>Type of Residual Waste</label>
                                        <select name="reswaste" class="form-control" required>
                                            <option><?php echo $reswaste ?></option>
                                            <option>Contaminated soil</option>
                                            <option>Ceramics</option>
                                            <option>Gypsum Board</option>
                                            <option>Linoleum</option>
                                            <option>Leather</option>
                                            <option>Rubber</option>
                                            <option>Textiles</option>
                                            <option>Electronics</option>
                                            <option>Fertilizers</option>
                                            <option>Detergents</option>
                                            <option>Oil</option>
                                            <option>Pharmaceutical waste</option>
                                            <option>Photographic film and paper</option>
                                            <option>Pesticides</option>
                                        </select>
                                    </div> 
                                    <div class="form-group">
                                        <label>Estimated Weight of Residual Waste (KG)</label>
                                        <input name="weight" type="number" step="any" class="form-control" maxlength="200" value="<?php echo $weight ?>" required/>
                                    </div>
                                    <div class="form-group">
                                        <label>Number of Containers Used</label>
                                        <input name="containers" type="number" step="any" class="form-control" maxlength="200" value="<?php echo $containers ?>" required/>
                                    </div>
                                    <div class="form-group">
                                    <label>Frequency of Waste Being Disposed:</label>
                                        <select name="frequency" class="form-control" required>
                                            <option><?php echo $frequency ?></option>
                                            <option>Daily</option>
                                            <option>Weekly</option>
                                            <option>Monthly</option>
                                            <option>Yearly</option>
                                        </select>
                                    </div>
                                    <div class="d-flex justify-content-center mt-4">
                                    <button name="update_reswaste" class="btn" type="submit">Update</button>                                                                                                                                          
                                    </div>                                      
                                </div>
                            </div>                                  
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>


