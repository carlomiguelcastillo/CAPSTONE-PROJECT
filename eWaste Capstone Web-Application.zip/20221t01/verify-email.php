<?php
session_start();
include('dbcon.php');

if(isset($_GET['token']))
{
    $token = $_GET['token'];
    $verify_query = "SELECT verify_token, verify_status FROM userResto WHERE verify_token = '$token' LIMIT 1";
    $verify_query_run = mysqli_query($con, $verify_query);

    $verify_query_2 = "SELECT verify_token, verify_status FROM userOrg WHERE verify_token = '$token' LIMIT 1";
    $verify_query_run_2 = mysqli_query($con, $verify_query_2);

    if(mysqli_num_rows($verify_query_run))
    {
        $row = mysqli_fetch_array($verify_query_run);

        if($row['verify_status'] == "0")
        {
            $clicked_token = $row['verify_token'];
            $update_query = "UPDATE userResto SET verify_status = '1' WHERE verify_token = '$clicked_token' LIMIT 1 ";
            $update_query_run = mysqli_query($con, $update_query);

            if($update_query_run)
            {
                $_SESSION['action'] = "Successfully verified email address.";

                $resto_data = "SELECT resto_id, username, email FROM userResto WHERE verify_token = '$clicked_token' ";
                $resto_data_run = mysqli_query($con, $resto_data);
                $row = mysqli_fetch_array($resto_data_run);
                $resto_id = $row['resto_id'];
                $username = $row['username'];
                $email = $row['email'];

                $log_query = "INSERT INTO restolog (user_id, username, email, user_type, action_made) VALUES ('$resto_id', '$username', '$email', 'resto', '{$_SESSION['action']}')";
                $log_query_run = mysqli_query($con, $log_query);

                if ($log_query_run)
                {
                $_SESSION['status'] = "Verification successful!";
                header("Location: login.php");
                exit(0);
                }
            }

            
            else
            {
            $_SESSION['status'] = "Verification failed";
            header("Location: login.php");
            exit(0);
            }
        }

        else
        {
        $_SESSION['status'] = "Email already verified. Please login.";
        header("Location: login.php");
        exit(0);
        }

    }

    if(mysqli_num_rows($verify_query_run_2) > 0)
    {
        $row_2 = mysqli_fetch_array($verify_query_run_2);

        if($row_2['verify_status'] == "0")
        {
            $clicked_token_2 = $row_2['verify_token'];
            $update_query_2 = "UPDATE userOrg SET verify_status = '1' WHERE verify_token = '$clicked_token_2' LIMIT 1 ";
            $update_query_run_2 = mysqli_query($con, $update_query_2);

            if($update_query_run_2)
            {
                $_SESSION['action'] = "Successfully verified email address.";

                $org_data = "SELECT id, username, email FROM userorg WHERE verify_token = '$clicked_token_2' ";
                $org_data_run = mysqli_query($con, $org_data);
                $row = mysqli_fetch_array($org_data_run);
                $id = $row['id'];
                $username = $row['username'];
                $email = $row['email'];

                $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('$id', '$username', '$email', 'org', '{$_SESSION['action']}')";
                $log_query_run = mysqli_query($con, $log_query);

                if ($log_query_run)
                {
                $_SESSION['status'] = "Verification successful!";
                header("Location: login.php");
                exit(0);
                }
            }
            
            else
            {
            $_SESSION['status'] = "Verification failed";
            header("Location: login.php");
            exit(0);
            }
        }

        else
        {
        $_SESSION['status'] = "Email already verified. Please login.";
        header("Location: login.php");
        exit(0);
        }

    }
    else
    {
    $_SESSION['status'] = "This token does not exist.";
    header("Location: login.php");
    }

}
else
{
    $_SESSION['status'] = "Not Allowed";
    header("Location: login.php");
}

?>