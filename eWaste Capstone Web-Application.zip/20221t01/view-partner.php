<?php 
$page_title = "View Organizations";
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php'); 

if($_SESSION['user_type'] != 'resto') // Restricts org user from entering page
{
    header("Location: error.html");
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
        background-image: url('image/img.jpg');    
        }
        
        .container {
        width:1000px; 
        margin:7% auto;
        padding:10px;
        border-radius: 20px;
        }

        .card {
        width: 1500px;
        margin:7% auto;
        padding:20px;
        border-radius: 10px;
        background-color: #E2DFD2;
        }    
        .card-header {
        font-family: Georgia;
        text-align: center;           
        }    

        #dataTable th {
        border: 1px solid black;
        padding: 8px;
        text-align: center;
        }

        #dataTable td {
        border: 1px solid black;
        padding: 8px;
        text-align: left;
        }
</style>
</head>
<body>
    <div class="container-fluid px-4">            
        <div class="col-md-12">
            <div class="card">   
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Registered Organizations </h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <table id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th> Name of Organization </th>
                                    <th> Email </th>
                                    <th> Address </th>
                                    <th> City </th>
                                    <th> Services </th>
                                    <th> Description </th>                             
                                </tr>   
                            </thead>
                                <tbody>
                                    <?php
                                                            
                                        $query = "SELECT * FROM userOrg"; // Shows admins
                                        $query_run = mysqli_query($con, $query);

                                        if($query_run) //if(mysqli_num_rows($query_run) > 0)
                                        {
                                            while($row = mysqli_fetch_assoc($query_run))
                                            {                                 
                                                //$id = $row['id'];
                                                $orgName = $row['orgName']; 
                                                $email = $row['email']; 
                                                $services = $row['services']; 
                                                $desc = $row['description']; 
                                                $offAddress = $row['offAddress']; 
                                                $city = $row['city']; 
                                                echo '<tr>
                                                <th scope="row">' . $orgName . '</th>
                                                <td>' . $email . '</td>
                                                <td>' . $offAddress . '</td>
                                                <td>' . $city . '</td>
                                                <td>' . $services . '</td>
                                                <td>' . $desc . '</td>                                                                  
                                                </tr>';
                                            }
                                        } 
                                    ?>                             
                                </tbody>
                        </table>               
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
