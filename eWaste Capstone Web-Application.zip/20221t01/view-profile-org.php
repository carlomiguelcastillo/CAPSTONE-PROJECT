<?php
$page_title = "Account";
include 'dbcon.php';
include 'authentication.php';
include 'includes/header.php';
include 'includes/navbar.php';

if($_SESSION['user_type'] != 'org') 
{
    header("Location: error.html");
}

$user = $_GET['user']; // GET username from link
$query = "SELECT * FROM userOrg WHERE username=?";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, 's', $user);
mysqli_stmt_execute($stmt);
$query_run = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($query_run);

// Sanitize the retrieved values
$id = htmlspecialchars($row['id']);
$fname = htmlspecialchars($row['fname']);
$lname = htmlspecialchars($row['lname']);
$username = htmlspecialchars($row['username']);
$mobilenum = htmlspecialchars($row['mobilenum']);
$birthdate = htmlspecialchars($row['birthdate']);
$email = htmlspecialchars($row['email']);
$orgname = htmlspecialchars($row['orgName']);
$services = htmlspecialchars($row['services']);
$desc = htmlspecialchars($row['description']);
$offaddress = htmlspecialchars($row['offAddress']);
$city = htmlspecialchars($row['city']);

if($user != $_SESSION['auth_user']['username'])
{
   header("Location: /ewaste/visuals");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>View Organization's Profile</title>
   <link rel="stylesheet" href="/ewaste/css/view-profile.css">
</head>
<body class="view-body-org">    
   <div class="view-profile-org">
      <form action="update-profile-org.php" method="post" enctype="multipart/form-data">
         <div class="flex">
            <div class="inputBox">
               <h4>General Info</h4> <br>
                  <span>First Name: </span>
                  <input type="text" value="<?php echo $fname; ?>" class="box" readonly>
                  <span>Username: </span>
                  <input type="text" value="<?php echo $username; ?>" class="box" readonly>
                  <span>Email: </span>
                  <input type="text" value="<?php echo $email; ?>" class="box" readonly>
                  <br> <br>
               <h4>Organization Details</h4> <br>
                  <span>Name: </span>
                  <input type="text" value="<?php echo $orgname; ?>" class="box" readonly>
                  <span>City: </span>
                  <input type="text" value="<?php echo $city; ?>" class="box" readonly>
                  <span>Description: </span>
                  <textarea class="box" style="width: 800px; height: 200px; border-radius:6px;" readonly><?php echo $desc; ?></textarea>
            </div>

            <div class="inputBox"> <br>
               <span>Last Name: </span>
               <input type="text" value="<?php echo $lname; ?>" class="box" readonly>
               <span>Mobile #: </span>
               <input type="text" value="<?php echo $mobilenum; ?>" class="box" readonly>
               <span>Birthdate: </span>
               <input type="text" value="<?php echo $birthdate; ?>" class="box" readonly>
               <br> <br><br> 
               <span>Services:</span> 
               <input type="text" value="<?php echo $services; ?>" class="box" readonly>
               <span> Address: </span>
               <input type="text" value="<?php echo $offaddress; ?>" class="box" readonly>
               <span>Permit: <a href="/ewaste/download.php?file=<?php echo $row['permit'] ?>">Download</span><br> 
            </div>             
         </div>
            <?php        
               echo '<class="btn"><a href="/ewaste/edit-profile/' . $username . ' " class="btn">Update Profile</a></button>';
            ?>                
      </form>
   </div>
</body>
</html>

