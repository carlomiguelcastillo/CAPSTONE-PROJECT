<?php 
    $page_title = "View Waste";
    include('authentication.php');
    include('includes/header.php');
    include('includes/navbar.php');
    include('dbcon.php'); 

    if($_SESSION['user_type'] != 'resto') 
    {
        header("Location: error.html");
    }


    $sessionCsrfToken = $_SESSION['csrf_token'];

    $userCsrfTokenQuery = "SELECT csrf_token FROM userresto WHERE resto_id = {$_SESSION['auth_user']['id']}";
    $userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
    $userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
    $userCsrfToken = $userCsrfTokenRow['csrf_token'];

    if ($sessionCsrfToken !== $userCsrfToken) {
        header("Location: error.html");
        exit;
    }

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" rel="stylesheet" type='text/css'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.18/css/dataTables.bootstrap4.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>

    <style>
        body {
            background-image: url('/ewaste/image/img.jpg');       
        }     
        .container {
            width:1000px; 
            margin:7% auto;
            padding:10px;
            border-radius: 20px;
        }
        .card {
            width: 1500px;
            margin:7% auto;
            padding:20px;
            border-radius: 10px;
            background-color: #E2DFD2;
        }    
        .card-header {
            font-family: Georgia;
            text-align: center;           
        }    
        #dataTable {
            border: 1px solid black;
            border-collapse: collapse;
        }

        #dataTable th {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }

        #dataTable td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        .btn {
            width: 35%;
            padding: 5px;
        }

        .btn-success a .fa-pen-to-square,
        .btn-danger .fa-trash {
            color: white;
        }
        #dataTable th.actions-column,
        #dataTable td.actions-column {
            width: 7%; /* Adjust the value as needed */
        }
    </style>
</head>
<body>
    <!-- DELETE POP UP FORM (Bootstrap MODAL) -->
    <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"> Food Waste Data </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="delete-waste.php" method="POST">

                    <div class="modal-body">

                        <input type="hidden" name="delete_id" id="delete_id">

                        <h4> Are you sure you want to delete it? </h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
                        <button type="submit" name="deletedata" class="btn btn-primary"> YES </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="container-fluid px-4"> 
        <div class="col-md-12">
            <div class="card">      
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Food Waste  </h4>
                </div>
                <div class="card-body">
                    <table id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Type of Food </th> 
                                <th> Raw Cost </th>
                                <th> Weight </th>                           
                                <th> Frequency</th>
                                <th> Reason of Wastage </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $logged_user = $_SESSION['auth_user']['email'];
                                $query = "SELECT * 
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.email = '$logged_user'" ; // Shows resto users
                                $query_run = mysqli_query($con, $query);
                                                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {                                 
                                        $id = $row['id'];
                                        $resto_id = $row['resto_id'];
                                        $foodtype = $row['foodtype'];
                                        $rawcost = $row['rawcost'];
                                        $weight = $row['weight']; 
                                        $frequency = $row['frequency'];
                                        $reason = $row['reason'];
                                        $created_at = $row['created_at']; 
                                        $updated_at = $row['updated_at']; 

                                        $_SESSION['auth_waste'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];                            

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>               
                                        <td scope="row">'  . $foodtype . '</td>
                                        <td scope="row">' . "₱" . number_format($rawcost, 2) . '</td>
                                        <td scope="row">' . $weight . " Kg" . '</td>
                                        <td scope="row">' . $frequency . '</td>
                                        <td scope="row">' . $reason . '</td>
                                        <td scope="row">' . date('Y-m-d, h:i:s A', strtotime($created_at)) . '</td>';

                                        if ($updated_at === null) 
                                        {
                                            echo '<td scope="row">' . "N/A" . '</td>'; 
                                        } else {
                                            echo '<td scope="row">' . date('Y-m-d, h:i:s A', strtotime($updated_at)) . '</td>';
                                        }

                                        echo '<td class="text-center">     
                                                
                                        <button class="btn btn-success"><a href="update-waste/' . $resto_id .'/'.$id.'" class="text-light"><i class="fa-solid fa-pen-to-square"></i></a></button>                              
                                        <button type="button" class = "confirm_del_btn btn btn-danger btn-sm"> <i class="fa-sharp fa-solid fa-trash"></i> </button>
                                        
                                        </td> </tr>';                                                                                                                               
                                    }
                                }
            
                                else 
                                {
                                    echo "No Record/s Found";
                                }
                            ?>                          
                        </tbody>
                    </table>   
                </div>
            </div>

            <div class="card">      
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Food Surplus  </h4>
                </div>
                <div class="card-body">
                    <table id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Surplus Food </th> 
                                <th> Raw Cost </th>
                                <th> Weight </th>                           
                                <th> Freshness </th>
                                <th> Expiry Date </th>
                                <th> Packaging </th>
                                <th> Storage Condition </th>
                                <th> Availability </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $logged_user = $_SESSION['auth_user']['id'];
                                $query = "SELECT * FROM surplus WHERE resto_id = '$logged_user'" ; // Shows resto users
                                $query_run = mysqli_query($con, $query);
                                                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {                                 
                                        $id = $row['id'];
                                        $resto_id = $row['resto_id'];
                                        $surplus = $row['surplus'];
                                        $rawcost = $row['rawcost'];
                                        $weight = $row['weight']; 
                                        $freshness = $row['freshness'];
                                        $expirydate = $row['expirydate'];
                                        $packaging = $row['packaging'];
                                        $storagecondition = $row['storagecondition'];
                                        $availability = $row['availability'];
                                        $created_at = $row['created_at']; 
                                        $updated_at = $row['updated_at']; 

                                        $_SESSION['auth_surplus'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];                            

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>               
                                        <td scope="row">'  . $surplus . '</td>
                                        <td scope="row">' . "₱" . number_format($rawcost, 2) . '</td>
                                        <td scope="row">' . $weight . " Kg" . '</td>
                                        <td scope="row">' . $freshness . '</td>
                                        <td scope="row">' . $expirydate . '</td>
                                        <td scope="row">' . $packaging . '</td>
                                        <td scope="row">' . $storagecondition . '</td>
                                        <td scope="row">' . $availability . '</td>
                                        <td scope="row">' . date('Y-m-d, h:i:s A', strtotime($created_at)) . '</td>';

                                        if ($updated_at === null) 
                                        {
                                            echo '<td scope="row">' . "N/A" . '</td>'; 
                                        } else {
                                            echo '<td scope="row">' . date('Y-m-d, h:i:s A', strtotime($updated_at)) . '</td>';
                                        }

                                        echo '<td class="text-center actions-column">     
                                                
                                        
                                        <button class="btn btn-success"><a href="update-surplus.php/' . $resto_id .'/'.$id.'" class="text-light"><i class="fa-solid fa-pen-to-square"></i></a></button>                              
                                        <button type="button" class = "confirm_del_btn btn btn-danger btn-sm"> <i class="fa-sharp fa-solid fa-trash"></i> </button>
                                        
                                        </td> </tr>';                                                                                                                               
                                    }
                                }
            
                                else 
                                {
                                    echo "No Record/s Found";
                                }
                            ?>                          
                        </tbody>
                    </table>   
                </div>
            </div>

            <div class="card">      
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Recycleable Waste </h4>
                </div>
                <div class="card-body">
                    <table id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Recycleable Waste </th>
                                <th> Weight </th>                           
                                <th> Number of Containers </th>
                                <th> Frequency </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $logged_user = $_SESSION['auth_user']['id'];
                                $query = "SELECT * FROM recwaste WHERE resto_id = '$logged_user'" ; // Shows resto users
                                $query_run = mysqli_query($con, $query);
                                                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {                                 
                                        $id = $row['id'];
                                        $resto_id = $row['resto_id'];
                                        $recwaste = $row['recwaste'];
                                        $weight = $row['weight']; 
                                        $containers = $row['containers'];
                                        $frequency = $row['frequency'];
                                        $created_at = $row['created_at']; 
                                        $updated_at = $row['updated_at']; 

                                        $_SESSION['auth_recwaste'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];                            

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>               
                                        <td scope="row">'  . $recwaste . '</td>
                                        <td scope="row">' . $weight . " Kg" . '</td>
                                        <td scope="row">' . $containers . '</td>
                                        <td scope="row">' . $frequency . '</td>
                                        <td scope="row">' . date('Y-m-d, h:i:s A', strtotime($created_at)) . '</td>';

                                        if ($updated_at === null) 
                                        {
                                            echo '<td scope="row">' . "N/A" . '</td>'; 
                                        } else {
                                            echo '<td scope="row">' . date('Y-m-d, h:i:s A', strtotime($updated_at)) . '</td>';
                                        }

                                        echo '<td class="text-center">     
                                                
                                        <button class="btn btn-success"><a href="update-recwaste.php/' . $resto_id .'/'.$id.'" class="text-light"><i class="fa-solid fa-pen-to-square"></i></a></button>                              
                                        <button type="button" class = "confirm_del_btn btn btn-danger btn-sm"> <i class="fa-sharp fa-solid fa-trash"></i> </button>
                                        
                                        </td> </tr>';                                                                                                                               
                                    }
                                }
            
                                else 
                                {
                                    echo "No Record/s Found";
                                }
                            ?>                          
                        </tbody>
                    </table>   
                </div>
            </div>

            <div class="card">      
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Residual Waste </h4>
                </div>
                <div class="card-body">
                    <table id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Residual Waste </th>
                                <th> Weight </th>                           
                                <th> Number of Containers </th>
                                <th> Frequency </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $logged_user = $_SESSION['auth_user']['id'];
                                $query = "SELECT * FROM reswaste WHERE resto_id = '$logged_user'" ; // Shows resto users
                                $query_run = mysqli_query($con, $query);
                                                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {                                 
                                        $id = $row['id'];
                                        $resto_id = $row['resto_id'];
                                        $reswaste = $row['reswaste'];
                                        $weight = $row['weight']; 
                                        $containers = $row['containers'];
                                        $frequency = $row['frequency'];
                                        $created_at = $row['created_at']; 
                                        $updated_at = $row['updated_at']; 

                                        $_SESSION['auth_reswaste'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];                            

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>               
                                        <td scope="row">'  . $reswaste . '</td>
                                        <td scope="row">' . $weight . " Kg" . '</td>
                                        <td scope="row">' . $containers . '</td>
                                        <td scope="row">' . $frequency . '</td>
                                        <td scope="row">' . date('Y-m-d, h:i:s A', strtotime($created_at)) . '</td>';

                                        if ($updated_at === null) 
                                        {
                                            echo '<td scope="row">' . "N/A" . '</td>'; 
                                        } else {
                                            echo '<td scope="row">' . date('Y-m-d, h:i:s A', strtotime($updated_at)) . '</td>';
                                        }

                                        echo '<td class="text-center">     
                                                
                                        <button class="btn btn-success"><a href="update-reswaste.php/' . $resto_id .'/'.$id.'" class="text-light"><i class="fa-solid fa-pen-to-square"></i></a></button>                              
                                        <button type="button" class = "confirm_del_btn btn btn-danger btn-sm"> <i class="fa-sharp fa-solid fa-trash"></i> </button>
                                        
                                        </td> </tr>';                                                                                                                               
                                    }
                                }
            
                                else 
                                {
                                    echo "No Record/s Found";
                                }
                            ?>                          
                        </tbody>
                    </table>   
                </div>
            </div>

            <div class="card">      
                <div class="card-header">
                    <h4 style="font-size: 30px; font-weight: 700;"> Special/Toxic Waste </h4>
                </div>
                <div class="card-body">
                    <table id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Special/Toxic Waste </th>
                                <th> Weight </th>                           
                                <th> Number of Containers </th>
                                <th> Frequency </th>
                                <th> Date Added </th>
                                <th> Date Updated </th>
                                <th> Actions </th>
                            </tr>   
                        </thead>
                        <tbody>
                            <?php                                
                                $logged_user = $_SESSION['auth_user']['id'];
                                $query = "SELECT * FROM stwaste WHERE resto_id = '$logged_user'" ; // Shows resto users
                                $query_run = mysqli_query($con, $query);
                                                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    foreach($query_run as $row)
                                    {                                 
                                        $id = $row['id'];
                                        $resto_id = $row['resto_id'];
                                        $stwaste = $row['stwaste'];
                                        $weight = $row['weight']; 
                                        $containers = $row['containers'];
                                        $frequency = $row['frequency'];
                                        $created_at = $row['created_at']; 
                                        $updated_at = $row['updated_at']; 

                                        $_SESSION['auth_stwaste'] = ['id' => $row['id'], 'resto_id' => $row['resto_id'],];                            

                                        echo '<tr>
                                        <td scope="row">' . $id . '</td>               
                                        <td scope="row">'  . $stwaste . '</td>
                                        <td scope="row">' . $weight . " Kg" . '</td>
                                        <td scope="row">' . $containers . '</td>
                                        <td scope="row">' . $frequency . '</td>
                                        <td scope="row">' . date('Y-m-d, h:i:s A', strtotime($created_at)) . '</td>';

                                        if ($updated_at === null) 
                                        {
                                            echo '<td scope="row">' . "N/A" . '</td>'; 
                                        } else {
                                            echo '<td scope="row">' . date('Y-m-d, h:i:s A', strtotime($updated_at)) . '</td>';
                                        }

                                        echo '<td class="text-center">     
                                                
                                        <button class="btn btn-success"><a href="update-stwaste.php/' . $resto_id .'/'.$id.'" class="text-light"><i class="fa-solid fa-pen-to-square"></i></a></button>                              
                                        <button type="button" class = "confirm_del_btn btn btn-danger btn-sm"> <i class="fa-sharp fa-solid fa-trash"></i> </button>
                                        
                                        </td> </tr>';                                                                                                                               
                                    }
                                }
            
                                else 
                                {
                                    echo "No Record/s Found";
                                }
                            ?>                          
                        </tbody>
                    </table>   
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script>
    $(document).ready(function () {

        $('.confirm_del_btn').on('click', function () {

            $('#deletemodal').modal('show');

            $tr = $(this).closest('tr');

            var data = $tr.children("td").map(function () {
                return $(this).text();
            }).get();

            console.log(data);

            $('#delete_id').val(data[0]);

        });
    });
</script>