<?php
$page_title = "Dashboard";
include 'dbcon.php';
include 'authentication.php';
include 'includes/header.php';
include 'includes/navbar.php';

if($_SESSION['user_type'] != 'resto') 
{
    header("Location: error.html");
}

$sessionCsrfToken = $_SESSION['csrf_token'];

$userCsrfTokenQuery = "SELECT csrf_token FROM userresto WHERE resto_id = {$_SESSION['auth_user']['id']}";
$userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
$userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
$userCsrfToken = $userCsrfTokenRow['csrf_token'];

if ($sessionCsrfToken !== $userCsrfToken) {
    header("Location: error.html");
    exit;
}

$logged_user = $_SESSION['auth_user']['id'];
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style-resto.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <!-- Bootstrap JavaScript and jQuery -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
    <style>
        body{    
        background: #DCDCDC;
    }

    thead {
        border: 1px solid black;
    }
    th {
        border: 1px solid black;
        padding: 5px;
        text-align:center;
    }
    td {
        border: 1px solid black;
    }

    </style>

</head>
<body>
    <div class="sidebar">
        <div class="col-md-11 mx-auto">    
            <div class="card shadow mt-3">     
                <form action="" method="GET">                   
                    <div class="card-header">
                        <h5>                              
                            <button onClick="window.print();" class="btn btn-success btn-sm float-en" style="font-size: 15px">Print  </button> 
                            <button onClick="location.href='/ewaste/visuals-resto'" type="button" class="btn btn-success btn-sm float-en"> Reset </button>
                            <button type="submit" class="btn btn-success btn-sm float-en" name="search">Search</button>                        
                        </h5>
                    </div>     
                   
                    
                    <!-- DURATION FILTER --> 
                        <div class="card-body">   
                            <h6>Duration</h6>
                                                                                                                
                                <lable>From Date</label>

                                <?php 
                                    if (!empty(($_GET['from_date'])))
                                    {                                        
                                        $timelog = $_GET['from_date'];
                                        $_SESSION['action'] = "Filtered Time Start: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $fromDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="from_date" class="form-control" value="<?php if (isset($_GET['from_date'])){echo $fromDate;};?>" >

                                <lable>To Date</label>

                                <?php 
                                    if (!empty(($_GET['to_date'])))
                                    {                                        
                                        $timelog = $_GET['to_date'];
                                        $_SESSION['action'] = "Filtered Time End: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $toDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="to_date" class="form-control" value="<?php if (isset($_GET['to_date'])){echo $toDate;};?>" >          
                        </div>                                
                                                      
                </form>      
                                 
                <form action="excel-download.php" method="POST"> <!-- DOWNLOAD BUTTON --> 
                    <?php       
                    //DURATION DATE FILTER
                        if(isset($_GET['from_date'])) 
                        {      
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                        
                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                                                           
                                $query = "SELECT * FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date'";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else{
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                          
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                                        
                                    ?>
                                    <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                        <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                    <?php
                                }
                            }

                            //FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))                              
                            {                                                 
                                $query = "SELECT * FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW()";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));   
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                          
                                    
                                    $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                                                    
                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php
                            }
                        }
                    ?>                            
                </form>
                
                <hr>
                <?php
                if(isset($_GET['filter']) && !empty($_GET['filter'])) 
                {
                    echo "<span style='font-weight: 600; position: relative; top: -0px; left: 10px;'>Selected Restaurant/s: </span>";
                    $showresto = implode(", ", $checked);
                    echo "<span style='font-size: 14px; font-weight: 500; position: relative; top: -0px; left: 5px;'>".$showresto."</span>";
                }

                if(isset($_GET['filtercity']) && !empty($_GET['filtercity'])) 
                {
                    echo "<span style='font-weight: 600; position: relative; top: -0px; left: 10px;'>Selected City: </span>";
                    $showresto = implode(", ", $checked2);
                    echo "<span style='font-size: 14px; font-weight: 500; position: relative; top: -0px; left: 5px;'>".$showresto."</span>";
                }
                                                                
                ?>

            </div>
        </div>      
    </div>

    <!-- CHARTS --> 
    <div class="visuals - script"> 
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // PIE CHART
                google.charts.load('current', {'packages':['corechart']});
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                    ['', ''], 
                    
                    <?php
                        
                        // FILTER BY DATE 
                        if(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                        {
                            $restonames_7FL_PC = array();
                            $rawcosts_7FL_PC = array();     
                            $rcities_7FL_PC = array(); 
                            $restoname_city_7FL_PC = array();
                            $created_7FL_PC = array();
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];

                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                              
                                $query = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname, rcity, AVG(rawcost) AS rawcost, 
                                restoname AS restoname_only, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY restoname, rcity";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $restoname = $result['restoname'];
                                        $rawcost = $result['rawcost'];   
                                        $rcity = $result['rcity'];      
                                        $restoname_only = $result['restoname_only'];  
                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                        
                                        $restonames_7FL_PC[] = $restoname_only;                                      
                                        $rawcosts_7FL_PC[] = $rawcost; 
                                        $rcities_7FL_PC[] = $rcity;
                                        $restoname_city_7FL_PC[] = $restoname;  
                                        $created_7FL_PC[] = $created;

                                        ?>      
                                        ['<?php echo $restoname;?>', <?php echo $rawcost ;?>],  
                                        <?php                 
                                    }    
                                                                                                        
                                }    
                            }
                                                    
                            // FILTER FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))
                            {
                                $query = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname, rcity, AVG(rawcost) AS rawcost, 
                                restoname AS restoname_only, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY restoname";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $restoname = $result['restoname'];
                                        $rawcost = $result['rawcost'];   
                                        $rcity = $result['rcity'];      
                                        $restoname_only = $result['restoname_only'];  
                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                        
                                        $restonames_7FL_PC[] = $restoname_only;                                      
                                        $rawcosts_7FL_PC[] = $rawcost; 
                                        $rcities_7FL_PC[] = $rcity;
                                        $restoname_city_7FL_PC[] = $restoname;  
                                        $created_7FL_PC[] = $created;
                                        ?>      
                                        ['<?php echo $restoname;?>', <?php echo $rawcost ;?>],  
                                        <?php                 
                                    }                                                                                                       
                                }             
                            }     
                        }                     

                        // NULL
                        else
                        {                                      
                            ?>
                            ['<?php echo "null";?>', <?php echo "null" ;?>],
                            <?php          
                            
                        }
           
                    ?>

                    ]);

                    var options = {
                        title: 'Average Raw Cost (₱)',
                        pieSliceText: 'value',
                        sliceVisibilityThreshold: 0,
                        colors: ['#008000', '#0000FF', '#FF0000', '#800080', '#4682B4', '#D2691E', '#808000', '#800000', '#808080', '#FFFF00'],
                        tooltip: {
                            trigger: 'selection',
                            isHtml: true
                        },

                        titleTextStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '16',                           
                        },
                        pieSliceTextStyle: {                         
                            fontSize: '11',
                        },

                        legend: {           
                            position: 'right',
                            alignment: 'center',                
                            textStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '14',                            
                            },
                            maxLines: 1,
                        },
                        chartArea: {
                            width: '85%' // increase the chart area width
                        },

                        backgroundColor: {
                            'stroke': 'black',
                            'strokeWidth': 10
                        }
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                    chart.draw(data, options);

                    var svgElement = document.querySelector('#piechart svg');
                    svgElement.setAttribute('style', 'border-radius: 5px;');

                    document.getElementById('chart-container').innerHTML += '<div class="info-icon"><i class="fa fa-info-circle"></i></div>';
      
                    document.querySelector('.info-icon').addEventListener('click', function() {

                        document.getElementById('myModal').style.display = "block";
                    });

                    document.querySelector('.close').addEventListener('click', function() {
       
                    document.getElementById('myModal').style.display = "none";

                    });                    
                }
        </script>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // COLUMN CHART
            google.charts.load("current", {packages:['corechart']});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([
            ["", "Cost (₱)"],
                        
                <?php 
                    $data = []; 

                    // FILTER BY DATE 
                    if(isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT restoname, resto_id, reason, AVG(rawcost) AS rawcost FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT restoname, resto_id, reason, AVG(rawcost) AS rawcost FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                            {
                                $reason = $row['reason'];
                                $rawcost = $row['rawcost'];
                                $data[] = ['reason' => $reason, 'rawcost' => $rawcost];   
                                ?>      
                                ['<?php echo $reason;?>', <?php echo number_format($rawcost, 2, '.', ''); ?>],     
                                <?php                 
                            }                                                                                                           
                        }   

                        if(count($data) == 0) 
                        {
                            echo "['No data', 0]";
                        }
                    }

                    else // To show chart when no filter is set              
                    {                                
                        ?>
                        ['<?php echo "";?>', <?php echo 0 ;?>],
                        <?php                        
                    }
                ?>

            ]);

                var view = new google.visualization.DataView(data);
                
                var options = {
                    colors: ['#008000'],
                    title: 'Average Raw Cost (₱) Based on the Different Factors Leading to Food Wastage',    
                    bar: {groupWidth: "35%"},
                    legend: { position: "none" },        
                    chartArea: {                          
                        backgroundColor: {
                        //fill: '#9CBE8C',
                    }
                    },                   

                    titleTextStyle: {
                        color: '#000000',
                        bold: true,
                        fontSize: '20',
                    },
                    
                    vAxis: {
                        textStyle:{
                            color: '#000000',
                            bold: true,                           
                        },
                    },
                    hAxis: {                           
                        textStyle:{
                            color: '#000000',
                            bold: true,
                            fontSize: 10,                                                             
                        },                          
                        slantedText: true,
                        slantedTextAngle: 25                        
                    },

                    backgroundColor: {
                        //fill: '#9CBE8C',
                        'stroke': 'black', 
                        'strokeWidth': 10,                           
                    },                                    
                };

                    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
                    chart.draw(view, options);

                    var svgElement = document.querySelector('#columnchart_values svg');
                    svgElement.setAttribute('style', 'border-radius: 5px;');

                    document.getElementById('column-chart-container').innerHTML += '<div class="info-icon-column"><i class="fa fa-info-circle"></i></div>';
      
                    document.querySelector('.info-icon-column').addEventListener('click', function() {

                    document.getElementById('myModal-column-chart').style.display = "block";

                    // Select the close button inside the currently displayed modal
                    const closeBtn = document.querySelector('#myModal-column-chart .close');
                    
                        closeBtn.addEventListener('click', function() {
        
                            document.getElementById('myModal-column-chart').style.display = "none";

                        });
                    });           
                }
        </script> 

        <script type="text/javascript"> // BAR CHART
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ["", "Cost (₱)"],
              
                <?php 
                    $data = []; 

                    // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date']) && !empty($_GET['from_date'])) 
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT restoname, resto_id, foodtype, AVG(rawcost) AS rawcost FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT restoname, resto_id, foodtype, AVG(rawcost) AS rawcost FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                            {
                                $foodtype = $row['foodtype'];
                                $rawcost = $row['rawcost'];
                                $data[] = ['foodtype' => $foodtype, 'rawcost' => $rawcost];   
                                ?>      
                                ['<?php echo $foodtype;?>', <?php echo number_format($rawcost, 2, '.', ''); ?>],     
                                <?php                 
                            }                                                                                                           
                        }   

                        if(count($data) == 0) 
                        {
                            echo "['No data', 0]";
                        }
                    }

                    else                   
                    {                                
                        ?>
                        ['<?php echo "";?>', <?php echo 0 ;?>],
                        <?php                        
                    }
                ?>
            ]);

            var view = new google.visualization.DataView(data);

            var options = {
                title: "Average Raw Cost (₱) Based on Type of Food",
                colors: ['#008000'],
                bar: {groupWidth: "35%"},
                legend: { position: "none" },

                titleTextStyle: {
                        color: '#000000',
                        bold: true,
                        fontSize: '20',
                    },
                    titlePosition: 'center',
                    vAxis: {
                        textStyle:{
                            color: '#000000',
                            bold: true,  
                            fontSize: 15,                         
                        },
                    },
                    hAxis: {                           
                        textStyle:{
                            color: '#000000',
                            bold: true,
                            fontSize: 10,                                                             
                        },                                                 
                    },

                    backgroundColor: {                   
                        'stroke': 'black',
                        'strokeWidth': 10,                           
                    },    
            };
            var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
            chart.draw(view, options);

            var svgElement = document.querySelector('#barchart_values svg');
            svgElement.setAttribute('style', 'border-radius: 5px;');

            document.getElementById('bar-chart-container').innerHTML += '<div class="info-icon-bar"><i class="fa fa-info-circle"></i></div>';
      
            document.querySelector('.info-icon-bar').addEventListener('click', function() {

            document.getElementById('myModal-bar-chart').style.display = "block";

                // Select the close button inside the currently displayed modal
                const closeBtn = document.querySelector('#myModal-bar-chart .close');
                
                    closeBtn.addEventListener('click', function() {

                        document.getElementById('myModal-bar-chart').style.display = "none";

                    });
                });          
            }
        </script>

    </div>
    
    <!-- VS CARDS -->  

    <div id="vscard2" class="card">
        <div class="card-header" style="font-size:150%;"><b><center>Total Cost of Food Wasted</b></center>
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 2
                        
                    // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date']) && !empty($_GET['from_date'])) 
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT SUM(rawcost) AS rawcost, restoname FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;
                            }          
                        }                                    

                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT SUM(rawcost) AS rawcost, restoname FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $rawcost = $result['rawcost'];                          
                                
                                $total_rawcost += $rawcost;

                            }       
                        }
                        echo '<h4 class="mb-0 text-center">₱' . number_format($total_rawcost, 2, '.', ','); 
                    }
                                            
                ?>
            </div>                    
    </div>

    <div id="vscard3" class="card">
        <div class="card-header" style="font-size:150%;"><b><center>Average Cost of Food Wasted</b></center>
           
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 3
                        
                    // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date']) && !empty($_GET['from_date'])) 
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT AVG(rawcost) AS avg_rawcost, restoname FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' ";
                            $query_run = mysqli_query($con, $query);

                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];        
                        }                                    

                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT AVG(rawcost) AS avg_rawcost, restoname FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() ";
                            $query_run = mysqli_query($con, $query);

                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];     
                        }
                        echo '<h4 class="mb-0 text-center">₱' . number_format($avg_rawcost, 2, '.', ',') . '</h4>';   
                    }
                ?>
            </div>                    
    </div>
    
    <!-- VISUALS & MODALS--> 
    <div class="visuals">

        <!-- MODALS -->             
        <?php
            // PIE CHART MODAL (POP UP)
            
                // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants and Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurants</th>
                                                <th>City</th>
                                                <th>Average Raw Cost (₱)</th>
                                                <th>Date Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_7FL_PC, SORT_DESC, $restonames_7FL_PC, $rcities_7FL_PC, $restoname_city_7FL_PC, $created_7FL_PC,);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($restonames_7FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restonames_7FL_PC[$i]; ?></td>
                                                <td><?php echo $rcities_7FL_PC[$i]; ?></td>
                                                <td>₱<?php echo number_format($rawcosts_7FL_PC[$i], 2, '.', ','); ?></td>
                                                <td><?php echo $created_7FL_PC[$i]; ?></td> 
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rawcosts_7FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_7FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restonames_7FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[count($rawcosts_7FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restoname_city_7FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[1] . " (2nd Highest) and an average of ₱" . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[count($restoname_city_7FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php  
                    }

            // COLUMN CHART MODAL    
            
                // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {
                        $restoname_7FL_CC = array();
                        $reason_7FL_CC = array();
                        $rawcost_7FL_CC = array();
                        $restoname_city_7FL_CC = array();
                        $rcity_7FL_CC = array();
                        $created_7FL_CC = array(); 

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname_city, restoname, reason, rcity, AVG(rawcost) AS rawcost, created_at FROM waste 
                            WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY restoname, reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $rawcost = $row_CC['rawcost'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_7FL_CC[] = $restoname;
                                    $reason_7FL_CC[] = $reason;
                                    $rawcost_7FL_CC[] = $rawcost;
                                    $restoname_city_7FL_CC[] = $restoname_city;
                                    $rcity_7FL_CC[] = $rcity;   
                                    $created_7FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Raw Cost (₱)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_CC, SORT_DESC, $restoname_7FL_CC, $reason_7FL_CC, $restoname_city_7FL_CC, $rcity_7FL_CC, $created_7FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_7FL_CC[$i]; ?></td>                                                  
                                                    <td>₱<?php echo number_format($rawcost_7FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_CC) == 2) {
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_CC) > 2) {
                                            // Calculate the difference in rawcost between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[count($rawcost_7FL_CC) - 1];
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . " (2nd Highest) and an average of ₱" . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_CC[count($restoname_7FL_CC) - 1] . " with " . $reason_7FL_CC[count($reason_7FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if (empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname_city, restoname, reason, rcity, AVG(rawcost) AS rawcost, created_at FROM waste 
                            WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY restoname, reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $rawcost = $row_CC['rawcost'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_7FL_CC[] = $restoname;
                                    $reason_7FL_CC[] = $reason;
                                    $rawcost_7FL_CC[] = $rawcost;
                                    $restoname_city_7FL_CC[] = $restoname_city;
                                    $rcity_7FL_CC[] = $rcity;   
                                    $created_7FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Raw Cost (₱)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_CC, SORT_DESC, $restoname_7FL_CC, $reason_7FL_CC, $restoname_city_7FL_CC, $rcity_7FL_CC, $created_7FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_7FL_CC[$i]; ?></td>                                                  
                                                    <td>₱<?php echo number_format($rawcost_7FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_CC) == 2) {
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_CC) > 2) {
                                            // Calculate the difference in rawcost between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[count($rawcost_7FL_CC) - 1];
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . " (2nd Highest) and an average of ₱" . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_CC[count($restoname_7FL_CC) - 1] . " with " . $reason_7FL_CC[count($reason_7FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        } 
                    }

            // BAR CHART MODAL

                // FILTER BY DATE  
                    if(isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {
                        $restoname_7FL_BC = array();
                        $foodtype_7FL_BC = array();
                        $rawcost_7FL_BC = array();
                        $restoname_city_7FL_BC = array();
                        $rcity_7FL_BC = array();
                        $created_7FL_BC = array();

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname_city, restoname, foodtype, rcity, AVG(rawcost) AS rawcost, created_at FROM waste 
                            WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY restoname, foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $rawcost = $row_BC['rawcost'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_7FL_BC[] = $restoname;
                                    $foodtype_7FL_BC[] = $foodtype;
                                    $rawcost_7FL_BC[] = $rawcost;
                                    $restoname_city_7FL_BC[] = $restoname_city;
                                    $rcity_7FL_BC[] = $rcity;   
                                    $created_7FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Time frame of average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Raw Cost (₱)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_BC, SORT_DESC, $restoname_7FL_BC, $foodtype_7FL_BC, $restoname_city_7FL_BC, $rcity_7FL_BC, $created_7FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_7FL_BC[$i]; ?></td>                                                  
                                                    <td>₱<?php echo number_format($rawcost_7FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_BC) == 2) {
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_BC) > 2) {
                                            // Calculate the difference in rawcost between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[count($rawcost_7FL_BC) - 1];
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_BC[1] . " (2nd Highest) and an average of ₱" . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_BC[count($restoname_7FL_BC) - 1] . " with " . $foodtype_7FL_BC[count($foodtype_7FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if(empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(restoname, ' (', rcity, ')') AS restoname_city, restoname, foodtype, rcity, AVG(rawcost) AS rawcost, created_at FROM waste 
                            WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY restoname, foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $rawcost = $row_BC['rawcost'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_7FL_BC[] = $restoname;
                                    $foodtype_7FL_BC[] = $foodtype;
                                    $rawcost_7FL_BC[] = $rawcost;
                                    $restoname_city_7FL_BC[] = $restoname_city;
                                    $rcity_7FL_BC[] = $rcity;   
                                    $created_7FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Time frame of average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Raw Cost (₱)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_BC, SORT_DESC, $restoname_7FL_BC, $foodtype_7FL_BC, $restoname_city_7FL_BC, $rcity_7FL_BC, $created_7FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_7FL_BC[$i]; ?></td>                                                  
                                                    <td>₱<?php echo number_format($rawcost_7FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_BC) == 2) {
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_BC) > 2) {
                                            // Calculate the difference in rawcost between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[count($rawcost_7FL_BC) - 1];
                                            // Calculate the difference in rawcost between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of ₱" . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_BC[1] . " (2nd Highest) and an average of ₱" . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_BC[count($restoname_7FL_BC) - 1] . " with " . $foodtype_7FL_BC[count($foodtype_7FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        } 
                    }
            
            // VSCARD2 MODAL
          
                // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(rawcost) AS rawcost, restoname, rcity, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY restoname ORDER BY rawcost DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                             <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Raw Cost</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $rawcost = $result['rawcost'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "₱" . number_format($rawcost, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total rawcost data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(rawcost) AS rawcost, restoname, rcity, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY restoname ORDER BY rawcost DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Raw Cost</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $rawcost = $result['rawcost'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "₱" . number_format($rawcost, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total rawcost data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

            // VSCARD3 MODAL
              
                // FILTER BY DATE 
                    if(isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(rawcost) AS rawcost, restoname, rcity, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND '$to_date' GROUP BY restoname ORDER BY rawcost DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                           <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Raw Cost</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $rawcost = $result['rawcost'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "₱" . number_format($rawcost, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average rawcost data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(rawcost) AS rawcost, restoname, rcity, created_at FROM waste WHERE resto_id = '$logged_user' AND created_at BETWEEN '$from_date' AND NOW() GROUP BY restoname ORDER BY rawcost DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Raw Cost</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $rawcost = $result['rawcost'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "₱" . number_format($rawcost, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average rawcost data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }
                
        ?>

        <div class="chart-wrapper">
            <div id="piechart"></div>
            <div id="chart-container"></div>
        </div>

        <div class="chart-wrapper-column">
            <div id="columnchart_values"></div>  
            <div id="column-chart-container"></div> <!-- info icon columnchart-->
        </div>    
        
        <div class="chart-wrapper-bar">
            <div id="barchart_values"></div>       
            <div id="bar-chart-container"></div> <!-- info icon barchart-->
        </div>   

        <div id="vscard1-container"></div> 

        <div id="vscard2-container"></div>
                    
        <div id="vscard3-container"></div>
    </div>

    <a href="/ewaste/visuals-weight-resto" id="visual-link">View Weight Data</a>

</body>
</html>

<script>
    document.getElementById('vscard1-container').innerHTML += '<div class="info-icon-vscard1"><i class="fa fa-info-circle"></i></div>';
      
    document.querySelector('.info-icon-vscard1').addEventListener('click', function() {

        document.getElementById('myModal-vscard').style.display = "block";
    });

    document.querySelector('.close-vscard').addEventListener('click', function() {

    document.getElementById('myModal-vscard').style.display = "none";

    });    
    
    document.getElementById('vscard2-container').innerHTML += '<div class="info-icon-vscard2"><i class="fa fa-info-circle"></i></div>';
      
      document.querySelector('.info-icon-vscard2').addEventListener('click', function() {
  
          document.getElementById('myModal-vscard2').style.display = "block";
      });
  
      document.querySelector('.close-vscard2').addEventListener('click', function() {
  
      document.getElementById('myModal-vscard2').style.display = "none";
  
      });      

      document.getElementById('vscard3-container').innerHTML += '<div class="info-icon-vscard3"><i class="fa fa-info-circle"></i></div>';
      
      document.querySelector('.info-icon-vscard3').addEventListener('click', function() {
  
          document.getElementById('myModal-vscard3').style.display = "block";
      });
  
      document.querySelector('.close-vscard3').addEventListener('click', function() {
  
      document.getElementById('myModal-vscard3').style.display = "none";
  
      });     
</script>