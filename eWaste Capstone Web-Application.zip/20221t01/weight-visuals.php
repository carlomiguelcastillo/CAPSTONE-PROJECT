<?php
    $page_title = "Dashboard";
    include 'dbcon.php';
    include 'authentication.php';
    include 'includes/header.php';
    include 'includes/navbar.php';

    if($_SESSION['user_type'] != 'org') 
    {
        header("Location: error.html");
    }

    // Get the CSRF token from the session
    $sessionCsrfToken = $_SESSION['csrf_token'];

    // Get the user's CSRF token from the database
    $userCsrfTokenQuery = "SELECT csrf_token FROM userorg WHERE id = {$_SESSION['auth_user']['id']}";
    $userCsrfTokenResult = mysqli_query($con, $userCsrfTokenQuery);
    $userCsrfTokenRow = mysqli_fetch_assoc($userCsrfTokenResult);
    $userCsrfToken = $userCsrfTokenRow['csrf_token'];

    // Validate the CSRF token
    if ($sessionCsrfToken !== $userCsrfToken) {
        // CSRF token does not match, handle the error (e.g., redirect to an error page)
        header("Location: error.html");
        exit;
    }

    // CSRF token is valid, continue with further processing
    // ...
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <!-- Bootstrap JavaScript and jQuery -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    
    <style>
        body{    
        background: #DCDCDC;
        }

        thead {
            border: 1px solid black;
        }
        th {
            border: 1px solid black;
            padding: 5px;
            text-align:center;
        }
        td {
            border: 1px solid black;
        }

    </style>

</head>
<body>
    <div class="sidebar">
        <div class="col-md-11 mx-auto">    
            <div class="card shadow mt-3">     
                <form action="" method="GET">                   
                    <div class="card-header">
                        <h5>                              
                            <button onClick="window.print();" class="btn btn-success btn-sm float-en" style="font-size: 15px">Print  </button> 
                            <button onClick="location.href='/ewaste/visuals-weight'" type="button" class="btn btn-success btn-sm float-en"> Reset </button>
                            <button type="submit" class="btn btn-success btn-sm float-en" name="search">Search</button>                        
                        </h5>
                    </div>     
                   
                    <!-- RESTO DROPDOWN FILTER -->   
                        <div class="card-body">                                                  
                            <div class="dropdown d-inline-flex">
                                <button class="btn btn-success dropdown-toggle" type="button" id="restaurantDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Select Restaurants
                                </button>
                                <div class="dropdown-menu w-100" aria-labelledby="restaurantDropdown">
                                <div class="form-check mx-2">
                                    <input class="form-check-input" type="checkbox" id="checkAll" />
                                    <label class="form-check-label" for="checkAll">Check All</label>
                                </div>
                                    <?php                              
                                        $query = "SELECT ur.restoname FROM waste w JOIN userresto ur ON ur.resto_id = w.resto_id GROUP BY ur.restoname";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0) // this is to check if the record in the database exists or not
                                        {                               
                                            foreach($query_run as $list) // Loops thru the data
                                            {
                                                $rrestoname = "'" . $list['restoname'] . "'";
                                                $checked = [];
                                                if(isset($_GET['filter']) && !empty($_GET['filter'])) // If resto is checked, it still store the data in checkbox
                                                {                                                                                                         
                                                    $checked = $_GET['filter'];                                                                           
                                                }                                                                                                 
                                                    ?>
                                                <div class="form-check mx-2">
                                                    <input class="form-check-input" type="checkbox" name="filter[]" value="<?= $rrestoname; ?>" 
                                                        <?php 
                                                        if(in_array($rrestoname, $checked)) // If a checkbox (resto) is checked
                                                        {
                                                            $restolog = $list['restoname'];
                                                            $_SESSION['action'] = "Filtered Restaurant: $restolog";

                                                            $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES
                                                            ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                                            $log_query_run = mysqli_query($con, $log_query);

                                                            if($log_query_run)
                                                            {
                                                            echo "checked";
                                                            }
                                                        } 
                                                        ?>
                                                    />
                                                    <label class="form-check-label"><?= $list['restoname']; //Shows the list of Restos?></label> 
                                                </div>
                                        <?php
                                            } 
                                        }
                                    ?>
                                </div>
                            </div>
                        </div>
                    
                    <!-- CITY DROPDOWN FILTER -->
                        <div class="card-body">   
                            <div class="dropdown d-inline-flex">
                                <button class="btn btn-success dropdown-toggle" type="button" id="citiesDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width: 170px;">
                                    Select Cities
                                </button>
                                <ul class="dropdown-menu w-100" aria-labelledby="citiesDropdown">
                                <li>
                                    <div class="form-check mx-2">
                                    <input class="form-check-input" type="checkbox" id="checkAllCities" />
                                    <label class="form-check-label" for="checkAllCities">Check All</label>
                                    </div>
                                </li>
                                    <?php
                                    $query = "SELECT ur.rcity FROM waste w JOIN userresto ur ON ur.resto_id = w.resto_id GROUP BY ur.rcity";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0) {
                                        foreach($query_run as $list) {
                                        $rcityy = "'" . $list['rcity'] . "'";
                                        $checked2 = [];                             
                                        if(isset($_GET['filtercity'])) {
                                            $checked2 = $_GET['filtercity'];                                       
                                        }
                                    ?>
                                        <li>
                                            <div class="form-check mx-2">
                                                <input class="form-check-input" type="checkbox" name="filtercity[]" value="<?= $rcityy; ?>"
                                                    <?php 
                                                    if(in_array($rcityy, $checked2)) {                                        
                                                        $restolog = $list['rcity'];
                                                        $_SESSION['action'] = "Filtered City: $restolog";
                                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                                        $log_query_run = mysqli_query($con, $log_query);
                                                        if($log_query_run) {
                                                        echo "checked";
                                                        }
                                                    } 
                                                    ?>
                                                />
                                                <label class="form-check-label"><?= $list['rcity']; ?></label>
                                            </div>
                                        </li>
                                    <?php
                                        } 
                                    }
                                    ?>
                                </ul>
                            </div> 
                        </div>
                    
                    <!-- DURATION FILTER --> 
                        <div class="card-body">   
                            <h6>Duration</h6>
                                                                                                                
                                <lable>From Date</label>

                                <?php 
                                    if (!empty(($_GET['from_date'])))
                                    {                                        
                                        $timelog = $_GET['from_date'];
                                        $_SESSION['action'] = "Filtered Time Start: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $fromDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="from_date" class="form-control" value="<?php if (isset($_GET['from_date'])){echo $fromDate;};?>" >

                                <lable>To Date</label>

                                <?php 
                                    if (!empty(($_GET['to_date'])))
                                    {                                        
                                        $timelog = $_GET['to_date'];
                                        $_SESSION['action'] = "Filtered Time End: $timelog";

                                        $log_query = "INSERT INTO orglog (user_id, username, email, user_type, action_made) VALUES ('{$_SESSION['auth_user']['id']}', '{$_SESSION['auth_user']['username']}', '{$_SESSION['auth_user']['email']}', '{$_SESSION['user_type']}', '{$_SESSION['action']}')";
                                        $log_query_run = mysqli_query($con, $log_query);

                                        $toDate = date("Y-m-d", strtotime($timelog));
                                    } 
                                ?>

                                <input type="date" name="to_date" class="form-control" value="<?php if (isset($_GET['to_date'])){echo $toDate;};?>" >          
                        </div>                                
                                                      
                </form>      
                                 
                <form action="excel-download.php" method="POST"> <!-- DOWNLOAD BUTTON --> 
                    <?php       
                    //RESTO FILTER          
                        if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {         
                            $data[] = array("Restaurant Name", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                            foreach($checked as $row)
                            {
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.restoname IN ($row)";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $email = $result['email'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));   
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                   
                                    
                                    $data[] = array($restoname, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                            }                       
                            ?>
                            <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                            <?php
                        }
                    //CITY FILTER
                        elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {   
                            $data[] = array("City", "Email", "Restaurant Name", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                            foreach($checked2 as $row2)
                            {
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.rcity IN ($row2)";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $restoname = $result['restoname'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                             
                                    
                                    $data[] = array($city, $email, $restoname, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                            }                       
                            ?>
                            <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                            <?php
                        }                       
                    //RESTO & CITY FILTER  
                        elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {   
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                            foreach($checked as $row)
                            {
                                foreach($checked2 as $row2)  
                                {
                                    $query = "SELECT *
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2)";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at'])); 
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else{
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                         
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                } 
                            }                      
                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php                    
                        }     
                    //DURATION DATE FILTER
                        elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                        {      
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                        
                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                                                           
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE w.created_at BETWEEN '$from_date' AND '$to_date'";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else{
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                          
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                                        
                                    ?>
                                    <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                        <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                    <?php
                                }
                            }

                            //FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))                              
                            {                                                 
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE w.created_at BETWEEN '$from_date' AND NOW()";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));   
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else{
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                          
                                    
                                    $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                                                    
                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php
                            }
                        }
                    //ALL FILTERS
                        elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date'])) 
                        {                             
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                            foreach($checked as $row)
                            {
                                foreach($checked2 as $row2)  
                                {
                                    $query = "SELECT *
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at'])); 
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else {
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                      
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                } 
                            }                    
                            
                            //NO TO DATE FILTER
                            if(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date'])) 
                            {  
                                $from_date = $_GET['from_date'];                    
                                foreach($checked as $row)
                                {
                                    foreach($checked2 as $row2)  
                                    {
                                        $query = "SELECT *
                                        FROM waste w
                                        JOIN userresto ur ON ur.resto_id = w.resto_id
                                        WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                                        $query_run = mysqli_query($con, $query);
                                        
                                        while($result = mysqli_fetch_array($query_run))
                                        {
                                            $restoname = $result['restoname'];
                                            $city = utf8_encode($result['rcity']);
                                            $email = $result['email'];
                                            $restotype = $result['restotype'];
                                            $foodtype = $result['foodtype'];
                                            $rawcost = $result['rawcost']; 
                                            $weight = $result['weight'];
                                            $frequency = $result['frequency'];
                                            $reason = $result['reason'];
                                            $created_at = date("Y-m-d", strtotime($result['created_at'])); 
                                            if($result['updated_at'] === null) 
                                            {
                                                $result['updated_at'] = " "; 
                                            } else {
                                                $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                            }                                                                         
                                            
                                            $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                        }
                                    } 
                                }        
                            }      

                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php                    
                        }  
                    //RESTO FILTER & DURATION FILTER USED
                        elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date'])) 
                        {                             
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                            foreach($checked as $row)
                            {                               
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.restoname IN ($row) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else {
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                        
                                    
                                    $data[] = array($restoname, $city, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                            }      
                            
                            if(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date'])) 
                            { 
                                $from_date = $_GET['from_date'];                                                  
                                foreach($checked as $row)
                                {                               
                                    $query = "SELECT *
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.restoname IN ($row) AND w.created_at BETWEEN '$from_date' AND NOW()";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at']));  
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else {
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                       
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                }
                            }      

                                ?>
                                <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                    <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                                <?php                    
                        }  
                    //CITY FILTER & DURATION FILTER USED
                        elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                        { 
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $data[] = array("Restaurant Name", "City", "Email", "Restaurant Type", "Food Type", "Raw Cost", "Weight", "Frequency", "Reason", "Created At", "Updated At");                       
                        
                            foreach($checked2 as $row2)  
                            {
                                $query = "SELECT *
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $city = $result['rcity'];
                                    $email = $result['email'];
                                    $restotype = $result['restotype'];
                                    $foodtype = $result['foodtype'];
                                    $rawcost = $result['rawcost']; 
                                    $weight = $result['weight'];
                                    $frequency = $result['frequency'];
                                    $reason = $result['reason'];
                                    $created_at = date("Y-m-d", strtotime($result['created_at']));
                                    if($result['updated_at'] === null) 
                                    {
                                        $result['updated_at'] = " "; 
                                    } else {
                                        $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                    }                                                                          
                                    
                                    $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                }
                            } 

                            //CITY AND FROM DATE
                            if(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date']))
                            {
                                $from_date = $_GET['from_date'];                    
                            
                                foreach($checked2 as $row2)  
                                {
                                    $query = "SELECT *
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        //$city = utf8_encode($result['rcity']);
                                        $city = $result['rcity'];
                                        $email = $result['email'];
                                        $restotype = $result['restotype'];
                                        $foodtype = $result['foodtype'];
                                        $rawcost = $result['rawcost']; 
                                        $weight = $result['weight'];
                                        $frequency = $result['frequency'];
                                        $reason = $result['reason'];
                                        $created_at = date("Y-m-d", strtotime($result['created_at'])); 
                                        if($result['updated_at'] === null) 
                                        {
                                            $result['updated_at'] = " "; 
                                        } else {
                                            $result['updated_at'] = date("Y-m-d", strtotime($result['updated_at']));  ;
                                        }                                                                         
                                        
                                        $data[] = array($restoname, $city, $email, $restotype, $foodtype, $rawcost, $weight, $frequency, $reason, $created_at, $result['updated_at']);                              
                                    }
                                } 
                            }
                                                
                            ?>
                            <input type="hidden" name="data" value="<?php echo base64_encode(serialize($data)); ?>">
                                <button type="submit" class="btn btn-success btn-sm float-en" name="download" style="position:relative; left:30px;">Download Raw Data</button>  
                            <?php
                        }
                        
                    ?>                            
                </form>
                
                <hr>
                <?php
                    if(isset($_GET['filter']) && !empty($_GET['filter'])) 
                    {
                        echo "<span style='font-weight: 600; position: relative; top: -0px; left: 10px;'>Selected Restaurant/s: </span>";
                        $showresto = implode(", ", $checked);
                        echo "<span style='font-size: 14px; font-weight: 500; position: relative; top: -0px; left: 5px;'>".$showresto."</span>";
                    }

                    if(isset($_GET['filtercity']) && !empty($_GET['filtercity'])) 
                    {
                        echo "<span style='font-weight: 600; position: relative; top: -0px; left: 10px;'>Selected City: </span>";
                        $showresto = implode(", ", $checked2);
                        echo "<span style='font-size: 14px; font-weight: 500; position: relative; top: -0px; left: 5px;'>".$showresto."</span>";
                    }
                ?>

            </div>
        </div>      
    </div>

    <div class="space"></div>

    <!-- CHARTS --> 
    <div class="visuals - script"> 
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // PIE CHART
                google.charts.load('current', {'packages':['corechart']});
                google.charts.setOnLoadCallback(drawChart);

                function drawChart() {

                    var data = google.visualization.arrayToDataTable([
                    ['', ''], 
                    
                    <?php

                        // FILTER BY RESTO 
                        if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {         
                            foreach($checked as $row)
                            {
                                $query = "SELECT ur.restoname, AVG(w.weight) AS weight
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.restoname IN ($row)";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $restoname = $result['restoname'];
                                    $weight = $result['weight'];      

                                    $restonamesPC[] = $restoname;
                                    $rawcostsPC[] = $weight;
                                    
                                    ?>

                                    ['<?php echo $restoname;?>', <?php echo $weight ;?>], 
                                    <?php 
                                }                                             
                            }                        
                        }

                        // FILTER BY CITY 
                        elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                        {
                            foreach($checked2 as $row2)
                            {
                                $query = "SELECT ur.rcity, AVG(w.weight) AS weight
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.rcity IN ($row2)";
                                $query_run = mysqli_query($con, $query);
                                
                                while($result = mysqli_fetch_array($query_run))
                                {
                                    $rcity = $result['rcity'];
                                    $weight = $result['weight'];         
                                    
                                    $rcities[] = $rcity; 
                                    $rawcosts[] = $weight; 

                                    ?>

                                    ['<?php echo $rcity;?>', <?php echo $weight ;?>],
                                    <?php 
                                }
                               
                            }    
                        }   

                        // FILTER BY RESTO AND CITY
                        elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                        {         
                            $restonames_3FL_PC = array();
                            $rawcosts_3FL_PC = array();     
                            $rcities_3FL_PC = array(); 
                            $restoname_city_3FL_PC = array(); 
                            
                           foreach($checked as $row)
                           { 
                               foreach($checked2 as $row2)  
                               {                             
                                    $query = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname, ur.restoname AS restoname_only, ur.rcity, AVG(w.weight) AS weight 
                                    FROM waste w 
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2) GROUP BY ur.restoname";
                                    $query_run = mysqli_query($con, $query);
                               
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $weight = $result['weight'];  
                                        $rcity = $result['rcity'];      
                                        $restoname_only = $result['restoname_only'];    
                                        
                                        $restonames_3FL_PC[] = $restoname_only;                                      
                                        $rawcosts_3FL_PC[] = $weight; 
                                        $rcities_3FL_PC[] = $rcity;
                                        $restoname_city_3FL_PC[] = $restoname; 
                                        
                                        ?>

                                        ['<?php echo $restoname;?>', <?php echo $weight ;?>],
                                        <?php
                                    }                                 
                               }
                           }
                        }  

                        // ALL FILTERS USED
                        elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                        {
                            $restonames_4FL_PC = array();
                            $rawcosts_4FL_PC = array();     
                            $rcities_4FL_PC = array(); 
                            $restoname_city_4FL_PC = array();
                            $created_4FL_PC = array();

                            foreach($checked as $row)
                            { 
                                foreach($checked2 as $row2)  
                                {         
                                $from_date = $_GET['from_date'];
                                $to_date = $_GET['to_date'];      
                                $query = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname, ur.restoname AS restoname_only, ur.rcity, AVG(w.weight) AS weight, w.created_at
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname";
                                $query_run = mysqli_query($con, $query);
                                
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($result = mysqli_fetch_array($query_run))
                                        {
                                            $restoname = $result['restoname'];
                                            $weight = $result['weight'];   
                                            $rcity = $result['rcity'];      
                                            $restoname_only = $result['restoname_only'];  
                                            $created = date("Y-m-d", strtotime($result['created_at']));
                                            
                                            $restonames_4FL_PC[] = $restoname_only;                                      
                                            $rawcosts_4FL_PC[] = $weight; 
                                            $rcities_4FL_PC[] = $rcity;
                                            $restoname_city_4FL_PC[] = $restoname;  
                                            $created_4FL_PC[] = $created;

                                            ?>

                                            ['<?php echo $restoname;?>', <?php echo $weight ;?>],
                                            <?php
                                            
                                        }
                                    }
                                }
                            }

                            // NO TO DATE FILTER
                            if(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date']))
                            {
                                foreach($checked as $row)
                                { 
                                    foreach($checked2 as $row2)  
                                    {         
                                    $from_date = $_GET['from_date'];   
                                    $query = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname, ur.restoname AS restoname_only, ur.rcity, AVG(w.weight) AS weight, w.created_at
                                    FROM waste w 
                                    JOIN userresto ur ON ur.resto_id = w.resto_id
                                    WHERE ur.restoname IN ($row) AND ur.rcity IN ($row2) AND w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname";
                                    $query_run = mysqli_query($con, $query);
                                    
                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            while($result = mysqli_fetch_array($query_run))
                                            {
                                                $restoname = $result['restoname'];
                                                $weight = $result['weight'];   
                                                $rcity = $result['rcity'];      
                                                $restoname_only = $result['restoname_only'];  
                                                $created = date("Y-m-d", strtotime($result['created_at']));
                                                
                                                $restonames_4FL_PC[] = $restoname_only;                                      
                                                $rawcosts_4FL_PC[] = $weight; 
                                                $rcities_4FL_PC[] = $rcity;
                                                $restoname_city_4FL_PC[] = $restoname;  
                                                $created_4FL_PC[] = $created;    

                                                ?>

                                                ['<?php echo $restoname;?>', <?php echo $weight ;?>],
                                                <?php
                                                
                                            }                                        
                                        }
                                    }
                                }
                            }  
                        } 

                        // RESTO FILTER & DURATION FILTER USED
                        elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date'])) 
                        {
                            $restonames_5FL_PC = array();
                            $rawcosts_5FL_PC = array();     
                            $created_5FL_PC = array();

                            foreach($checked as $row)
                            {                              
                                $from_date = $_GET['from_date'];
                                $to_date = $_GET['to_date'];      
                                $query = "SELECT ur.restoname, ur.rcity, AVG(w.weight) as weight, w.created_at 
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id 
                                WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($row) GROUP BY ur.restoname";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $restoname = $result['restoname'];
                                        $weight = $result['weight'];    
                                        $created = date("Y-m-d", strtotime($result['created_at']));                      
                                 
                                        $rawcosts_5FL_PC[] = $weight; 
                                        $restonames_5FL_PC[] = $restoname;  
                                        $created_5FL_PC[] = $created;

                                        ?>

                                        ['<?php echo $restoname;?>', <?php echo $weight ;?>],
                                        <?php
                                        
                                    }

                                }                           
                            }

                            // RESTO FILTER & FROM DATE
                            if(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date'])) 
                            {
                                foreach($checked as $row)
                                {                              
                                    $from_date = $_GET['from_date'];
                                    $to_date = $_GET['to_date'];      
                                    $query = "SELECT ur.restoname, ur.rcity, AVG(w.weight) as weight, w.created_at 
                                    FROM waste w 
                                    JOIN userresto ur ON ur.resto_id = w.resto_id 
                                    WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($row) GROUP BY ur.restoname";
                                    $query_run = mysqli_query($con, $query);
                                    
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($result = mysqli_fetch_array($query_run))
                                        {
                                            $restoname = $result['restoname'];
                                            $weight = $result['weight'];   
                                            $created = date("Y-m-d", strtotime($result['created_at']));    
                                            
                                            $rawcosts_5FL_PC[] = $weight; 
                                            $restonames_5FL_PC[] = $restoname;  
                                            $created_5FL_PC[] = $created;
    
                                            ?>
    
                                            ['<?php echo $restoname;?>', <?php echo $weight ;?>],
                                            <?php
                                            
                                        }
                                    }                           
                                }
                            }   
                        }   

                        // CITY FILTER & DURATION FILTER USED
                        elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                        {   
                            $rawcosts_6FL_PC = array();     
                            $rcities_6FL_PC = array(); 
                            $created_6FL_PC = array();

                            foreach($checked2 as $row2)  
                            {         
                                $from_date = $_GET['from_date'];
                                $to_date = $_GET['to_date'];      
                                $query = "SELECT ur.rcity, AVG(w.weight) AS weight, w.created_at 
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id 
                                WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($row2) GROUP BY ur.rcity";
                                $query_run = mysqli_query($con, $query);
                                
                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run))
                                    {
                                        $rcity = $result['rcity'];
                                        $weight = $result['weight']; 
                                        $created = date("Y-m-d", strtotime($result['created_at']));    
                                        
                                        $rawcosts_6FL_PC[] = $weight; 
                                        $rcities_6FL_PC[] = $rcity;  
                                        $created_6FL_PC[] = $created;

                                        ?>

                                        ['<?php echo $rcity;?>', <?php echo $weight ;?>],
                                        <?php
                                        
                                    }
                                }
                            }

                            //CITY FILTER & FROM DATE FITLER
                            if(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && empty($_GET['to_date']))
                            {
                                foreach($checked2 as $row2)  
                                {         
                                    $from_date = $_GET['from_date'];
                                    $query = "SELECT ur.rcity, AVG(w.weight) AS weight, w.created_at 
                                    FROM waste w 
                                    JOIN userresto ur ON ur.resto_id = w.resto_id 
                                    WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($row2) GROUP BY ur.rcity";  
                                    $query_run = mysqli_query($con, $query);
                                    
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        while($result = mysqli_fetch_array($query_run))
                                        {
                                            $rcity = $result['rcity'];
                                            $weight = $result['weight']; 
                                            $created = date("Y-m-d", strtotime($result['created_at']));    
                                            
                                            $rawcosts_6FL_PC[] = $weight; 
                                            $rcities_6FL_PC[] = $rcity;  
                                            $created_6FL_PC[] = $created;
                                            ?>

                                            ['<?php echo $rcity;?>', <?php echo $weight ;?>],
                                            <?php
                                            
                                        }
                                    }
                                }
                            }
                        }    

                        // FILTER BY DATE 
                        elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                        {
                            $restonames_7FL_PC = array();
                            $rawcosts_7FL_PC = array();     
                            $rcities_7FL_PC = array(); 
                            $restoname_city_7FL_PC = array();
                            $created_7FL_PC = array();
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];

                            if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                            {                              
                                $query = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname, ur.rcity, AVG(w.weight) AS weight, 
                                ur.restoname AS restoname_only, w.created_at 
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id 
                                WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname, ur.rcity";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $restoname = $result['restoname'];
                                        $weight = $result['weight'];   
                                        $rcity = $result['rcity'];      
                                        $restoname_only = $result['restoname_only'];  
                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                        
                                        $restonames_7FL_PC[] = $restoname_only;                                      
                                        $rawcosts_7FL_PC[] = $weight; 
                                        $rcities_7FL_PC[] = $rcity;
                                        $restoname_city_7FL_PC[] = $restoname;  
                                        $created_7FL_PC[] = $created;

                                        ?>      
                                        ['<?php echo $restoname;?>', <?php echo $weight ;?>],  
                                        <?php                 
                                    }    
                                                                                                        
                                }    
                            }
                                                    
                            // FILTER FROM DATE ONLY
                            if(empty($_GET['to_date']) && !empty($_GET['from_date']))
                            {
                                $query = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname, ur.rcity, AVG(w.weight) AS weight, 
                                ur.restoname AS restoname_only, w.created_at 
                                FROM waste w 
                                JOIN userresto ur ON ur.resto_id = w.resto_id 
                                WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname, ur.rcity";
                                $query_run = mysqli_query($con, $query);

                                if(mysqli_num_rows($query_run) > 0)
                                {
                                    while($result = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                                    {
                                        $restoname = $result['restoname'];
                                        $weight = $result['weight'];   
                                        $rcity = $result['rcity'];      
                                        $restoname_only = $result['restoname_only'];  
                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                        
                                        $restonames_7FL_PC[] = $restoname_only;                                      
                                        $rawcosts_7FL_PC[] = $weight; 
                                        $rcities_7FL_PC[] = $rcity;
                                        $restoname_city_7FL_PC[] = $restoname;  
                                        $created_7FL_PC[] = $created;
                                        ?>      
                                        ['<?php echo $restoname;?>', <?php echo $weight ;?>],  
                                        <?php                 
                                    }                                                                                                       
                                }             
                            }     
                        }                     

                        // NULL
                        else
                        {                                      
                            ?>
                            ['<?php echo "null";?>', <?php echo "null" ;?>],
                            <?php          
                            
                        }
           
                    ?>

                    ]);

                    var options = {
                        title: 'Average Weight (Kg) Per Restaurant and/or City',
                        pieSliceText: 'value',
                        sliceVisibilityThreshold: 0,
                        colors: ['#008000', '#0000FF', '#FF0000', '#800080', '#4682B4', '#D2691E', '#808000', '#800000', '#808080', '#FFFF00'],
                        tooltip: {
                            trigger: 'selection',
                            isHtml: true
                        },

                        titleTextStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '16',                           
                        },
                        pieSliceTextStyle: {                         
                            fontSize: '11',
                        },

                        legend: {           
                            position: 'right',
                            alignment: 'center',                
                            textStyle: {
                            color: '#000000',
                            bold: true,
                            fontSize: '14',                            
                            },
                            maxLines: 1,
                        },
                        chartArea: {
                            width: '85%' // increase the chart area width
                        },

                        backgroundColor: {
                            'stroke': 'black',
                            'strokeWidth': 10
                        }
                    };

                    var chart = new google.visualization.PieChart(document.getElementById('piechart'));

                        chart.draw(data, options);

                        var svgElement = document.querySelector('#piechart svg');
                        svgElement.setAttribute('style', 'border-radius: 5px;');

                        document.getElementById('chart-container').innerHTML += '<div class="info-icon"><i class="fa fa-info-circle"></i></div>';
        
                        document.querySelector('.info-icon').addEventListener('click', function() {

                        document.getElementById('myModal').style.display = "block";
                        });

                        document.querySelector('.close').addEventListener('click', function() {
        
                        document.getElementById('myModal').style.display = "none";

                    });                    
                }
        </script>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript"> // COLUMN CHART
            google.charts.load("current", {packages:['corechart']});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([
            ["", "Cost ()"],
                        
                <?php 
                    $data = []; 

                    // FILTER BY RESTO 
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {               
                        $list = implode(',', $checked); //implode() function returns a string from the elements of an array
                        $query = "SELECT w.reason, AVG(w.weight) AS weight 
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($list) GROUP BY w.reason";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $reason = $result['reason'];
                            $weight = $result['weight'];                            

                            ?>

                            ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],                          
                            <?php
                        }                       
                    }

                    //FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $list = implode(',', $checked2); //implode() function returns a string from the elements of an array
                        $query = "SELECT w.reason, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.rcity IN ($list) GROUP BY w.reason";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $reason = $result['reason'];
                            $weight = $result['weight'];                          

                            ?>

                            ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                            <?php
                        }             
                    }

                    // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                    {
                        $list = implode(',', $checked);   
                        $list2 = implode(',', $checked2);                            
                        $query = "SELECT w.reason, AVG(w.weight) AS weight 
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY w.reason";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $reason = $result['reason'];
                            $weight = $result['weight'];                          
                            $data[] = ['reason' => $reason, 'weight' => $weight]; // to make sure visual still show if no data found
                            ?>

                            ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                            <?php
                        }      
                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }    
                        
                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT ur.restoname, ur.resto_id, w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT ur.restoname, ur.resto_id, w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                            {
                                $reason = $row['reason'];
                                $weight = $row['weight'];
                                $data[] = ['reason' => $reason, 'weight' => $weight];   
                                ?>      
                                ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],     
                                <?php                 
                            }                                                                                                           
                        }   

                        if(count($data) == 0) 
                        {
                            echo "['No data', 0]";
                        }
                    }

                    //ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);   
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT ur.restoname, ur.resto_id, w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);   
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT ur.restoname, ur.resto_id, w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $reason = $result['reason'];
                                $weight = $result['weight'];                          
                                $data[] = ['reason' => $reason, 'weight' => $weight];  

                                ?>

                                ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }   

                    //RESTO FILTER & DURATION FILTER
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']))  
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);          
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $reason = $result['reason'];
                                $weight = $result['weight'];                          
                                $data[] = ['reason' => $reason, 'weight' => $weight];  

                                ?>

                                ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }   
                     
                    //CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {                       
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($list2) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        { 
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.reason, AVG(w.weight) AS weight 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($list2) GROUP BY w.reason";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $reason = $result['reason'];
                                $weight = $result['weight'];                          
                                $data[] = ['reason' => $reason, 'weight' => $weight];  

                                ?>

                                ['<?php echo $reason;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    } 
                    
                    else // To show chart when no filter is set              
                    {                                
                        ?>
                        ['<?php echo "";?>', <?php echo 0 ;?>],
                        <?php                        
                    }
                ?>

            ]);

                var view = new google.visualization.DataView(data);
                
                var options = {
                    colors: ['#008000'],
                    title: 'Average Weight (Kg) Based on the Different Factors Leading to Food Wastage',    
                    bar: {groupWidth: "35%"},
                    legend: { position: "none" },        
                    chartArea: {                          
                        backgroundColor: {
                        //fill: '#9CBE8C',
                    }
                    },                   

                    titleTextStyle: {
                        color: '#000000',
                        bold: true,
                        fontSize: '20',
                    },
                    
                    vAxis: {
                        textStyle:{
                            color: '#000000',
                            bold: true,                           
                        },
                    },
                    hAxis: {                           
                        textStyle:{
                            color: '#000000',
                            bold: true,
                            fontSize: 10,                                                             
                        },                          
                        slantedText: true,
                        slantedTextAngle: 25                        
                    },

                    backgroundColor: {
                        //fill: '#9CBE8C',
                        'stroke': 'black', 
                        'strokeWidth': 10,                           
                    },                                    
                };

                    var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
                    chart.draw(view, options);

                    var svgElement = document.querySelector('#columnchart_values svg');
                    svgElement.setAttribute('style', 'border-radius: 5px;');

                    document.getElementById('column-chart-container').innerHTML += '<div class="info-icon-column"><i class="fa fa-info-circle"></i></div>';
      
                    document.querySelector('.info-icon-column').addEventListener('click', function() {

                    document.getElementById('myModal-column-chart').style.display = "block";

                    // Select the close button inside the currently displayed modal
                    const closeBtn = document.querySelector('#myModal-column-chart .close');
                    
                        closeBtn.addEventListener('click', function() {
        
                            document.getElementById('myModal-column-chart').style.display = "none";

                        });
                    });           
                }
        </script> 

        <script type="text/javascript"> // BAR CHART
            google.charts.load("current", {packages:["corechart"]});
            google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ["", "Cost ()"],
              
                <?php 
                    $data = []; 

                    // FILTER BY RESTO 
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {               
                        $list = implode(',', $checked); //implode() function returns a string from the elements of an array
                        $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($list) GROUP BY w.foodtype";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $foodtype = $result['foodtype'];
                            $weight = $result['weight'];       
                            
                            $restonames[] = $restoname; // store all restonames in an array
                            $rawcosts[] = $weight;

                            ?>

                            ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],

                            <?php
                        }  
                    }

                    //FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $list = implode(',', $checked2); //implode() function returns a string from the elements of an array
                        $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.rcity IN ($list) GROUP BY w.foodtype";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $foodtype = $result['foodtype'];
                            $weight = $result['weight'];                          

                            ?>

                            ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],

                            <?php
                        }  
                    }

                    // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                    {
                        $list = implode(',', $checked);   
                        $list2 = implode(',', $checked2);                            
                        $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($list) AND  ur.rcity IN ($list2) GROUP BY w.foodtype";
                        $query_run = mysqli_query($con, $query);
                        
                        while($result = mysqli_fetch_array($query_run))
                        {
                            $foodtype = $result['foodtype'];
                            $weight = $result['weight'];                          
                            $data[] = ['foodtype' => $foodtype, 'weight' => $weight]; // to make sure visual still show if no data found
                            ?>

                            ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                            <?php
                        }      
                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                        
                    }    
                        
                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']) && !empty($_GET['from_date'])) 
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT ur.restoname, ur.resto_id, w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];
                            $query = "SELECT ur.restoname, ur.resto_id, w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($row = mysqli_fetch_array($query_run)) //foreach($query_run as $row)
                            {
                                $foodtype = $row['foodtype'];
                                $weight = $row['weight'];
                                $data[] = ['foodtype' => $foodtype, 'weight' => $weight];   
                                ?>      
                                ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],     
                                <?php                 
                            }                                                                                                           
                        }   

                        if(count($data) == 0) 
                        {
                            echo "['No data', 0]";
                        }
                    }

                    //ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);   
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND  ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);   
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND  ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND NOW() GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $foodtype = $result['foodtype'];
                                $weight = $result['weight'];                          
                                $data[] = ['foodtype' => $foodtype, 'weight' => $weight];  

                                ?>

                                ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }   

                    //RESTO FILTER & DURATION FILTER
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))  
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);          
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND w.created_at BETWEEN '$from_date' AND NOW() GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $foodtype = $result['foodtype'];
                                $weight = $result['weight'];                          
                                $data[] = ['foodtype' => $foodtype, 'weight' => $weight];  

                                ?>

                                ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    }   
                    
                    //CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                       
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        { 
                            $list2 = implode(',', $checked2);         
                            $from_date = $_GET['from_date'];
                            $to_date = $_GET['to_date'];      
                            $query = "SELECT w.foodtype, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND NOW() GROUP BY w.foodtype";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        if(mysqli_num_rows($query_run) > 0)
                        {
                            while($result = mysqli_fetch_array($query_run))
                            {
                                $foodtype = $result['foodtype'];
                                $weight = $result['weight'];                          
                                $data[] = ['foodtype' => $foodtype, 'weight' => $weight];  

                                ?>

                                ['<?php echo $foodtype;?>', <?php echo number_format($weight, 2, '.', ''); ?>],    
                                <?php
                                
                            }
                        }
                                           
                        if(count($data) < 1) 
                        {
                            echo "['No data', 0]";
                        }
                    } 

                    else                   
                    {                                
                        ?>
                        ['<?php echo "";?>', <?php echo 0 ;?>],
                        <?php                        
                    }
                ?>
            ]);

            var view = new google.visualization.DataView(data);

            var options = {
                title: "Average Weight (Kg) Based on Type of Food",
                colors: ['#008000'],
                bar: {groupWidth: "35%"},
                legend: { position: "none" },

                titleTextStyle: {
                        color: '#000000',
                        bold: true,
                        fontSize: '20',
                    },
                    titlePosition: 'center',
                    vAxis: {
                        textStyle:{
                            color: '#000000',
                            bold: true,  
                            fontSize: 15,                         
                        },
                    },
                    hAxis: {                           
                        textStyle:{
                            color: '#000000',
                            bold: true,
                            fontSize: 10,                                                             
                        },                                                 
                    },

                    backgroundColor: {                   
                        'stroke': 'black',
                        'strokeWidth': 10,                           
                    },    
            };
            var chart = new google.visualization.BarChart(document.getElementById("barchart_values"));
            chart.draw(view, options);

            var svgElement = document.querySelector('#barchart_values svg');
            svgElement.setAttribute('style', 'border-radius: 5px;');

            document.getElementById('bar-chart-container').innerHTML += '<div class="info-icon-bar"><i class="fa fa-info-circle"></i></div>';
      
            document.querySelector('.info-icon-bar').addEventListener('click', function() {

            document.getElementById('myModal-bar-chart').style.display = "block";

                // Select the close button inside the currently displayed modal
                const closeBtn = document.querySelector('#myModal-bar-chart .close');
                
                    closeBtn.addEventListener('click', function() {

                        document.getElementById('myModal-bar-chart').style.display = "none";

                    });
                });          
            }
        </script>

        <div id="line_title">Average Weight (Kg) Per Month </div>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <script type="text/javascript">  // LINE CHART
            google.charts.load('current', {'packages': ['line']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Month');
                data.addColumn('number', 'Weight ');

                <?php
                    $data = [];

                    // FILTER BY RESTO 
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $list = implode(',', $checked);
                        $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id 
                                    WHERE ur.restoname IN ($list) GROUP BY month
                                    ORDER BY month ASC";
                        $query_run = mysqli_query($con, $query);

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];
                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    // FILTER BY CTIY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $list = implode(',', $checked2);
                        $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id 
                                    WHERE ur.rcity IN ($list) GROUP BY month
                                    ORDER BY month ASC";
                        $query_run = mysqli_query($con, $query);

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    // FILTER BY RESTO & CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                    {
                        $list = implode(',', $checked);
                        $list2 = implode(',', $checked2);
                        $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                                    FROM waste w
                                    JOIN userresto ur ON ur.resto_id = w.resto_id 
                                    WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY month
                                    ORDER BY month ASC";
                        $query_run = mysqli_query($con, $query);

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']) && !empty($_GET['from_date'])) 
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date'
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    //ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {
                        if(isset($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);
                            $list2 = implode(',', $checked2);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);
                            $list2 = implode(',', $checked2);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND NOW()
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }
                        
                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }

                    }

                    //RESTO FILTER & DURATION FILTER
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))  
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND w.created_at BETWEEN '$from_date' AND '$to_date'
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        
                        if(empty($_GET['to_date'])) 
                        {
                            $list = implode(',', $checked);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($list) AND w.created_at BETWEEN '$from_date' AND NOW()
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            $restonames[] = $month; // store all months in an array
                            $rcities[] = $month;
                            $weights[] = $weight;
                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    //CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {
                        if(isset($_GET['to_date']) && !empty($_GET['to_date'])) 
                        {
                            $list2 = implode(',', $checked2);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        
                        if(empty($_GET['to_date'])) 
                        {
                            $list2 = implode(',', $checked2);
                            $query = "SELECT DATE_FORMAT(w.created_at, '%Y-%m') AS month, AVG(w.weight) AS weight 
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($list2) AND w.created_at BETWEEN '$from_date' AND NOW()
                            GROUP BY month
                            ORDER BY month ASC";
                            $query_run = mysqli_query($con, $query);
                        }

                        while ($result = mysqli_fetch_array($query_run)) {
                            $month = $result['month'];
                            $weight = $result['weight'];

                            ?>
                            data.addRow([
                                '<?php echo date("Y", strtotime($month)) . " " . date("M", strtotime($month)); ?>',
                                <?php echo number_format($weight, 2, '.', ''); ?>
                            ]);
                            <?php
                        }
                    }

                    else
                    {                                
                        ?>
                        data.addRow([
                            '',
                            0
                        ]);
                        <?php                        
                    }

                ?>

                var options = {
                    chart: {
                        title: '.',
                    },
                    titleTextStyle: {
                        color: '#FFFFFF',
                        bold: true,
                        fontSize: 21,
                        },
                    legend: {
                        position: 'right',
                        alignment: 'top',
                        textStyle: {
                        color: '#000000',
                        fontSize: '15',                                                  
                        },
                    },
                    vAxis: {
                        textStyle: {
                        color: '#000000',
                        fontSize: 14,
                        },
                    },
                    hAxis: {
                        title: '.',
                        textStyle: {
                        color: '#000000',
                        fontSize: 14,
                        },
                    },
                    width: 1200,
                    height: 550,
                };

                var chart = new google.charts.Line(document.getElementById('linechart_values'));
                chart.draw(data, google.charts.Line.convertOptions(options));

                document.getElementById('line-chart-container').innerHTML += '<div class="info-icon-line"><i class="fa fa-info-circle"></i></div>';
      
                document.querySelector('.info-icon-line').addEventListener('click', function() {

                document.getElementById('myModal-line-chart').style.display = "block";

                    // Select the close button inside the currently displayed modal
                    const closeBtn = document.querySelector('#myModal-line-chart .close');
                    
                        closeBtn.addEventListener('click', function() {

                        document.getElementById('myModal-line-chart').style.display = "none";

                        });
                    });          
            }
        </script>

    </div>
    
    <!-- VS CARDS -->  
    <div id="vscard2" class="card">
        <div class="card-header" style="font-size:150%;"><b><center>Total Weight of Food Wasted</b></center>
            <div class="info-icon-vscard2">
                <i class="fa fa-info-circle" data-toggle="modal" data-target="#infoModal-vscard2"></i>
            </div>
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 2
                        
                    // FILTER BY RESTO 
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))    
                    {
                        $card_list = implode(',', $checked);
                        $query = "SELECT SUM(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($card_list)";
                        $query_run = mysqli_query($con, $query);
                        
                        $total_rawcost = 0;
                        while ($result = mysqli_fetch_array($query_run)) {
                            $weight = $result['weight'];                          
                            
                            // Add the weight of the current restaurant to the total weight
                            $total_rawcost += $weight;

                        }                      
                        // Output the total weight for the selected restaurants
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg';
                    }
                    
                    //FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $card_list2 = implode(',', $checked2);
                        $query = "SELECT SUM(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.rcity IN ($card_list2)";
                        $query_run = mysqli_query($con, $query);                  
                        
                        $total_rawcost = 0;
                        while ($result = mysqli_fetch_array($query_run)) {
                            $weight = $result['weight'];                          
                            
                            $total_rawcost += $weight;

                        }                      
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg';                           
                    }

                    // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                    {
                        $card_list = implode(',', $checked);       
                        $card_list2 = implode(',', $checked2);                            
                        $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                        FROM waste w 
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2)";
                        $query_run = mysqli_query($con, $query);
                        
                        $total_rawcost = 0;
                        while ($result = mysqli_fetch_array($query_run)) {
                            $weight = $result['weight'];                          
                            
                            $total_rawcost += $weight;

                        }                      
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg';          
                    }                                                 

                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }          
                        }                                    

                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);

                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;

                            }       
                        }
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg'; 
                    }

                    // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {                            
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       
                        $card_list2 = implode(',', $checked2);  

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                             
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                           
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg'; 
                    }  
                    
                    // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']) ) 
                    {
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                             
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                           
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg'; 
                    }   

                    // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                       
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];        
                        $card_list2 = implode(',', $checked2);  

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                             
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT SUM(w.weight) AS weight, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $total_rawcost = 0;
                            while ($result = mysqli_fetch_array($query_run)) {
                                $weight = $result['weight'];                          
                                
                                $total_rawcost += $weight;
                            }                           
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($total_rawcost, 2, '.', ',') . ' Kg';
                    }                                                

                ?>
            </div>                    
    </div>

    <div id="vscard3" class="card">
        <div class="card-header" style="font-size:120%;"><b><center>Average Weight of Food Wasted</b></center>
            <div class="info-icon-vscard3">
                <i class="fa fa-info-circle" data-toggle="modal" data-target="#infoModal-vscard3"></i>
            </div>
        </div>
            <div class="card-body text-dark">            
                <?php //VS CARD 3
                        
                    // FILTER BY RESTO 
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))    
                    {
                        $card_list = implode(',', $checked);
                        $query = "SELECT AVG(w.weight) AS avg_rawcost 
                        FROM waste w 
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($card_list)";
                        $query_run = mysqli_query($con, $query);

                        $result = mysqli_fetch_assoc($query_run);
                        $avg_rawcost = $result['avg_rawcost'];

                        // Output the overall average weight for all the selected restaurants
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>';
                    }
         
                    
                    //FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $card_list2 = implode(',', $checked2);
                        $query = "SELECT AVG(w.weight) AS avg_rawcost 
                        FROM waste w 
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.rcity IN ($card_list2)";
                        $query_run = mysqli_query($con, $query);                  
                        
                        $result = mysqli_fetch_assoc($query_run);
                        $avg_rawcost = $result['avg_rawcost'];
  
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>';                 
                    }

                    // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))
                    {
                        $card_list = implode(',', $checked);       
                        $card_list2 = implode(',', $checked2);                            
                        $query = "SELECT AVG(w.weight) AS avg_rawcost, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                        FROM waste w 
                        JOIN userresto ur ON ur.resto_id = w.resto_id 
                        WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) ";
                        $query_run = mysqli_query($con, $query);
                        
                        $result = mysqli_fetch_assoc($query_run);
                        $avg_rawcost = $result['avg_rawcost'];
  
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>';            
                    }                                                 

                    // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                          
                            $query = "SELECT AVG(w.weight) AS avg_rawcost, ur.restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);

                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];        
                        }                                    

                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY
                        {
                            $query = "SELECT AVG(w.weight) AS avg_rawcost, ur.restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);

                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];     
                        }
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>';   
                    }

                    // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {                            
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       
                        $card_list2 = implode(',', $checked2);  

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS avg_rawcost, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                              
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT AVG(w.weight) AS avg_rawcost, CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname 
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                         
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>'; 
                    }  
                    
                    // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']) ) 
                    {
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];     
                        $card_list = implode(',', $checked);       

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS avg_rawcost
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                                 
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT AVG(w.weight) AS avg_rawcost
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.restoname IN ($card_list) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                               
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>'; 
                    }   

                    // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                       
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];        
                        $card_list2 = implode(',', $checked2);  

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS avg_rawcost
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND '$to_date'";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                                
                        }
                        if(empty($_GET['to_date'])) // FILTER FROM DATE ONLY// NO TO DATE FILTER
                        {                                    
                            $query = "SELECT AVG(w.weight) AS avg_rawcost
                            FROM waste w 
                            JOIN userresto ur ON ur.resto_id = w.resto_id 
                            WHERE ur.rcity IN ($card_list2) AND w.created_at BETWEEN '$from_date' AND NOW()";
                            $query_run = mysqli_query($con, $query);
                            
                            $result = mysqli_fetch_assoc($query_run);
                            $avg_rawcost = $result['avg_rawcost'];                              
                        }  
                        echo '<h4 class="mb-0 text-center">' . number_format($avg_rawcost, 2, '.', ',') . ' Kg</h4>';
                    }                                                

                ?>
            </div>                    
    </div>
    
    <!-- VISUALS & MODALS--> 
    <div class="visuals">

        <!-- MODALS -->             
        <?php
            // PIE CHART MODAL (POP UP)

                // FILTER BY RESTO
                    if (isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $query = "SELECT ur.restoname, AVG(w.weight) AS weight
                                FROM waste w
                                JOIN userresto ur ON ur.resto_id = w.resto_id
                                WHERE ur.restoname IN ($card_list)
                                GROUP BY ur.restoname
                                ORDER BY AVG(w.weight) DESC"; // Fixed the order by clause
                        $query_run = mysqli_query($con, $query);
                    
                        ?>
                        <div id="myModal" class="modal">
                            <div class="modal-content">
                                <span class="close">&times;</span>
                                <div class="modal-body">
                                    <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                    <table style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurant</th>
                                                <th>Weight</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php 
                                            while ($result = mysqli_fetch_array($query_run)) {
                                                $weight = $result['weight'];                          
                                                $restoname = $result['restoname'];  
                                                echo '<tr>
                                                        <td>' . $restoname . '</td>
                                                        <td>' . "" . number_format($weight, 2) . '</td>
                                                    </tr>'; 
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                    <hr>
                                    <?php
                                    // Retrieve the data again for further calculations
                                    $query_run = mysqli_query($con, $query);
                                    $restonames = array();
                                    $rawcosts = array();
                                    while ($result = mysqli_fetch_array($query_run)) {
                                        $rawcosts[] = $result['weight'];
                                        $restonames[] = $result['restoname'];  
                                    }
                    
                                    if (count($restonames) == 2) {
                                        $difference_second_highest = $rawcosts[0] - $rawcosts[1];
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restonames[0] . " spends more money on labor and materials needed to make their food as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restonames[1] . ".</p>";
                                        }
                                    }
                    
                                    if (count($restonames) > 2) {
                                        $difference_lowest = $rawcosts[0] - $rawcosts[count($rawcosts) - 1];
                                        $difference_second_highest = $rawcosts[0] - $rawcosts[1]; 
                    
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restonames[0] . " spends the most money on labor and materials needed to make their food as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restonames[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restonames[count($restonames) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                
                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>City</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts, SORT_DESC, $rcities);

                                            // Loop through the sorted arrays and print the cities and rawcosts in a table
                                            for ($i = 0; $i < count($rcities); $i++) { ?>
                                                <tr>
                                                <td><?php echo $rcities[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rcities) == 2) {
                                        
                                        $difference_second_highest = $rawcosts[0] - $rawcosts[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $rcities[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcities[1] . ".</p>";
                                        }
                                    }

                                    if (count($rcities) > 2) {
                                        
                                        $difference_lowest = $rawcosts[0] - $rawcosts[count($rawcosts) - 1];                                       
                                        $difference_second_highest = $rawcosts[0] - $rawcosts[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $rcities[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcities[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcities[count($rcities) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {   
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants and Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurants</th>
                                                <th>City</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_3FL_PC, SORT_DESC, $restonames_3FL_PC, $rcities_3FL_PC, $restoname_city_3FL_PC);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($restonames_3FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restonames_3FL_PC[$i]; ?></td>
                                                <td><?php echo $rcities_3FL_PC[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts_3FL_PC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($restonames_3FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_3FL_PC[0] - $rawcosts_3FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_3FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restonames_3FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_3FL_PC[0] - $rawcosts_3FL_PC[count($rawcosts_3FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_3FL_PC[0] - $rawcosts_3FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restoname_city_3FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_PC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_3FL_PC[count($restoname_city_3FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }
               
                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants and Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurants</th>
                                                <th>City</th>
                                                <th>Average Weight (Kg)</th>
                                                <th>Date Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_4FL_PC, SORT_DESC, $restonames_4FL_PC, $rcities_4FL_PC, $restoname_city_4FL_PC, $created_4FL_PC,);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($restonames_4FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restonames_4FL_PC[$i]; ?></td>
                                                <td><?php echo $rcities_4FL_PC[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts_4FL_PC[$i], 2, '.', ','); ?></td>
                                                <td><?php echo $created_4FL_PC[$i]; ?></td> 
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rawcosts_4FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_4FL_PC[0] - $rawcosts_4FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_4FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restonames_4FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_4FL_PC[0] - $rawcosts_4FL_PC[count($rawcosts_4FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_4FL_PC[0] - $rawcosts_4FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restoname_city_4FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_PC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_4FL_PC[count($restoname_city_4FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php                 
                    }   

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurants</th>
                                                <th>Average Weight (Kg)</th>
                                                <th>Date Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_5FL_PC, SORT_DESC, $restonames_5FL_PC, $created_5FL_PC,);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($restonames_5FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restonames_5FL_PC[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts_5FL_PC[$i], 2, '.', ','); ?></td>
                                                <td><?php echo $created_5FL_PC[$i]; ?></td> 
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rawcosts_5FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_5FL_PC[0] - $rawcosts_5FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restonames_5FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restonames_5FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restonames_5FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_5FL_PC[0] - $rawcosts_5FL_PC[count($rawcosts_5FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_5FL_PC[0] - $rawcosts_5FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restonames_5FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restonames_5FL_PC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restonames_5FL_PC[count($restonames_5FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php    
                    }   

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date']))
                    {                       
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>City</th>
                                                <th>Average Weight (Kg)</th>
                                                <th>Date Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_6FL_PC, SORT_DESC, $rcities_6FL_PC, $created_6FL_PC,);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($rcities_6FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $rcities_6FL_PC[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts_6FL_PC[$i], 2, '.', ','); ?></td>
                                                <td><?php echo $created_6FL_PC[$i]; ?></td> 
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rawcosts_6FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_6FL_PC[0] - $rawcosts_6FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $rcities_6FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcities_6FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($rcities_6FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_6FL_PC[0] - $rawcosts_6FL_PC[count($rawcosts_6FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_6FL_PC[0] - $rawcosts_6FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $rcities_6FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcities_6FL_PC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcities_6FL_PC[count($rcities_6FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php    
                    }      

                // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && isset($_GET['to_date'])) 
                    {
                        ?>
                            <div id="myModal" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants and Cities Selected: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurants</th>
                                                <th>City</th>
                                                <th>Average Weight (Kg)</th>
                                                <th>Date Created</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                        
                                            array_multisort($rawcosts_7FL_PC, SORT_DESC, $restonames_7FL_PC, $rcities_7FL_PC, $restoname_city_7FL_PC, $created_7FL_PC,);

                                            // Loop through the sorted arrays and print the restos and rawcosts in a table
                                            for ($i = 0; $i < count($restonames_7FL_PC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restonames_7FL_PC[$i]; ?></td>
                                                <td><?php echo $rcities_7FL_PC[$i]; ?></td>
                                                <td><?php echo number_format($rawcosts_7FL_PC[$i], 2, '.', ','); ?></td>
                                                <td><?php echo $created_7FL_PC[$i]; ?></td> 
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php

                                    if (count($rawcosts_7FL_PC) == 2) {
                                        
                                        $difference_second_highest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[1];
                                       
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_7FL_PC[0] . " spends more money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restonames_7FL_PC) > 2) {
                                        
                                        $difference_lowest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[count($rawcosts_7FL_PC) - 1];                                       
                                        $difference_second_highest = $rawcosts_7FL_PC[0] - $rawcosts_7FL_PC[1]; 
                                        
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {                                          
                                            echo "<p>" . $restoname_city_7FL_PC[0] . " spends the most money on labor and materials needed to make their food as they spend an average of
                                            " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_7FL_PC[count($restoname_city_7FL_PC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php  
                    }

            // COLUMN CHART MODAL    
            
                // FILTER BY RESTO
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $restoname_1FL_CC = array();
                        $reason_1FL_CC = array();
                        $rawcost_1FL_CC = array();

                        $query_CC_modal = "SELECT ur.restoname, AVG(w.weight) AS avg_rawcost, w.reason
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($list) GROUP BY ur.restoname, w.reason";

                        $query_run_CC_modal = mysqli_query($con, $query_CC_modal);

                        if(mysqli_num_rows($query_run_CC_modal) > 0)
                        {
                            while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                            {
                                $restoname = $row_CC['restoname']; 
                                $reason = $row_CC['reason'];
                                $weight = $row_CC['avg_rawcost'];  
                                
                                $restoname_1FL_CC[] = $restoname;
                                $reason_1FL_CC[] = $reason; 
                                $rawcost_1FL_CC[] = $weight;                                         
                            }          
                                        
                        }              
                        
                        ?>
                            <div id="myModal-column-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurant</th>
                                                <th>Reason</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_1FL_CC, SORT_DESC, $restoname_1FL_CC, $reason_1FL_CC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($restoname_1FL_CC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restoname_1FL_CC[$i]; ?></td>
                                                <td><?php echo $reason_1FL_CC[$i]; ?></td>
                                                <td><?php echo number_format($rawcost_1FL_CC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($restoname_1FL_CC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_1FL_CC[0] - $rawcost_1FL_CC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_1FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_1FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_1FL_CC[1] . " with " . $reason_1FL_CC[1] .".</p>";
                                        }
                                    }

                                    if (count($restoname_1FL_CC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_1FL_CC[0] - $rawcost_1FL_CC[count($rawcost_1FL_CC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_1FL_CC[0] - $rawcost_1FL_CC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                            echo "<p>" . $restoname_1FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_1FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_1FL_CC[1] . " with " . $reason_1FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_1FL_CC[count($restoname_1FL_CC) - 1] . " with " . $reason_1FL_CC[count($reason_1FL_CC) - 1] ." (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }

                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $rcity_2FL_CC = array();
                        $reason_2FL_CC = array();
                        $rawcost_2FL_CC = array();
                        
                        $query_CC_modal = "SELECT ur.rcity, w.reason, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.rcity IN ($list) GROUP BY ur.rcity, w.reason";

                        $query_run_CC_modal = mysqli_query($con, $query_CC_modal);

                        if(mysqli_num_rows($query_run_CC_modal) > 0)
                        {
                            while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                            {
                                $rcity = $row_CC['rcity']; 
                                $reason = $row_CC['reason'];
                                $weight = $row_CC['weight'];  
                                
                                $rcity_2FL_CC[] = $rcity;
                                $reason_2FL_CC[] = $reason; 
                                $rawcost_2FL_CC[] = $weight;                                         
                            }                                            
                        }                              
                        ?>
                            <div id="myModal-column-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>City selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>City</th>
                                                <th>Reason</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_2FL_CC, SORT_DESC, $rcity_2FL_CC, $reason_2FL_CC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($rcity_2FL_CC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $rcity_2FL_CC[$i]; ?></td>
                                                <td><?php echo $reason_2FL_CC[$i]; ?></td>
                                                <td><?php echo number_format($rawcost_2FL_CC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($rcity_2FL_CC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_2FL_CC[0] - $rawcost_2FL_CC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $rcity_2FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_2FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " .  $rcity_2FL_CC[1] . " with " . $reason_2FL_CC[1] .".</p>";
                                        }
                                    }

                                    if (count($rcity_2FL_CC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_2FL_CC[0] - $rawcost_2FL_CC[count($rawcost_2FL_CC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_2FL_CC[0] - $rawcost_2FL_CC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                            echo "<p>" .$rcity_2FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_2FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_2FL_CC[1] . " with " . $reason_2FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_2FL_CC[count($rcity_2FL_CC) - 1] . " with " . $reason_2FL_CC[count($reason_2FL_CC) - 1] ." (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {   
                        $restoname_3FL_CC = array();
                        $reason_3FL_CC = array();
                        $rawcost_3FL_CC = array();
                        $restoname_city_3FL_CC = array();
                        $rcity_3FL_CC = array();

                        $query_CC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.reason, ur.rcity, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.reason";

                        $query_run_CC_modal = mysqli_query($con, $query_CC_modal);

                        if(mysqli_num_rows($query_run_CC_modal) > 0)
                        {
                            while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                            {
                                $restoname = $row_CC['restoname']; 
                                $reason = $row_CC['reason'];
                                $weight = $row_CC['weight'];
                                $restoname_city = $row_CC['restoname_city'];
                                $rcity = $row_CC['rcity'];
                                
                                $restoname_3FL_CC[] = $restoname;
                                $reason_3FL_CC[] = $reason;
                                $rawcost_3FL_CC[] = $weight;
                                $restoname_city_3FL_CC[] = $restoname_city;
                                $rcity_3FL_CC[] = $rcity;                                      
                            }                                          
                        }              
                        
                        ?>
                            <div id="myModal-column-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurant</th>
                                                <th>City</th>
                                                <th>Reason</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_3FL_CC, SORT_DESC, $restoname_3FL_CC, $reason_3FL_CC, $restoname_city_3FL_CC, $rcity_3FL_CC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($restoname_3FL_CC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restoname_3FL_CC[$i]; ?></td>   
                                                <td><?php echo $rcity_3FL_CC[$i]; ?></td>
                                                <td><?php echo $reason_3FL_CC[$i]; ?></td>

                                                <td><?php echo number_format($rawcost_3FL_CC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($restoname_3FL_CC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_3FL_CC[0] - $rawcost_3FL_CC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_3FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_3FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_CC[1] . " with " . $reason_3FL_CC[1] . ".</p>";

                                        }
                                    }

                                    if (count($restoname_3FL_CC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_3FL_CC[0] - $rawcost_3FL_CC[count($rawcost_3FL_CC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_3FL_CC[0] - $rawcost_3FL_CC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                            echo "<p>" . $restoname_city_3FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_3FL_CC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_CC[1] . " with " . $reason_3FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_3FL_CC[count($restoname_city_3FL_CC) - 1] . " with " . $reason_3FL_CC[count($reason_3FL_CC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }
        
                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {

                        $restoname_4FL_CC = array();
                        $reason_4FL_CC = array();
                        $rawcost_4FL_CC = array();
                        $restoname_city_4FL_CC = array();
                        $rcity_4FL_CC = array();
                        $created_4FL_CC = array();  

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.reason, ur.rcity, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_4FL_CC[] = $restoname;
                                    $reason_4FL_CC[] = $reason;
                                    $rawcost_4FL_CC[] = $weight;
                                    $restoname_city_4FL_CC[] = $restoname_city;
                                    $rcity_4FL_CC[] = $rcity;   
                                    $created_4FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_4FL_CC, SORT_DESC, $restoname_4FL_CC, $reason_4FL_CC, $restoname_city_4FL_CC, $rcity_4FL_CC, $created_4FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_4FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_4FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_4FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_4FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_4FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_4FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_4FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_city_4FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_4FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[1] . " with " . $reason_4FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_4FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[count($rawcost_4FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_city_4FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_4FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[1] . " with " . $reason_4FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[count($restoname_city_4FL_CC) - 1] . " with " . $reason_4FL_CC[count($reason_4FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if (empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.reason, ur.rcity, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_4FL_CC[] = $restoname;
                                    $reason_4FL_CC[] = $reason;
                                    $rawcost_4FL_CC[] = $weight;
                                    $restoname_city_4FL_CC[] = $restoname_city;
                                    $rcity_4FL_CC[] = $rcity;   
                                    $created_4FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_4FL_CC, SORT_DESC, $restoname_4FL_CC, $reason_4FL_CC, $restoname_city_4FL_CC, $rcity_4FL_CC, $created_4FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_4FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_4FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_4FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_4FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_4FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_4FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_4FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_city_4FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_4FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[1] . " with " . $reason_4FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_4FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[count($rawcost_4FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_CC[0] - $rawcost_4FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_city_4FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_4FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[1] . " with " . $reason_4FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_4FL_CC[count($restoname_city_4FL_CC) - 1] . " with " . $reason_4FL_CC[count($reason_4FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }   

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                    {
                        $restoname_5FL_CC = array();
                        $reason_5FL_CC = array();
                        $rawcost_5FL_CC = array();
                        $restoname_city_5FL_CC = array();
                        $rcity_5FL_CC = array();
                        $created_5FL_CC = array();

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query_CC_modal = "SELECT ur.restoname, w.reason, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_5FL_CC[] = $restoname;
                                    $reason_5FL_CC[] = $reason;
                                    $rawcost_5FL_CC[] = $weight;  
                                    $created_5FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_5FL_CC, SORT_DESC, $restoname_5FL_CC, $reason_5FL_CC, $restoname_5FL_CC, $created_5FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_5FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_5FL_CC[$i]; ?></td>   
                                                    <td><?php echo $reason_5FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_5FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_5FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_5FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_5FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_5FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_CC[1] . " with " . $reason_5FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_5FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[count($rawcost_5FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_5FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_5FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_CC[1] . " with " . $reason_5FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_5FL_CC[count($restoname_5FL_CC) - 1] . " with " . $reason_5FL_CC[count($reason_5FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                        
                        if (empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT ur.restoname, w.reason, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_5FL_CC[] = $restoname;
                                    $reason_5FL_CC[] = $reason;
                                    $rawcost_5FL_CC[] = $weight;  
                                    $created_5FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_5FL_CC, SORT_DESC, $restoname_5FL_CC, $reason_5FL_CC, $restoname_5FL_CC, $created_5FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_5FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_5FL_CC[$i]; ?></td>   
                                                    <td><?php echo $reason_5FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_5FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_5FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_5FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_5FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_5FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_CC[1] . " with " . $reason_5FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_5FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[count($rawcost_5FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_CC[0] - $rawcost_5FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_5FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_5FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_CC[1] . " with " . $reason_5FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_5FL_CC[count($restoname_5FL_CC) - 1] . " with " . $reason_5FL_CC[count($reason_5FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }   

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {                       
                        $reason_6FL_CC = array();
                        $rawcost_6FL_CC = array();
                        $rcity_6FL_CC = array();
                        $created_6FL_CC = array();

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query_CC_modal = "SELECT ur.rcity, w.reason, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $rcity = $row_CC['rcity']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $rcity_6FL_CC[] = $rcity;
                                    $reason_6FL_CC[] = $reason;
                                    $rawcost_6FL_CC[] = $weight;  
                                    $created_6FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>City selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_6FL_CC, SORT_DESC, $rcity_6FL_CC, $reason_6FL_CC, $rcity_6FL_CC, $created_6FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($rcity_6FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $rcity_6FL_CC[$i]; ?></td>   
                                                    <td><?php echo $reason_6FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_6FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_6FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($rcity_6FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $rcity_6FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_6FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_CC[1] . " with " . $reason_6FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($rcity_6FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[count($rawcost_6FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $rcity_6FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_6FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_CC[1] . " with " . $reason_6FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_6FL_CC[count($rcity_6FL_CC) - 1] . " with " . $reason_6FL_CC[count($reason_6FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                        
                        if (empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT ur.rcity, w.reason, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $rcity = $row_CC['rcity']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $rcity_6FL_CC[] = $rcity;
                                    $reason_6FL_CC[] = $reason;
                                    $rawcost_6FL_CC[] = $weight;  
                                    $created_6FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>City selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_6FL_CC, SORT_DESC, $rcity_6FL_CC, $reason_6FL_CC, $rcity_6FL_CC, $created_6FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($rcity_6FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $rcity_6FL_CC[$i]; ?></td>   
                                                    <td><?php echo $reason_6FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_6FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_6FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($rcity_6FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $rcity_6FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_6FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_CC[1] . " with " . $reason_6FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($rcity_6FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[count($rawcost_6FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_CC[0] - $rawcost_6FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $rcity_6FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_6FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_CC[1] . " with " . $reason_6FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_6FL_CC[count($rcity_6FL_CC) - 1] . " with " . $reason_6FL_CC[count($reason_6FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }      

                // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                    {
                        $restoname_7FL_CC = array();
                        $reason_7FL_CC = array();
                        $rawcost_7FL_CC = array();
                        $restoname_city_7FL_CC = array();
                        $rcity_7FL_CC = array();
                        $created_7FL_CC = array(); 

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.reason, ur.rcity, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_7FL_CC[] = $restoname;
                                    $reason_7FL_CC[] = $reason;
                                    $rawcost_7FL_CC[] = $weight;
                                    $restoname_city_7FL_CC[] = $restoname_city;
                                    $rcity_7FL_CC[] = $rcity;   
                                    $created_7FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_CC, SORT_DESC, $restoname_7FL_CC, $reason_7FL_CC, $restoname_city_7FL_CC, $rcity_7FL_CC, $created_7FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_7FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_7FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[count($rawcost_7FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_CC[count($restoname_7FL_CC) - 1] . " with " . $reason_7FL_CC[count($reason_7FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if (empty($_GET['to_date']))
                        {                           
                            $query_CC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.reason, ur.rcity, AVG(w.weight) AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname, w.reason";

                            $query_run_CC_modal = mysqli_query($con, $query_CC_modal);
                        
                            if(mysqli_num_rows($query_run_CC_modal) > 0)
                            {
                                while($row_CC = mysqli_fetch_array($query_run_CC_modal)) 
                                {
                                    $restoname = $row_CC['restoname']; 
                                    $reason = $row_CC['reason'];
                                    $weight = $row_CC['weight'];
                                    $restoname_city = $row_CC['restoname_city'];
                                    $rcity = $row_CC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_CC['created_at']));
                                    
                                    $restoname_7FL_CC[] = $restoname;
                                    $reason_7FL_CC[] = $reason;
                                    $rawcost_7FL_CC[] = $weight;
                                    $restoname_city_7FL_CC[] = $restoname_city;
                                    $rcity_7FL_CC[] = $rcity;   
                                    $created_7FL_CC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-column-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on reason: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_CC, SORT_DESC, $restoname_7FL_CC, $reason_7FL_CC, $restoname_city_7FL_CC, $rcity_7FL_CC, $created_7FL_CC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_CC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_CC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_CC[$i]; ?></td>
                                                    <td><?php echo $reason_7FL_CC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_7FL_CC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_CC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_CC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_CC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[count($rawcost_7FL_CC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_CC[0] - $rawcost_7FL_CC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_CC[0] . " spends more money based on factors of food wastage: " . $reason_7FL_CC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_CC[1] . " with " . $reason_7FL_CC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_CC[count($restoname_7FL_CC) - 1] . " with " . $reason_7FL_CC[count($reason_7FL_CC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        } 
                    }

            // BAR CHART MODAL

                // FILTER BY RESTO
                    if(isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $restoname_1FL_BC = array();
                        $foodtype_1FL_BC = array();
                        $rawcost_1FL_BC = array();

                        $query_BC_modal = "SELECT ur.restoname, AVG(w.weight) AS weight, w.foodtype
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($list) GROUP BY ur.restoname, w.foodtype";

                        $query_run_BC_modal = mysqli_query($con, $query_BC_modal);

                        if(mysqli_num_rows($query_run_BC_modal) > 0)
                        {
                            while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                            {
                                $restoname = $row_BC['restoname']; 
                                $foodtype = $row_BC['foodtype'];
                                $weight = $row_BC['weight'];  
                                
                                $restoname_1FL_BC[] = $restoname;
                                $foodtype_1FL_BC[] = $foodtype; 
                                $rawcost_1FL_BC[] = $weight;                                         
                            }          
                                        
                        }              
                        
                        ?>
                            <div id="myModal-bar-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurant</th>
                                                <th>Food Type</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_1FL_BC, SORT_DESC, $restoname_1FL_BC, $foodtype_1FL_BC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($restoname_1FL_BC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restoname_1FL_BC[$i]; ?></td>
                                                <td><?php echo $foodtype_1FL_BC[$i]; ?></td>
                                                <td><?php echo number_format($rawcost_1FL_BC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($restoname_1FL_BC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_1FL_BC[0] - $rawcost_1FL_BC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_1FL_BC[0] . " spends more money based on the food type: " . $foodtype_1FL_BC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_1FL_BC[1] . " with " . $foodtype_1FL_BC[1] . ".</p>";
                                        }
                                    }

                                    if (count($restoname_1FL_BC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_1FL_BC[0] - $rawcost_1FL_BC[count($rawcost_1FL_BC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_1FL_BC[0] - $rawcost_1FL_BC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                             // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                             echo "<p>" . $restoname_1FL_BC[0] . " spends more money based on the food type: " . $foodtype_1FL_BC[0] .
                                             " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_1FL_BC[1] . " with " . $foodtype_1FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_1FL_BC[count($restoname_1FL_BC) - 1] . " with " . $foodtype_1FL_BC[count($foodtype_1FL_BC) - 1] . " (Lowest).</p>";;
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }

                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {
                        $rcity_2FL_BC = array();
                        $foodtype_2FL_BC = array();
                        $rawcost_2FL_BC = array();

                        $query_BC_modal = "SELECT ur.rcity, w.foodtype, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.rcity IN ($list) GROUP BY ur.rcity, w.foodtype";

                        $query_run_BC_modal = mysqli_query($con, $query_BC_modal);

                        if(mysqli_num_rows($query_run_BC_modal) > 0)
                        {
                            while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                            {
                                $rcity = $row_BC['rcity']; 
                                $foodtype = $row_BC['foodtype'];
                                $weight = $row_BC['weight'];  
                                
                                $rcity_2FL_BC[] = $rcity;
                                $foodtype_2FL_BC[] = $foodtype; 
                                $rawcost_2FL_BC[] = $weight;                                         
                            }                                            
                        }                              
                    ?>
                            <div id="myModal-bar-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>City selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>City</th>
                                                <th>Food Type</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_2FL_BC, SORT_DESC, $rcity_2FL_BC, $foodtype_2FL_BC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($rcity_2FL_BC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $rcity_2FL_BC[$i]; ?></td>
                                                <td><?php echo $foodtype_2FL_BC[$i]; ?></td>
                                                <td><?php echo number_format($rawcost_2FL_BC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($rcity_2FL_BC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_2FL_BC[0] - $rawcost_2FL_BC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $rcity_2FL_BC[0] . " spends more money based on the food type: " . $foodtype_2FL_BC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_2FL_BC[1] . " with " . $foodtype_2FL_CC[0] . ".</p>";
                                        }
                                    }

                                    if (count($rcity_2FL_BC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_2FL_BC[0] - $rawcost_2FL_BC[count($rawcost_2FL_BC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_2FL_BC[0] - $rawcost_2FL_BC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                            echo "<p>" . $rcity_2FL_BC[0] . " spends more money based on the food type: " . $foodtype_2FL_BC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_2FL_BC[1] . " with " . $foodtype_2FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_2FL_BC[count($rcity_2FL_BC) - 1] . " with " . $foodtype_2FL_BC[count($foodtype_2FL_BC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {   
                        $restoname_3FL_BC = array();
                        $foodtype_3FL_BC = array();
                        $rawcost_3FL_BC = array();
                        $restoname_city_3FL_BC = array();
                        $rcity_3FL_BC = array();

                        $query_BC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.foodtype, ur.rcity, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.foodtype";

                        $query_run_BC_modal = mysqli_query($con, $query_BC_modal);

                        if(mysqli_num_rows($query_run_BC_modal) > 0)
                        {
                            while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                            {
                                $restoname = $row_BC['restoname']; 
                                $foodtype = $row_BC['foodtype'];
                                $weight = $row_BC['weight'];
                                $restoname_city = $row_BC['restoname_city'];
                                $rcity = $row_BC['rcity'];
                                
                                $restoname_3FL_BC[] = $restoname;
                                $foodtype_3FL_BC[] = $foodtype;
                                $rawcost_3FL_BC[] = $weight;
                                $restoname_city_3FL_BC[] = $restoname_city;
                                $rcity_3FL_BC[] = $rcity;                                      
                            }                                          
                        }              
                        
                    ?>
                            <div id="myModal-bar-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                    <p><center><b>Restaurants and cities selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                    <table border="1"  style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th>Restaurant</th>
                                                <th>City</th>
                                                <th>Food Type</th>
                                                <th>Average Weight (Kg)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            array_multisort($rawcost_3FL_BC, SORT_DESC, $restoname_3FL_BC, $foodtype_3FL_BC, $restoname_city_3FL_BC, $rcity_3FL_BC);

                                            // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                            for ($i = 0; $i < count($restoname_3FL_BC); $i++) { ?>
                                                <tr>
                                                <td><?php echo $restoname_3FL_BC[$i]; ?></td>   
                                                <td><?php echo $rcity_3FL_BC[$i]; ?></td>
                                                <td><?php echo $foodtype_3FL_BC[$i]; ?></td>

                                                <td><?php echo number_format($rawcost_3FL_BC[$i], 2, '.', ','); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table><hr>
                                    <?php
                                    
                                    if (count($restoname_3FL_BC) == 2) {
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_3FL_BC[0] - $rawcost_3FL_BC[1];
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0) {
                                            echo "<p>" . $restoname_city_3FL_BC[0] . " spends more money based on the food type: " . $foodtype_3FL_BC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_BC[1] . " with " . $foodtype_3FL_BC[0] . ".</p>";
                                        }
                                    }

                                    if (count($restoname_3FL_BC) > 2) {
                                        // Calculate the difference in weight between the highest and lowest restonames
                                        $difference_lowest = $rawcost_3FL_BC[0] - $rawcost_3FL_BC[count($rawcost_3FL_BC) - 1];
                                        // Calculate the difference in weight between the highest and second-highest restonames
                                        $difference_second_highest = $rawcost_3FL_BC[0] - $rawcost_3FL_BC[1]; 
                                        // Check if the difference is greater than 0
                                        if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                            // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                            echo "<p>" . $restoname_city_3FL_BC[0] . " spends more money based on the food type: " . $foodtype_3FL_BC[0] .
                                            " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_3FL_BC[1] . " with " . $foodtype_3FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_3FL_BC[count($restoname_city_3FL_BC) - 1] . " with " . $foodtype_3FL_BC[count($foodtype_3FL_BC) - 1] . " (Lowest).</p>";
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php
                    }
        
                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {
                        $restoname_4FL_BC = array();
                        $foodtype_4FL_BC = array();
                        $rawcost_4FL_BC = array();
                        $restoname_city_4FL_BC = array();
                        $rcity_4FL_BC = array();
                        $created_4FL_BC = array();   

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.foodtype, ur.rcity, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_4FL_BC[] = $restoname;
                                    $foodtype_4FL_BC[] = $foodtype;
                                    $rawcost_4FL_BC[] = $weight;
                                    $restoname_city_4FL_BC[] = $restoname_city;
                                    $rcity_4FL_BC[] = $rcity;   
                                    $created_4FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants and cities selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_4FL_BC, SORT_DESC, $restoname_4FL_BC, $foodtype_4FL_BC, $restoname_city_4FL_BC, $rcity_4FL_BC, $created_4FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_4FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_4FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_4FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_4FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_4FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_4FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_4FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_city_4FL_BC[0] . " spends more money based on the food type: " . $foodtype_4FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[1] . " with " . $foodtype_4FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_4FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[count($rawcost_4FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_city_4FL_BC[0] . " spends more money based on the food type: " . $foodtype_4FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[1] . " with " . $foodtype_4FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[count($restoname_city_4FL_BC) - 1] . " with " . $foodtype_4FL_BC[count($foodtype_4FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if (empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.foodtype, ur.rcity, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_4FL_BC[] = $restoname;
                                    $foodtype_4FL_BC[] = $foodtype;
                                    $rawcost_4FL_BC[] = $weight;
                                    $restoname_city_4FL_BC[] = $restoname_city;
                                    $rcity_4FL_BC[] = $rcity;   
                                    $created_4FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants and cities selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_4FL_BC, SORT_DESC, $restoname_4FL_BC, $foodtype_4FL_BC, $restoname_city_4FL_BC, $rcity_4FL_BC, $created_4FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_4FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_4FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_4FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_4FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_4FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_4FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_4FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_city_4FL_BC[0] . " spends more money based on the food type: " . $foodtype_4FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[1] . " with " . $foodtype_4FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_4FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[count($rawcost_4FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_4FL_BC[0] - $rawcost_4FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_city_4FL_BC[0] . " spends more money based on the food type: " . $foodtype_4FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[1] . " with " . $foodtype_4FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_city_4FL_BC[count($restoname_city_4FL_BC) - 1] . " with " . $foodtype_4FL_BC[count($foodtype_4FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }   

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date'])) 
                    {
                        $restoname_5FL_BC = array();
                        $foodtype_5FL_BC = array();
                        $rawcost_5FL_BC = array();
                        $restoname_city_5FL_BC = array();
                        $rcity_5FL_BC = array();
                        $created_5FL_BC = array();

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query_BC_modal = "SELECT ur.restoname, w.foodtype, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($list) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_5FL_BC[] = $restoname;
                                    $foodtype_5FL_BC[] = $foodtype;
                                    $rawcost_5FL_BC[] = $weight;  
                                    $created_5FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_5FL_BC, SORT_DESC, $restoname_5FL_BC, $foodtype_5FL_BC, $restoname_5FL_BC, $created_5FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_5FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_5FL_BC[$i]; ?></td>   
                                                    <td><?php echo $foodtype_5FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_5FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_5FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_5FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_5FL_BC[0] . " spends more money based on the food type: " . $foodtype_5FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_BC[1] . " with " . $foodtype_5FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_5FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[count($rawcost_5FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_5FL_BC[0] . " spends more money based on the food type: " . $foodtype_5FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_BC[1] . " with " . $foodtype_5FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_5FL_BC[count($restoname_5FL_BC) - 1] . " with " . $foodtype_5FL_BC[count($foodtype_5FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                        
                        if (empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT ur.restoname, w.foodtype, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($list) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_5FL_BC[] = $restoname;
                                    $foodtype_5FL_BC[] = $foodtype;
                                    $rawcost_5FL_BC[] = $weight;  
                                    $created_5FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Restaurants selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_5FL_BC, SORT_DESC, $restoname_5FL_BC, $foodtype_5FL_BC, $restoname_5FL_BC, $created_5FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_5FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_5FL_BC[$i]; ?></td>   
                                                    <td><?php echo $foodtype_5FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_5FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_5FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_5FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_5FL_BC[0] . " spends more money based on the food type: " . $foodtype_5FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_BC[1] . " with " . $foodtype_5FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_5FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[count($rawcost_5FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_5FL_BC[0] - $rawcost_5FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_5FL_BC[0] . " spends more money based on the food type: " . $foodtype_5FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_5FL_BC[1] . " with " . $foodtype_5FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_5FL_BC[count($restoname_5FL_BC) - 1] . " with " . $foodtype_5FL_BC[count($foodtype_5FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }   

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']))
                    {                       
                        $foodtype_6FL_BC = array();
                        $rawcost_6FL_BC = array();
                        $rcity_6FL_BC = array();
                        $created_6FL_BC = array();

                        if (isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query_BC_modal = "SELECT ur.rcity, w.foodtype, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $rcity = $row_BC['rcity']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $rcity_6FL_BC[] = $rcity;
                                    $foodtype_6FL_BC[] = $foodtype;
                                    $rawcost_6FL_BC[] = $weight;  
                                    $created_6FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>City selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_6FL_BC, SORT_DESC, $rcity_6FL_BC, $foodtype_6FL_BC, $rcity_6FL_BC, $created_6FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($rcity_6FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $rcity_6FL_BC[$i]; ?></td>   
                                                    <td><?php echo $foodtype_6FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_6FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_6FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($rcity_6FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $rcity_6FL_BC[0] . " spends more money based on the food type: " . $foodtype_6FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_BC[1] . " with " . $foodtype_6FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($rcity_6FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[count($rawcost_6FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $rcity_6FL_BC[0] . " spends more money based on the food type: " . $foodtype_6FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_BC[1] . " with " . $foodtype_6FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_6FL_BC[count($rcity_6FL_BC) - 1] . " with " . $foodtype_6FL_BC[count($foodtype_6FL_BC) - 1] . " (Lowest).</p>";

                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                        
                        if (empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT ur.rcity, w.foodtype, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($list2) GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $rcity = $row_BC['rcity']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $rcity_6FL_BC[] = $rcity;
                                    $foodtype_6FL_BC[] = $foodtype;
                                    $rawcost_6FL_BC[] = $weight;  
                                    $created_6FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>City selected and their average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Food Type</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_6FL_BC, SORT_DESC, $rcity_6FL_BC, $foodtype_6FL_BC, $rcity_6FL_BC, $created_6FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($rcity_6FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $rcity_6FL_BC[$i]; ?></td>   
                                                    <td><?php echo $foodtype_6FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_6FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_6FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($rcity_6FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $rcity_6FL_BC[0] . " spends more money based on the food type: " . $foodtype_6FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_BC[1] . " with " . $foodtype_6FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($rcity_6FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[count($rawcost_6FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_6FL_BC[0] - $rawcost_6FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $rcity_6FL_BC[0] . " spends more money based on the food type: " . $foodtype_6FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $rcity_6FL_BC[1] . " with " . $foodtype_6FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $rcity_6FL_BC[count($rcity_6FL_BC) - 1] . " with " . $foodtype_6FL_BC[count($foodtype_6FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }
                    }      

                // FILTER BY DATE  
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {
                        $restoname_7FL_BC = array();
                        $foodtype_7FL_BC = array();
                        $rawcost_7FL_BC = array();
                        $restoname_city_7FL_BC = array();
                        $rcity_7FL_BC = array();
                        $created_7FL_BC = array();

                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.foodtype, ur.rcity, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_7FL_BC[] = $restoname;
                                    $foodtype_7FL_BC[] = $foodtype;
                                    $rawcost_7FL_BC[] = $weight;
                                    $restoname_city_7FL_BC[] = $restoname_city;
                                    $rcity_7FL_BC[] = $rcity;   
                                    $created_7FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Time frame of average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_BC, SORT_DESC, $restoname_7FL_BC, $foodtype_7FL_BC, $restoname_city_7FL_BC, $rcity_7FL_BC, $created_7FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_7FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_7FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[count($rawcost_7FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_BC[count($restoname_7FL_BC) - 1] . " with " . $foodtype_7FL_BC[count($foodtype_7FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        }

                        if(empty($_GET['to_date']))
                        {                           
                            $query_BC_modal = "SELECT CONCAT(ur.restoname, ' (', ur.rcity, ')') AS restoname_city, ur.restoname, w.foodtype, ur.rcity, AVG(w.weight) 
                            AS weight, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname, w.foodtype";

                            $query_run_BC_modal = mysqli_query($con, $query_BC_modal);
                        
                            if(mysqli_num_rows($query_run_BC_modal) > 0)
                            {
                                while($row_BC = mysqli_fetch_array($query_run_BC_modal)) 
                                {
                                    $restoname = $row_BC['restoname']; 
                                    $foodtype = $row_BC['foodtype'];
                                    $weight = $row_BC['weight'];
                                    $restoname_city = $row_BC['restoname_city'];
                                    $rcity = $row_BC['rcity'];
                                    $created = date("Y-m-d", strtotime($row_BC['created_at']));
                                    
                                    $restoname_7FL_BC[] = $restoname;
                                    $foodtype_7FL_BC[] = $foodtype;
                                    $rawcost_7FL_BC[] = $weight;
                                    $restoname_city_7FL_BC[] = $restoname_city;
                                    $rcity_7FL_BC[] = $rcity;   
                                    $created_7FL_BC[] = $created;                                      
                                }                                          
                            }              
                        
                            ?>
                                <div id="myModal-bar-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <p><center><b>Time frame of average raw cost based on food type: </b><span style="font-size: smaller;">(From highest to lowest average)</span></center></p>
                                        <table border="1"  style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Reason</th>
                                                    <th>Average Weight (Kg)</th>
                                                    <th>Date Created</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php

                                                array_multisort($rawcost_7FL_BC, SORT_DESC, $restoname_7FL_BC, $foodtype_7FL_BC, $restoname_city_7FL_BC, $rcity_7FL_BC, $created_7FL_BC);

                                                // Loop through the sorted arrays and print the restonames and rawcosts in a table
                                                for ($i = 0; $i < count($restoname_7FL_BC); $i++) { ?>
                                                    <tr>
                                                    <td><?php echo $restoname_7FL_BC[$i]; ?></td>   
                                                    <td><?php echo $rcity_7FL_BC[$i]; ?></td>
                                                    <td><?php echo $foodtype_7FL_BC[$i]; ?></td>                                                  
                                                    <td><?php echo number_format($rawcost_7FL_BC[$i], 2, '.', ','); ?></td>
                                                    <td><?php echo $created_7FL_BC[$i]; ?></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table><hr>
                                        <?php
                                        
                                        if (count($restoname_7FL_BC) == 2) {
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1];
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0) {
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_CC[0] . ".</p>";
                                            }
                                        }

                                        if (count($restoname_7FL_BC) > 2) {
                                            // Calculate the difference in weight between the highest and lowest restonames
                                            $difference_lowest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[count($rawcost_7FL_BC) - 1];
                                            // Calculate the difference in weight between the highest and second-highest restonames
                                            $difference_second_highest = $rawcost_7FL_BC[0] - $rawcost_7FL_BC[1]; 
                                            // Check if the difference is greater than 0
                                            if ($difference_second_highest > 0 && $difference_lowest > 0) {
                                                // Print a message indicating that the highest restoname generates more food waste than the cheapest restoname
                                                echo "<p>" . $restoname_7FL_BC[0] . " spends more money based on the food type: " . $foodtype_7FL_BC[0] .
                                                " as they spend an average of " . number_format($difference_second_highest, 2, '.', ',') . " more than " . $restoname_7FL_BC[1] . " with " . $foodtype_7FL_BC[1] . " (2nd Highest) and an average of " . number_format($difference_lowest, 2, '.', ',') . " more than " . $restoname_7FL_BC[count($restoname_7FL_BC) - 1] . " with " . $foodtype_7FL_BC[count($foodtype_7FL_BC) - 1] . " (Lowest).</p>";
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php    
                        } 
                    }
          
            // VSCARD2 MODAL
                // FILTER BY RESTO 
                    if (isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {     
                        $query = "SELECT SUM(w.weight) AS weight, ur.restoname
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                <div class="modal-body">
                                    <p><center><b>Total Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Restaurants and their respective total weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                    }

                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {    
                        $query = "SELECT SUM(w.weight) AS weight, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.rcity IN ($card_list2) GROUP BY ur.rcity ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Total Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Cities and their respective total weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php     
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {    
                        $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Restaurants and their locations with the respective total weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php         
                    }

                // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                        <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their locations with the respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php     
                        }
                    }

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Cities and their respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT SUM(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard2" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard2">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Total Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Cities and their respective total weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php                 
                        }
                    }
            
            // VSCARD3 MODAL
                // FILTER BY RESTO 
                    if (isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {     
                        $query = "SELECT ur.restoname, AVG(w.weight) AS weight
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard3" class="modal">
                            <div class="modal-content">
                                <span class="close-vscard3">&times;</span>
                                <div class="modal-body">
                                    <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Restaurants and their respective average weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                    }

                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {    
                        $query = "SELECT AVG(w.weight) AS weight, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.rcity IN ($card_list2) GROUP BY ur.rcity ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard3" class="modal">
                        <div class="modal-content">
                            <span class="close-vscard3">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Cities and their respective average weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php     
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {    
                        $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-vscard3" class="modal">
                        <div class="modal-content">
                            <span class="close-vscard3">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <p>The table displayed above presents a list of Restaurants and their location with the respective average weight data from highest to lowest value.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php         
                    }

                // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                           <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their location with the respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-vscard3" class="modal">
                                <div class="modal-content">
                                    <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Restaurants and their respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php     
                        }
                    }

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);

                            ?>
                            <div id="myModal-vscard3" class="modal">
                                    <div class="modal-content">
                                        <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Cities and their respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);

                            ?>
                        <div id="myModal-vscard3" class="modal">
                                    <div class="modal-content">
                                        <span class="close-vscard3">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                            <p>The table displayed above presents a list of Cities and their respective average weight data from highest to lowest value.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php                 
                        }
                    }
            // LINE CHART MODAL
                // FILTER BY RESTO 
                    if (isset($_GET['filter']) && empty($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {     
                        $query = "SELECT ur.restoname, AVG(w.weight) AS weight, w.created_at
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-line-chart" class="modal">
                            <div class="modal-content">
                                <span class="close">&times;</span>
                                <div class="modal-body">
                                    <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                    }

                // FILTER BY CITY 
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date'])) 
                    {    
                        $query = "SELECT AVG(w.weight) AS weight, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.rcity IN ($card_list2) GROUP BY ur.rcity ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-line-chart" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php     
                    }

                // FILTER BY RESTO AND CITY
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && empty($_GET['from_date']) && empty($_GET['to_date']))                    
                    {    
                        $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                        FROM waste w
                        JOIN userresto ur ON ur.resto_id = w.resto_id
                        WHERE ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) GROUP BY ur.restoname ORDER BY w.weight DESC";
                        $query_run = mysqli_query($con, $query);

                        ?>
                        <div id="myModal-line-chart" class="modal">
                        <div class="modal-content">
                            <span class="close">&times;</span>
                                    <div class="modal-body">
                                    <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Restaurant</th>
                                                    <th>City</th>
                                                    <th>Weight</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                while($result = mysqli_fetch_array($query_run))
                                                {                                                                        
                                                    $weight = $result['weight'];                          
                                                    $restoname = $result['restoname'];  
                                                    $rcity = $result['rcity'];  
                                                    echo '<tr>
                                                            <td>' . $restoname . '</td>
                                                            <td>' . $rcity . '</td>
                                                            <td>' . "" . number_format($weight, 2) . '</td>
                                                        </tr>'; 
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php         
                    }

                // FILTER BY DATE 
                    elseif(empty($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // ALL FILTERS USED
                    elseif(isset($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date']))
                    {    
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list) AND ur.rcity IN ($card_list2) 
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average raw cost per restaurant and their respective city: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                    }

                // RESTO FILTER & DURATION FILTER USED
                    elseif(isset($_GET['filter']) && empty($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.restoname IN ($card_list)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);
        
                            ?>
                            <div id="myModal-line-chart" class="modal">
                                <div class="modal-content">
                                    <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per Restaurant: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>Restaurant</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $restoname = $result['restoname'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $restoname . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>
        
                            <?php     
                        }
                    }

                // CITY FILTER & DURATION FILTER USED
                    elseif(empty($_GET['filter']) && isset($_GET['filtercity']) && isset($_GET['from_date']) && !empty($_GET['from_date'])) 
                    {   
                        if(isset($_GET['to_date']) && !empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND '$to_date' AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);

                            ?>
                            <div id="myModal-line-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php         
                        }
                        
                        if(empty($_GET['to_date']))
                        {
                            $query = "SELECT AVG(w.weight) AS weight, ur.restoname, ur.rcity, w.created_at
                            FROM waste w
                            JOIN userresto ur ON ur.resto_id = w.resto_id
                            WHERE w.created_at BETWEEN '$from_date' AND NOW() AND ur.rcity IN ($card_list2)
                            GROUP BY ur.restoname ORDER BY w.weight DESC";
                            $query_run = mysqli_query($con, $query);

                            ?>
                            <div id="myModal-line-chart" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <div class="modal-body">
                                        <p><center><b>Average Weight Per City: </b><span style="font-size: smaller;">(From highest to lowest)</span></center></p>
                                            <table style="width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th>City</th>
                                                        <th>Weight</th>
                                                        <th>Date Created</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php 
                                                    while($result = mysqli_fetch_array($query_run))
                                                    {                                                                        
                                                        $weight = $result['weight'];                          
                                                        $rcity = $result['rcity'];  
                                                        $created = date("Y-m-d", strtotime($result['created_at']));
                                                        echo '<tr>
                                                                <td>' . $rcity . '</td>
                                                                <td>' . "" . number_format($weight, 2) . '</td>
                                                                <td>' . $created . '</td>
                                                            </tr>'; 
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                            <hr>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php                 
                        }
                    } 
        ?>

        <div class="chart-wrapper">
            <div id="piechart"></div>
            <div id="chart-container"></div>
        </div>

        <div class="chart-wrapper-column">
            <div id="columnchart_values"></div>  
            <div id="column-chart-container"></div> <!-- info icon columnchart-->
        </div>    
        
        <div class="chart-wrapper-bar">
            <div id="barchart_values"></div>       
            <div id="bar-chart-container"></div> <!-- info icon barchart-->
        </div>   

        <div class="chart-wrapper-linechart">
            <div id="linechart_values"></div>
            <div id="line-chart-container"></div> 
        </div>   

        <div id="vscard2-container"></div>
                    
        <div id="vscard3-container"></div>
    </div>

    <a href="/ewaste/visuals" id="visual-link">View Raw Cost Data</a>

</body>
</html>

<script>
    document.getElementById('vscard2-container').innerHTML += '<div class="info-icon-vscard2"><i class="fa fa-info-circle"></i></div>';
      
      document.querySelector('.info-icon-vscard2').addEventListener('click', function() {
  
          document.getElementById('myModal-vscard2').style.display = "block";
      });
  
      document.querySelector('.close-vscard2').addEventListener('click', function() {
  
      document.getElementById('myModal-vscard2').style.display = "none";
  
      });      

      document.getElementById('vscard3-container').innerHTML += '<div class="info-icon-vscard3"><i class="fa fa-info-circle"></i></div>';
      
      document.querySelector('.info-icon-vscard3').addEventListener('click', function() {
  
          document.getElementById('myModal-vscard3').style.display = "block";
      });
  
      document.querySelector('.close-vscard3').addEventListener('click', function() {
  
      document.getElementById('myModal-vscard3').style.display = "none";
  
      });     
</script>

<script>
  const checkAll = document.getElementById('checkAll');
  const checkboxes = document.querySelectorAll('input[name="filter[]"]');

  checkAll.addEventListener('change', function() {
    checkboxes.forEach(checkbox => {
      checkbox.checked = checkAll.checked;
    });
  });

  const checkAllCities = document.getElementById('checkAllCities');
  const cityCheckboxes = document.querySelectorAll('input[name="filtercity[]"]');

  checkAllCities.addEventListener('change', function() {
    cityCheckboxes.forEach(checkbox => {
      checkbox.checked = checkAllCities.checked;
    });
  });
</script>